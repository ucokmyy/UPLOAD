import "./settings/config.js";
import {
  makeWASocket,
  useMultiFileAuthState,
  jidDecode,
  DisconnectReason,
  downloadContentFromMessage,
  areJidsSameUser
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import PhoneNumber from 'awesome-phonenumber';
import store from "././source/lib/store.js";
import readline from "readline";
import pino from "pino";
import chalk from "chalk";
import fs from "fs-extra";
import NodeCache from "node-cache";
import { fileTypeFromBuffer } from "file-type";
import axios from "axios";
import * as jimp from "jimp";
import { spawn } from "child_process";
import { fileURLToPath, pathToFileURL } from "url";
import path from "path";
import { smsg } from "./source/myfunc.js";
import { handleWelcomeUpdate } from "./source/welcome.js";

global.sessionName = "session";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

const msgRetryCounterCache = new NodeCache();

const getBuffer = async (url, options = {}) => {
  try {
    const res = await axios({
      method: "get",
      url,
      headers: { DNT: 1, "Upgrade-Insecure-Request": 1 },
      responseType: "arraybuffer",
      ...options
    });
    return res.data;
  } catch (e) {
    console.log(`Error : ${e}`);
  }
};

const resize = async (imagePathOrUrl, width, height) => {
  let imageBuffer;
  if (/^https?:\/\//.test(imagePathOrUrl)) {
    const response = await axios.get(imagePathOrUrl, { responseType: "arraybuffer" });
    imageBuffer = response.data;
  } else {
    imageBuffer = await fs.readFile(imagePathOrUrl);
  }
  const read = await jimp.read(imageBuffer);
  return await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
};

let handleMessage;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const caserelog = path.resolve(__dirname, "./source/message.js");
const dbPath = path.resolve(__dirname, "./source/database/database.json");

async function relogfile() {
  try {
    const cacheBust = Date.now();
    const modulePath = pathToFileURL(caserelog).href;
    const module = await import(`${modulePath}?v=${cacheBust}`);
    
    if (typeof module.default !== 'function') {
        throw new Error("Reload gagal: 'message.js' tidak mengekspor 'default' sebagai fungsi.");
    }

    handleMessage = module.default;
    console.log(chalk.greenBright(`message.js berhasil di-reload!`));

  } catch (err) {
    console.error(chalk.red(`Gagal me-reload'message.js`));
    console.error(err);
  }
}

async function startServer() {
  const child = async () => {
    process.on("unhandledRejection", (err) => console.error(err));
    process.on("uncaughtException", (err) => console.error(err));

    await relogfile();
    fs.watchFile(caserelog, relogfile);

const { state, saveCreds } = await useMultiFileAuthState("./" + sessionName);

const conn = makeWASocket({
  version: [2, 3000, 1033105955],
  printQRInTerminal: false,
  logger: pino({ level: "silent" }),
  browser: ["Linux", "Chrome", "20.0.00"],
  auth: state,
  msgRetryCounterCache,
  connectTimeoutMs: 60000,
  emitOwnEvents: true,
  fireInitQueries: true,
  generateHighQualityLinkPreview: true,
  syncFullHistory: true,
  markOnlineOnConnect: true
});
store.bind(conn);
global.conn = conn;
conn.ev.on("creds.update", saveCreds);

if (!conn.authState.creds.registered) {
      console.log(chalk.cyan("╭──────────────────────────────────────···"));
      console.log(`📨 ${chalk.redBright("Masukkan nomor WhatsApp kamu:")}`);
      console.log(chalk.cyan("├──────────────────────────────────────···"));
      let phoneNumber = await question(`   ${chalk.cyan("- Nomor")}: `);
      console.log(chalk.cyan("╰──────────────────────────────────────···"));

      phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

      const customCode = global.customPairingCode;

      if (!phoneNumber || !customCode || customCode.length !== 8) {
          console.error(chalk.redBright("Pairing Code di config.js tidak valid."));
          console.error(chalk.redBright(`Nomor: ${phoneNumber || 'Kosong'}, Code: ${customCode || 'Kosong'} (harus 8 digit).`));
          process.exit(1);
          return;
      }

      console.log(chalk.cyan("╭──────────────────────────────────────···"));
      console.log(`📱 ${chalk.redBright("Nomor yang akan di-pair")}: ${chalk.cyan(phoneNumber)}`);
      console.log(chalk.cyan("├──────────────────────────────────────···"));

      await new Promise(resolve => setTimeout(resolve, 3000));

      const codeResult = await conn.requestPairingCode(phoneNumber, customCode);
      const displayCode = codeResult?.match(/.{1,4}/g)?.join("-") || codeResult;

      console.log(`  ${chalk.yellow("Pairing code:")} Masukkan kode ${chalk.cyan.bold(displayCode)}.`);
      console.log(chalk.cyan("╰──────────────────────────────────────···"));

      if (rl && !rl.closed) rl.close();
}

  conn.ev.on("messages.upsert", async (chatUpdate) => {
    try {
      let m = chatUpdate.messages?.[0];
      if (!m || !m.message) return;

      if (m.message?.ephemeralMessage?.message) {
        m.message = m.message.ephemeralMessage.message;
      }

      m = smsg(conn, m);
      if (!m?.key) return;

      const normalizeJid = async (jid) => {
        if (!jid || typeof jid !== 'string') return null;
        let cleaned = jid.split(':')[0].split('@')[0];
        if (jid.endsWith("@lid") && conn.signalRepository?.lidMapping) {
          const pn = await conn.signalRepository.lidMapping.getPNForLID(jid);
          if (pn) cleaned = pn.split(':')[0].split('@')[0];
        }
        if (jid.includes('@g.us')) return cleaned + '@g.us';
        return cleaned + '@s.whatsapp.net';
      };

      const senderRaw = m.key.participant || m.participant || m.sender || m.key.remoteJid;
      const senderJid = await normalizeJid(senderRaw);
      const remoteJid = m.key.remoteJid;

      if (!senderJid || !remoteJid) return;

      m.sender = senderJid;
      m.chat = remoteJid;

            if (!m.key.fromMe && remoteJid !== "status@broadcast") {
        fs.ensureFileSync(dbPath);
        let db = [];
        try {
          db = fs.readJsonSync(dbPath);
        } catch {
          db = [];
        }

        let isUpdated = false;
        const userIndex = db.findIndex(user => user.nomor === senderJid);
        const currentPushName = m.pushName || "Unknown";

        if (userIndex === -1) {
          db.push({
            index: db.length + 1,
            nomor: senderJid,
            name: currentPushName
          });
          isUpdated = true;
        } else if (db[userIndex].name !== currentPushName && currentPushName !== "Unknown") {
          db[userIndex].name = currentPushName;
          isUpdated = true;
        }

        if (isUpdated) {
          fs.writeJsonSync(dbPath, db, { spaces: 2 });
        }
      }


      if (remoteJid === "status@broadcast") {
        if (global.autoswview) await conn.readMessages([m.key]);
        return;
      }

      const ownerNumbers = Array.isArray(global.owner)
        ? global.owner.map(v => String(v).replace(/[^0-9]/g, ""))
        : [];

      const primaryOwnerNumber = String(global.primaryOwner || "").replace(/[^0-9]/g, "");
      const senderNumber = String(senderJid || "").replace(/[^0-9]/g, "");

      const isOwner = ownerNumbers.some(num => senderNumber.startsWith(num));
      const isPrimaryOwner = primaryOwnerNumber && senderNumber.startsWith(primaryOwnerNumber);

      const isSpecialGroup = global.idself &&
        (m.chat === global.idself || remoteJid === global.idself);

      const currentMode = global.mode || "public";
      const isAllowed =
        currentMode === "public"
          ? true
          : currentMode === "self"
          ? (isOwner || isSpecialGroup || m.key.fromMe)
          : currentMode === "ownerly"
          ? (isPrimaryOwner || m.key.fromMe)
          : currentMode === "oneown"
          ? (isPrimaryOwner || isSpecialGroup || m.key.fromMe)
          : true;

      if (!isAllowed && chatUpdate.type === "notify") return;
      if (m.key.id?.startsWith("BAE5") && m.key.id.length === 16) return;

      if (global.autoread) await conn.readMessages([m.key]);
      if (typeof handleMessage === "function") await handleMessage(conn, m, chatUpdate);

    } catch (err) {
      if (!err?.message?.includes("Bad MAC")) console.error(err);
    }
  });

conn.ev.on("group-participants.update", async (anu) => {
  await handleWelcomeUpdate(conn, anu);
});

conn.decodeJid = (jid) => {
  if (!jid) return jid;
  if (/:\d+@/gi.test(jid)) {
    let decode = jidDecode(jid) || {};
    return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
  } else return jid;
};

conn.getName = (jid, withoutContact = false) => {
  const id = conn.decodeJid(jid);
  let v = conn.chats?.[id] || {};

  if (id === "0@s.whatsapp.net") return "WhatsApp";
  if (id === conn.decodeJid(conn.user.id)) return conn.user.name;

  return (
    (withoutContact ? "" : v.name) ||
    v.subject ||
    v.notify ||
    v.verifiedName ||
    PhoneNumber("+" + id.replace("@s.whatsapp.net", "")).getNumber("international")
  );
};

conn.public = global.mode === "public";
conn.serializeM = (m) => smsg(conn, m);

    conn.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;
      if (connection === "close") {
        const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
        const reasonText = DisconnectReason[reason] || 'Alasan Tidak Diketahui';
        console.log(chalk.red(`Koneksi ditutup, alasan: ${reason} (${reasonText})`));

        if (reason === DisconnectReason.loggedOut || reason === DisconnectReason.badSession) {
          console.log(chalk.redBright(`❌ FATAL ERROR: Session tidak valid (${reasonText}).`));
          console.log(chalk.redBright(`Bot akan berhenti (crash) untuk mencegah infinite loop.`));
          console.log(chalk.redBright(`Sesuai permintaan, session TIDAK dihapus.`));
          console.log(chalk.redBright(`👉 Untuk memperbaiki, HAPUS folder "./${global.sessionName}" secara manual dan restart bot.`));
          process.exit(1); 
        } else {
          console.log(chalk.yellow("⚠️ Koneksi terputus, mencoba menyambung ulang secara otomatis (Natural Relog)..."));
          await child();
        }
      } else if (connection === "open") {
        console.log(chalk.greenBright("✅ Terhubung ke WhatsApp!"));
        await loadConnect(conn);
      }
    });
 
conn.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    const quoted = message.msg ? message.msg : message;
    const mime = (message.msg || message).mimetype || '';

    const messageType = message.mtype
        ? message.mtype.replace(/Message/gi, '')
        : mime.split('/')[0];

    const stream = await downloadContentFromMessage(quoted, messageType);

    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }

    const type = await fileTypeFromBuffer(buffer);
    const trueFileName = attachExtension && type
        ? `${filename}.${type.ext}`
        : filename;

    fs.writeFileSync(trueFileName, buffer);
    return trueFileName;
};

    conn.sendButton = async (jid, text, footer, btnklick, image1, image2, buttons, quoted, options) => {
      const message = {
        footer: footer,
        headerType: 1,
        viewOnce: true,
        image: { url: image1 },
        caption: text,
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "Pilih Opsi" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: btnklick,
                sections: [
                  {
                    title: "MENU UTAMA",
                    rows: buttons.map(btn => ({
                      title: btn.title,
                      description: btn.description || "",
                      id: btn.id
                    }))
                  }
                ]
              })
            }
          }
        ],
        contextInfo: {
          forwardingScore: 999,
          isForwarded: true,
          mentionedJid: [quoted.sender],
          forwardedNewsletterMessageInfo: {
            newsletterName: "— SH.Fauzialifatah",
            newsletterJid: "120363367787013309@newsletter"
          },
          externalAdReply: {
            title: global.namebotz,
            body: global.nameown,
            thumbnailUrl: image1,
            sourceUrl: global.YouTube,
            mediaType: 1,
            renderLargerThumbnail: false
          }
        },
        ...options
      };
      return await conn.sendMessage(jid, message, { quoted });
    };

    conn.sendButtonRelay = async (jid, text, buttons, quoted) => {
      const thumbnail = await resize("./source/thumbnail/image.jpg", 300, 300);
      const message = {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: -9999999999,
                  degreesLongitude: -8888888888,
                  name: global.namebotz,
                  address: global.nameown,
                  jpegThumbnail: thumbnail
                },
                hasMediaAttachment: true
              },
              body: { text: text },
              nativeFlowMessage: {
                buttons: buttons,
                messageParamsJson: JSON.stringify({
                  limited_time_offer: {
                    text: "t.me/FauziAlifatah",
                    url: "t.me/FauziAlifatah",
                    copy_code: "99999999",
                    expiration_time: Date.now() * 999
                  },
                  bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "Fauzialifatah",
                    button_title: "Fauzialifatah"
                  }
                })
              }
            }
          }
        }
      };
      return await conn.relayMessage(jid, message, { quoted });
    };

    conn.sendText = (jid, teks, quoted = "", options = {}) => conn.sendMessage(jid, { text: teks, ...options }, { quoted, ...options });

    conn.sendImage = async (jid, path, caption = "", quoted = "", options = {}) => {
      const buffer = Buffer.isBuffer(path)
        ? path
        : /^https?:\/\//.test(path)
        ? await getBuffer(path)
        : fs.existsSync(path)
        ? fs.readFileSync(path)
        : Buffer.alloc(0);
      return await conn.sendMessage(jid, { image: buffer, caption, ...options }, { quoted });
    };

    conn.sendAudio = async (jid, path, quoted = "", ptt = false, options = {}) => {
      const buffer = Buffer.isBuffer(path)
        ? path
        : /^https?:\/\//.test(path)
        ? await getBuffer(path)
        : fs.existsSync(path)
        ? fs.readFileSync(path)
        : Buffer.alloc(0);
      return await conn.sendMessage(jid, { audio: buffer, ptt, ...options }, { quoted });
    };

    conn.sendVideo = async (jid, path, caption = "", quoted = "", gif = false, options = {}) => {
      const buffer = Buffer.isBuffer(path)
        ? path
        : /^https?:\/\//.test(path)
        ? await getBuffer(path)
        : fs.existsSync(path)
        ? fs.readFileSync(path)
        : Buffer.alloc(0);
      return await conn.sendMessage(jid, { video: buffer, caption, gifPlayback: gif, ...options }, { quoted });
    };

    return conn;
  };
  await child();
}

startServer();

fs.watchFile(__filename, () => {
  console.log(chalk.redBright(`📦 File ${__filename} berubah, restart bot...`));
  spawn(process.argv[0], [__filename], { stdio: "inherit" });
  process.exit();
});
