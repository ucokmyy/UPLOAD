import fs from "fs"

const path = "./source/database/grupakses.json"

const handler = async (m) => {

  if (!fs.existsSync(path)) {
    return m.reply("Database grup akses belum ada")
  }

  let data = []
  try {
    data = JSON.parse(fs.readFileSync(path))
  } catch {
    return m.reply("Gagal membaca database")
  }

  if (!data.length) {
    return m.reply("Belum ada grup yang memiliki akses")
  }

  let teks = `📋 *LIST GRUP AKSES*\n\n`

  data.forEach((id, i) => {
    teks += `${i + 1}. ${id}\n`
  })

  m.reply(teks)
}

handler.command = ["listakses"]
handler.tags = ["owner"]
handler.help = ["listakses"]
handler.owner = true

export default handler