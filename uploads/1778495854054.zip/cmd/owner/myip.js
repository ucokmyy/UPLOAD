import axios from "axios"
import https from "https"

const httpsAgent = new https.Agent({
  keepAlive: false
})

const handler = async (m) => {
  try {
    const { data: ipData } = await axios.get("https://api.ipify.org?format=json", {
      timeout: 7000,
      httpsAgent
    })

    if (!ipData?.ip) throw new Error("Invalid IP response")

    const ip = ipData.ip
    let detail
    try {
      const { data } = await axios.get(`https://ipwho.is/${ip}`, {
        timeout: 7000,
        httpsAgent
      })

      if (!data.success) throw new Error("Primary lookup failed")
      detail = data
    } catch {
      const { data } = await axios.get(`https://ip-api.com/json/${ip}`, {
        timeout: 7000,
        httpsAgent
      })

      if (data.status !== "success")
        throw new Error("Fallback lookup failed")

      detail = {
        ip: data.query,
        country: data.country,
        country_code: data.countryCode,
        region: data.regionName,
        city: data.city,
        timezone: data.timezone,
        connection: {
          isp: data.isp,
          org: data.org,
          asn: data.as
        },
        latitude: data.lat,
        longitude: data.lon
      }
    }

    const teks = `
🔐 *SERVER PUBLIC IP INFORMATION*

🌍 IP Address   : ${detail.ip}
🏳️ Country      : ${detail.country} (${detail.country_code || "-"})
📍 Region       : ${detail.region || "-"}
🏙️ City         : ${detail.city || "-"}
🕒 Timezone     : ${detail.timezone || "-"}
📡 ISP          : ${detail.connection?.isp || "-"}
🏢 Organization : ${detail.connection?.org || "-"}
🧩 ASN          : ${detail.connection?.asn || "-"}
🛰️ Lat,Long     : ${detail.latitude || "-"}, ${detail.longitude || "-"}

📊 Lookup       : SUCCESS
`.trim()

    await m.reply(teks)

  } catch (err) {
    console.error("MYIP ERROR:", err.message)
    await m.reply("❌ Gagal mengambil IP (network blocked / API timeout).")
  }
}

handler.command = ["myip"]
handler.tags = ["owner"]
handler.help = ["myip"]
handler.owner = true

export default handler