const handler = async (m, { conn }) => {
  const groupMetadata2 = m.isGroup
    ? await conn.groupMetadata(m.chat)
    : {}

  const participants = m.isGroup
    ? groupMetadata2.participants
    : []

  m.reply(JSON.stringify(participants, null, 2))
}

handler.help = ['participants']
handler.tags = ['group']
handler.command = ['participants']
handler.owner = true

export default handler