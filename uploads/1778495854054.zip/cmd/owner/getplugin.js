import fs from "fs-extra";
import path from "path";
// list semua file .js di cmd/
const listJsFilesRecursively = (directory) => {
  const results = [];
  try {
    const entries = fs.readdirSync(directory, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        results.push(...listJsFilesRecursively(fullPath));
      } else if (entry.isFile() && fullPath.endsWith(".js")) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    console.error(`Gagal membaca direktori: ${directory}`, e);
  }
  return results;
};

// cari plugin berdasarkan nama (tanpa /)
function findPlugin(cmdDir, query) {
  const files = listJsFilesRecursively(cmdDir);

  let q = String(query || "").trim();
  if (!q) return null;

  q = q.replace(/\\/g, "/");
  if (!q.endsWith(".js")) q += ".js";

  // 1) kalau user kasih path langsung
  if (q.includes("/")) {
    const target = path.resolve(cmdDir, q);
    if (fs.existsSync(target)) {
      return {
        fullPath: target,
        relPath: path.relative(cmdDir, target).replace(/\\/g, "/")
      };
    }
    return null;
  }

  // 2) cari basename exact
  const exact = files.find(
    (f) => path.basename(f).toLowerCase() === q.toLowerCase()
  );
  if (exact) {
    return {
      fullPath: exact,
      relPath: path.relative(cmdDir, exact).replace(/\\/g, "/")
    };
  }

  // 3) cari partial match
  const partial = files.find((f) =>
    path.basename(f).toLowerCase().includes(q.toLowerCase())
  );
  if (partial) {
    return {
      fullPath: partial,
      relPath: path.relative(cmdDir, partial).replace(/\\/g, "/")
    };
  }

  return null;
}

let handler = async (m, { conn, q, reply, command, usedPrefix }) => {
  try {
    const query = (q || "").trim();
    if (!query) {
      return reply(
        `Contoh:\n${usedPrefix + command} menu\n${usedPrefix + command} owner/test`
      );
    }

    const rootDir = process.cwd();
    const cmdDir = path.resolve(rootDir, "./cmd");

    if (!(await fs.pathExists(cmdDir))) {
      return reply("Folder `./cmd/` tidak ditemukan.");
    }

    const found = findPlugin(cmdDir, query);
    if (!found) {
      return reply(
        `Plugin tidak ditemukan.\nCoba pakai:\n${usedPrefix + command} namaFile\natau\n${usedPrefix + command} owner/namaFile`
      );
    }

    const codeContent = await fs.readFile(found.fullPath, "utf8");

    const header = `📌𝗣𝗹𝘂𝗴𝗶𝗻 *${found.relPath}*\n\n`;

    // ✅ Action button "Salin" (copy full code, tanpa header)
    const buttons = [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "Salin code 📋",
          copy_code: codeContent
        })
      }
    ];

    const payload = {
      text: header + codeContent,
      footer: global.botname || "BOT",
      interactiveButtons: buttons
    };

    await conn.sendMessage(m.chat, payload, { quoted: m });
  } catch (e) {
    console.error(e);
    reply(`Gagal mengambil plugin:\n${e.message}`);
  }
};

handler.command = ["getplug", "getplugin"];
handler.owner = true;
handler.help = ["getplug"];
handler.tags = ["owner"];

export default handler;