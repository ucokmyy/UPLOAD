import fs from "fs-extra";
import path from "path";

const IGNORED_DIRS = new Set([
  "node_modules",
  ".git",
  ".cache",
  "tmp",
  "temp"
]);

function listFilesRecursively(directory) {
  const results = [];
  try {
    const entries = fs.readdirSync(directory, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(directory, entry.name);

      if (entry.isDirectory()) {
        if (IGNORED_DIRS.has(entry.name)) continue;
        results.push(...listFilesRecursively(fullPath));
      } else if (entry.isFile()) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    console.error(`Gagal membaca direktori: ${directory}`, e);
  }
  return results;
}

function findFile(rootDir, query) {
  const files = listFilesRecursively(rootDir);

  let q = String(query || "").trim();
  if (!q) return null;

  q = q.replace(/\\/g, "/");

  if (!/\.[a-z0-9]+$/i.test(path.basename(q))) {
    return { error: "NO_EXTENSION" };
  }

  if (q.includes("/")) {
    const target = path.resolve(rootDir, q);
    if (fs.existsSync(target) && fs.statSync(target).isFile()) {
      return {
        fullPath: target,
        relPath: path.relative(rootDir, target).replace(/\\/g, "/")
      };
    }
    return null;
  }

  const exact = files.find(
    (f) => path.basename(f).toLowerCase() === q.toLowerCase()
  );

  if (exact) {
    return {
      fullPath: exact,
      relPath: path.relative(rootDir, exact).replace(/\\/g, "/")
    };
  }

  const exactRel = files.find(
    (f) =>
      path.relative(rootDir, f).replace(/\\/g, "/").toLowerCase() === q.toLowerCase()
  );

  if (exactRel) {
    return {
      fullPath: exactRel,
      relPath: path.relative(rootDir, exactRel).replace(/\\/g, "/")
    };
  }

  return null;
}

let handler = async (m, { conn, q, reply, command, usedPrefix }) => {
  try {
    const query = String(q || "").trim();

    if (!query) {
      return reply(
        `Contoh penggunaan:\n` +
        `${usedPrefix + command} message.js\n` +
        `${usedPrefix + command} afk.js\n` +
        `${usedPrefix + command} afk.json\n\n` +
        `Wajib sertakan nama file lengkap beserta ekstensi.`
      );
    }

    const rootDir = process.cwd();
    const found = findFile(rootDir, query);

    if (found?.error === "NO_EXTENSION") {
      return reply(
        `Nama file wajib pakai ekstensi.\n\nContoh:\n` +
        `${usedPrefix + command} message.js\n` +
        `${usedPrefix + command} afk.json`
      );
    }

    if (!found) {
      return reply(
        `File tidak ditemukan: *${query}*\n\n` +
        `Pastikan nama file lengkap beserta ekstensi.\n` +
        `Contoh:\n${usedPrefix + command} tiktok.js`
      );
    }

    const relativePath = path.relative(rootDir, found.fullPath);
    if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
      return reply(
        "Error: Ilegal path traversal detected.\nAnda hanya boleh mengambil file di dalam folder project."
      );
    }

    const stat = await fs.stat(found.fullPath);

    await conn.sendMessage(
      m.chat,
      {
        document: await fs.readFile(found.fullPath),
        fileName: path.basename(found.fullPath),
        mimetype: "application/octet-stream",
        caption:
          `📂 *GET FILE*\n` +
          `📄 Nama : ${path.basename(found.fullPath)}\n` +
          `🗂️ Path : ${found.relPath}\n` +
          `🏷️ Size : ${stat.size} bytes`
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);
    reply(`Gagal mengambil file:\n${e.message}`);
  }
};

handler.command = ["getfile"];
handler.owner = true;
handler.help = ["getfile <nama.ext>"];
handler.tags = ["owner"];

export default handler;