import fs from "fs-extra";
import path from "path";

const listJsFilesRecursively = (directory) => {
  const results = [];
  try {
    const entries = fs.readdirSync(directory, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        results.push(...listJsFilesRecursively(fullPath));
      } else if (entry.isFile() && fullPath.endsWith(".js")) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    console.error(`Gagal membaca direktori: ${directory}`, e);
  }
  return results;
};

let handler = async (m, { reply }) => {
  try {
    const rootDir = process.cwd();
    const cmdDir = path.resolve(rootDir, "./cmd");

    if (!(await fs.pathExists(cmdDir))) {
      return reply("Folder `./cmd/` tidak ditemukan.");
    }

    const files = listJsFilesRecursively(cmdDir);

    if (files.length === 0) {
      return reply("Tidak ada plugin yang ditemukan di dalam folder `./cmd/`.");
    }

    // ✅ kelompokkan per folder pertama (owner/main/tools/...)
    const groups = {};
    for (const fullPath of files) {
      const rel = path.relative(cmdDir, fullPath).replace(/\\/g, "/"); // contoh: owner/listplug.js
      const folder = rel.split("/")[0] || "lainnya";

      if (!groups[folder]) groups[folder] = [];
      groups[folder].push(rel);
    }

    // sort folder A-Z
    const sortedFolders = Object.keys(groups).sort((a, b) => a.localeCompare(b));

    // build text
    let text = `📦 *Daftar Plugin Terinstal (Total: ${files.length})*\n`;

    for (const folder of sortedFolders) {
      const list = groups[folder].sort((a, b) => a.localeCompare(b));
      text += `\n\n🗃️ *Plugin ${folder} (${list.length})*\n`;
      text += list.map((x) => `• ${x}`).join("\n");
    }

    return reply(text.trim());
  } catch (e) {
    console.error(e);
    return reply(`Gagal mengambil daftar plugin:\n${e.message}`);
  }
};

handler.command = ["listplug", "pluginlist"];
handler.owner = true;
handler.help = ["listplug"];
handler.tags = ["owner"];

export default handler;