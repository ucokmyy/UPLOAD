const handler = async (m, { conn }) => {
  try {
    const botNumber = conn.user.id

    let gcall = Object.values(
      await conn.groupFetchAllParticipating().catch(_ => null)
    )

    if (!gcall || !gcall.length) {
      return m.reply("Bot belum ada di grup manapun.")
    }

    let listgc = `📋 *Berikut daftar grup:*\n\n`
    listgc += `────────────────────\n\n`

    for (let i = 0; i < gcall.length; i++) {
      let u = gcall[i]

      const groupMetadataa = await conn.groupMetadata(u.id)
        .catch(_ => (conn.chats?.[u.id]?.metadata || {}))

      const participantss = groupMetadataa?.participants || []

      const botJid = conn.decodeJid(botNumber)

      const map = Object.fromEntries(
        participantss.map(p => [conn.decodeJid(p.jid || p.id), p])
      )

      const bott = map[botJid] || {}

      const isBotAdmin =
        bott?.admin === "admin" || bott?.admin === "superadmin"

      let linkGc = await conn.groupInviteCode(u.id).catch(_ => null)
      linkGc = linkGc ? `https://chat.whatsapp.com/${linkGc}` : "Tidak tersedia"

      let admins = participantss.filter(
        v => v.admin === "admin" || v.admin === "superadmin"
      )

      listgc += `📌 *${i + 1}. ${u.subject}*\n`
      listgc += `────────────────────\n`
      listgc += `🆔 *ID Grup* : ${u.id}\n`
      listgc += `👤 *Pembuat* : ${u.owner ? u.owner.split("@")[0] : "Sudah keluar"}\n`
      listgc += `🔗 *Link* : ${linkGc}\n`
      listgc += `🔒 *Status* : ${u.restrict ? "Tutup" : "Buka"}\n`
      listgc += `👥 *Member* : ${participantss.length || "Tidak diketahui"}\n`
      listgc += `👑 *Admin* : ${admins.length || "Tidak diketahui"}\n`
      listgc += `🤖 *Bot Admin* : ${isBotAdmin ? "Ya" : "Tidak"}\n`
      listgc += `📅 *Dibuat* : ${
        u.creation
          ? new Date(u.creation * 1000).toLocaleString()
          : "Tidak diketahui"
      }\n`
      listgc += `✏️ *Nama Diubah* : ${
        u.subjectTime
          ? new Date(u.subjectTime * 1000).toLocaleString()
          : "Tidak diketahui"
      }\n`
      listgc += `📝 *Deskripsi Diubah* : ${
        u.descTime
          ? new Date(u.descTime * 1000).toLocaleString()
          : "Tidak diketahui"
      }\n`
      listgc += `────────────────────\n\n`
    }

    let ppuser = "https://telegra.ph/file/6880771a42bad09dd6087.jpg"
    try {
      ppuser = await conn.profilePictureUrl(conn.user.id, "image")
    } catch {}

    await conn.sendMessage(
      m.chat,
      {
        text: listgc,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            thumbnailUrl: ppuser,
            title: `[ ${gcall.length} Group Chat ]`,
            body: global.botname || "",
            sourceUrl: global.linkyt || "",
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: false
          }
        }
      },
      { quoted: m }
    )
  } catch (e) {
    console.error("[LISTGRUP ERROR]", e)
    m.reply("Gagal mengambil daftar grup.")
  }
}

handler.command = ["listgrup", "listgc"]
handler.help = ["listgrup"]
handler.tags = ["owner"]
handler.owner = true

export default handler