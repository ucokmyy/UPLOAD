import fs from "fs/promises"
import path from "path"

const EXT_TRASH = [
  ".gif", ".png", ".jpg", ".jpeg",
  ".webp", ".mp4", ".webm",
  ".mp3", ".opus",
  ".zip"
]

// root project bot
const ROOT_DIR = process.cwd()

async function scanDir(dir, result = []) {
  const files = await fs.readdir(dir, { withFileTypes: true })

  for (const file of files) {
    const fullPath = path.join(dir, file.name)

    // skip folder penting
    if (
      file.name === "node_modules" ||
      file.name === ".git" ||
      file.name === "session"
    ) continue

    if (file.isDirectory()) {
      await scanDir(fullPath, result)
    } else {
      const ext = path.extname(file.name).toLowerCase()
      if (EXT_TRASH.includes(ext)) {
        result.push(fullPath)
      }
    }
  }
  return result
}

const handler = async (m) => {
  try {
    const trashFiles = await scanDir(ROOT_DIR)

    if (trashFiles.length === 0) {
      return m.reply("🗑️ Tidak ada file sampah ditemukan.")
    }

    let teks = "🗑️ *FILE SAMPAH DIHAPUS*\n\n"

    trashFiles.forEach((file, i) => {
      teks += `${i + 1}. ${path.basename(file)}\n`
    })

    // hapus semua file
    for (const file of trashFiles) {
      await fs.unlink(file).catch(() => {})
    }

    teks += `\n🧾 Total sampah dihapus: *${trashFiles.length} file*`

    m.reply(teks)
  } catch (e) {
    console.error(e)
  }
}

handler.command = ["delsampah", "smph"]
handler.tags = ["owner"]
handler.help = ["delsampah"]
handler.owner = true

export default handler