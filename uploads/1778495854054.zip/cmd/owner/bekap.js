import fs from "fs"
import fsp from "fs/promises"
import path from "path"
import archiver from "archiver"

const ownerjid = "6282296626024@s.whatsapp.net"
const ROOT_DIR = process.cwd()

const EXT_TRASH = [
  ".gif", ".png", ".jpg", ".jpeg",
  ".webp", ".mp4", ".webm",
  ".mp3", ".opus",
  ".zip"
]

async function scanDir(dir, result = []) {
  const files = await fsp.readdir(dir, { withFileTypes: true })

  for (const file of files) {
    const fullPath = path.join(dir, file.name)

    if (
      file.name === "node_modules" ||
      file.name === ".git" ||
      file.name === "session"
    ) continue

    if (file.isDirectory()) {
      await scanDir(fullPath, result)
    } else {
      const ext = path.extname(file.name).toLowerCase()
      if (EXT_TRASH.includes(ext)) {
        result.push(fullPath)
      }
    }
  }
  return result
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B"
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB"
  if (bytes < 1024 * 1024 * 1024)
    return (bytes / (1024 * 1024)).toFixed(2) + " MB"
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + " GB"
}

const handler = async (m, { conn }) => {
  try {
    const zipName = "CIMMY BOT.zip"
    const zipPath = path.join(process.cwd(), zipName)

    const sent = await conn.sendMessage(
      m.chat,
      { text: "📥 Sedang backup, mohon tunggu..." },
      { quoted: m }
    )

    const trashFiles = await scanDir(ROOT_DIR)

    let totalSize = 0
    for (const file of trashFiles) {
      const stat = fs.statSync(file)
      totalSize += stat.size
    }

    let junkText = trashFiles.length
      ? trashFiles
          .map(f => `• ${path.basename(f)} 📁${formatSize(fs.statSync(f).size)}`)
          .join("\n")
      : "Tidak ada"

    await new Promise(r => setTimeout(r, 1000))

    await conn.sendMessage(
      m.chat,
      {
        text:
`🚮 Di temukan sampah 
${junkText}

🗑️ Membuang ${formatSize(totalSize)} sampah`,
        edit: sent.key
      }
    )

    for (const file of trashFiles) {
      await fsp.unlink(file).catch(() => {})
    }

    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath)

    const output = fs.createWriteStream(zipPath)
    const archive = archiver("zip", { zlib: { level: 9 } })

    archive.pipe(output)

    const folders = ["cmd", "source", "settings", "lib"]
    for (const folder of folders) {
      const folderPath = path.join(process.cwd(), folder)
      if (fs.existsSync(folderPath)) {
        archive.directory(folderPath, folder)
      }
    }

    const files = ["handler.js", "index.js", "package.json", "buttons.js"]
    for (const file of files) {
      const filePath = path.join(process.cwd(), file)
      if (fs.existsSync(filePath)) {
        archive.file(filePath, { name: file })
      }
    }

    await archive.finalize()

    output.on("close", async () => {
      const stats = fs.statSync(zipPath)

      let sizeText
      if (stats.size < 1024 * 1024) {
        sizeText = (stats.size / 1024).toFixed(2) + " KB"
      } else {
        sizeText = (stats.size / (1024 * 1024)).toFixed(2) + " MB"
      }

      // kirim ke owner
      await conn.sendMessage(
        ownerjid,
        {
          document: fs.readFileSync(zipPath),
          mimetype: "application/zip",
          fileName: zipName,
          caption: `✅ Backup selesai\n📦 Size: ${sizeText}`
        }
      )

      await new Promise(r => setTimeout(r, 1000))

      // 🔥 PESAN FINAL + BUSINESS MODE
      await conn.sendMessage(
        m.chat,
        {
          text: `✅ Backup selesai
📦 Size: ${sizeText}

> ─ silahkan cek pribadi`,
          contextInfo: {
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: "6282159019459@s.whatsapp.net"
            }
          }
        },
        { quoted: m }
      )
    })

  } catch (err) {
    console.error(err)
    m.reply(`❌ Error: ${err}`)
  }
}

handler.help = ["getsc"]
handler.tags = ["owner"]
handler.command = ["getsc", "bekap", "backup", "bekao"]
handler.owner = true

export default handler