import fs from "fs-extra";
import path from "path";

// list semua file .js di cmd/
const listJsFilesRecursively = (directory) => {
  const results = [];
  try {
    const entries = fs.readdirSync(directory, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        results.push(...listJsFilesRecursively(fullPath));
      } else if (entry.isFile() && fullPath.endsWith(".js")) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    console.error(`Gagal membaca direktori: ${directory}`, e);
  }
  return results;
};

// cari plugin berdasarkan nama (tanpa /)
function findPlugin(cmdDir, query) {
  const files = listJsFilesRecursively(cmdDir);

  let q = String(query || "").trim();
  if (!q) return null;

  q = q.replace(/\\/g, "/");
  if (!q.endsWith(".js")) q += ".js";

  // 1) kalau user kasih path langsung
  if (q.includes("/")) {
    const target = path.resolve(cmdDir, q);
    if (fs.existsSync(target)) {
      return {
        fullPath: target,
        relPath: path.relative(cmdDir, target).replace(/\\/g, "/")
      };
    }
    return null;
  }

  // 2) cari basename exact
  const exact = files.find(
    (f) => path.basename(f).toLowerCase() === q.toLowerCase()
  );
  if (exact) {
    return {
      fullPath: exact,
      relPath: path.relative(cmdDir, exact).replace(/\\/g, "/")
    };
  }

  // 3) cari partial match
  const partial = files.find((f) =>
    path.basename(f).toLowerCase().includes(q.toLowerCase())
  );
  if (partial) {
    return {
      fullPath: partial,
      relPath: path.relative(cmdDir, partial).replace(/\\/g, "/")
    };
  }

  return null;
}

let handler = async (m, { q, reply, command, usedPrefix }) => {
  try {
    const query = (q || "").trim();
    if (!query) {
      return reply(
        `Tentukan plugin yang ingin dihapus.\nContoh:\n${usedPrefix + command} menu\n${usedPrefix + command} owner/test`
      );
    }

    const rootDir = process.cwd();
    const cmdDir = path.resolve(rootDir, "./cmd");

    if (!(await fs.pathExists(cmdDir))) {
      return reply("Folder `./cmd/` tidak ditemukan.");
    }

    // ✅ cari otomatis lokasi plugin
    const found = findPlugin(cmdDir, query);
    if (!found) {
      return reply(
        `Plugin tidak ditemukan untuk: *${query}*\n\n` +
          `Coba tulis lebih spesifik:\n` +
          `${usedPrefix + command} owner/namaFile`
      );
    }

    const targetPath = found.fullPath;

    // ✅ anti path traversal (extra safety)
    const relativePath = path.relative(cmdDir, targetPath);
    if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
      return reply(
        "Error: Ilegal path traversal detected.\nAnda hanya boleh menghapus file di dalam folder `./cmd/`"
      );
    }

    if (!(await fs.pathExists(targetPath))) {
      return reply(`File tidak ditemukan:\n${targetPath}`);
    }

    const parentDir = path.dirname(targetPath);

    await fs.remove(targetPath);

    let replyMessage = `✅ Plugin berhasil dihapus dari:\n${targetPath}`;

    // ✅ kalau folder plugin kosong, hapus foldernya juga
    if (parentDir !== cmdDir) {
      const filesInDir = await fs.promises.readdir(parentDir);
      if (filesInDir.length === 0) {
        await fs.remove(parentDir);
        replyMessage += `\n\n✅ Folder kosong '${path.basename(parentDir)}' juga telah dihapus.`;
      }
    }

    return reply(replyMessage);
  } catch (e) {
    console.error(e);
    reply(`Gagal menghapus plugin:\n${e.message}`);
  }
};

handler.command = ["delplug", "dellplugin"];
handler.owner = true;
handler.help = ["delplug"];
handler.tags = ["owner"];

export default handler;