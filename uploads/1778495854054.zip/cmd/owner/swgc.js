import { prepareWAMessageMedia } from "@whiskeysockets/baileys"

async function handler(m, { conn, args }) {

  const example = `╔══⪻ 𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆 𝙎𝙒 ⪼══╗
║
╠⪼ Command:
║ • .swgc <teks>
║ • .sw <idgroup> <teks>
║
╠⪼ Atau:
║ • Kirim media + caption .swgc
║ • Reply media + .swgc
║ • Kirim media + .sw <idgroup>
║ • Reply media + .sw <idgroup>
║
╚═════════════════╝`

  // Ambil body dari text atau caption media
  const body = (m.text || m.caption || "").trim()
  const cmd = body.split(" ")[0]

  let targetGroup
  let storyText = ""

  // =========================
  // SWGC
  // =========================
  if (cmd === ".swgc") {

    if (!global.idself)
      return m.reply("global.idself belum diset di config.js")

    targetGroup = global.idself
    storyText = body.replace(".swgc", "").trim()
  }

  // =========================
  // SW MANUAL
  // =========================
  if (cmd === ".sw") {

    if (!args[0])
      return m.reply("⚠ Masukkan ID grup.\nContoh: .sw 123456@g.us Halo")

    targetGroup = args[0]
    storyText = args.slice(1).join(" ")
  }

  if (!targetGroup)
    return m.reply(example)

  const quoted = m.quoted
  const mime =
    (m.message?.imageMessage && "image") ||
    (m.message?.videoMessage && "video") ||
    quoted?.mimetype ||
    ""

  try {

    // =========================
    // MEDIA LANGSUNG (KIRIM MEDIA + CAPTION)
    // =========================
    if (!quoted && (m.message?.imageMessage || m.message?.videoMessage)) {

      const buffer = await m.download()

      const media = await prepareWAMessageMedia(
        m.message.videoMessage
          ? { video: buffer, caption: storyText }
          : { image: buffer, caption: storyText },
        { upload: conn.waUploadToServer }
      )

      await conn.relayMessage(targetGroup, {
        groupStatusMessageV2: {
          message: m.message.videoMessage
            ? { videoMessage: media.videoMessage }
            : { imageMessage: media.imageMessage }
        }
      }, {})

      return m.reply("✅ Story media berhasil diupload.")
    }

    // =========================
    // REPLY MEDIA
    // =========================
    if (quoted && /image|video/.test(quoted.mimetype || "")) {

      const buffer = await quoted.download()

      const media = await prepareWAMessageMedia(
        /video/.test(quoted.mimetype)
          ? { video: buffer, caption: storyText || quoted.caption || "" }
          : { image: buffer, caption: storyText || quoted.caption || "" },
        { upload: conn.waUploadToServer }
      )

      await conn.relayMessage(targetGroup, {
        groupStatusMessageV2: {
          message: /video/.test(quoted.mimetype)
            ? { videoMessage: media.videoMessage }
            : { imageMessage: media.imageMessage }
        }
      }, {})

      return m.reply("✅ Story media berhasil diupload.")
    }

    // =========================
    // TEKS LANGSUNG ATAU REPLY TEKS
    // =========================
    if (storyText || quoted?.text) {

      const finalText = storyText || quoted.text

      await conn.relayMessage(targetGroup, {
        groupStatusMessageV2: {
          message: {
            extendedTextMessage: {
              text: finalText
            }
          }
        }
      }, {})

      return m.reply("✅ Story teks berhasil diupload.")
    }

    return m.reply(example)

  } catch (e) {
    return m.reply("❌ Gagal upload story.\nError: " + e.message)
  }
}

handler.command = ["sw","swgc"]
handler.owner = true

export default handler