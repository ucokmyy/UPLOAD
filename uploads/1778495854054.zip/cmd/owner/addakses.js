import { addGroupAccess, delGroupAccess } from "../../source/database/grupakses.js"

const handler = async (m, { args, command }) => {

  const id = args[0]
  if (!id) return m.reply("Masukkan ID grup")

  if (command === "addakses") {
    addGroupAccess(id)
    return m.reply("Berhasil tambah akses grup")
  }

  if (command === "delakses") {
    delGroupAccess(id)
    return m.reply("Berhasil hapus akses grup")
  }
}

handler.command = ["addakses", "delakses"]
handler.tags = ["owner"]
handler.help = ["addakses <idgrup>", "delakses <idgrup>"]
handler.owner = true

export default handler