import fs from "fs-extra";
import path from "path";

// list semua file .js di cmd/
const listJsFilesRecursively = (directory) => {
  const results = [];
  try {
    const entries = fs.readdirSync(directory, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        results.push(...listJsFilesRecursively(fullPath));
      } else if (entry.isFile() && fullPath.endsWith(".js")) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    console.error(`Gagal membaca direktori: ${directory}`, e);
  }
  return results;
};

// cari plugin berdasarkan nama (tanpa /)
function findPlugin(cmdDir, query) {
  const files = listJsFilesRecursively(cmdDir);

  let q = String(query || "").trim();
  if (!q) return null;

  q = q.replace(/\\/g, "/");
  if (!q.endsWith(".js")) q += ".js";

  // 1) kalau input mengandung "/" berarti user udah kasih path
  if (q.includes("/")) {
    const target = path.resolve(cmdDir, q);
    if (fs.existsSync(target)) {
      return {
        fullPath: target,
        relPath: path.relative(cmdDir, target).replace(/\\/g, "/")
      };
    }
    return null;
  }

  // 2) cari basename exact
  const exact = files.find(
    (f) => path.basename(f).toLowerCase() === q.toLowerCase()
  );
  if (exact) {
    return {
      fullPath: exact,
      relPath: path.relative(cmdDir, exact).replace(/\\/g, "/")
    };
  }

  // 3) cari partial match
  const partial = files.find((f) =>
    path.basename(f).toLowerCase().includes(q.toLowerCase())
  );
  if (partial) {
    return {
      fullPath: partial,
      relPath: path.relative(cmdDir, partial).replace(/\\/g, "/")
    };
  }

  return null;
}

let handler = async (m, { q, reply, quoted }) => {
  try {
    let codeContent;

    if (quoted && quoted.text && q) {
      codeContent = quoted.text;
    } else {
      return reply(
        "Cara penggunaan:\nReply pesan yang berisi kode baru dengan perintah `.editplug path/file.js`"
      );
    }

    if (!q) return reply("Nama file atau path tidak boleh kosong.");
    if (!codeContent) return reply("Kode plugin tidak ditemukan.");

    const rootDir = process.cwd();
    const cmdDir = path.resolve(rootDir, "./cmd");

    // ✅ cari otomatis lokasi plugin
    const found = findPlugin(cmdDir, q);
    if (!found) {
      return reply(
        `File tidak ditemukan untuk: *${q}*\n\n` +
          `Coba tulis lebih spesifik:\n` +
          `.editplug owner/namaFile\n\n` +
          `Atau gunakan .addplug untuk membuat file baru.`
      );
    }

    const targetPath = found.fullPath;

    // anti path traversal tetap aman (meskipun udah ketemu)
    const relativePath = path.relative(cmdDir, targetPath);
    if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
      return reply(
        "Error: Ilegal path traversal detected.\nAnda hanya boleh mengedit file di dalam folder `./cmd/`"
      );
    }

    if (!(await fs.pathExists(targetPath))) {
      return reply(
        `File tidak ditemukan:\n${targetPath}\n\nGunakan .addplug untuk membuat file baru.`
      );
    }

    await fs.writeFile(targetPath, codeContent);

    reply(
      `✅ Plugin berhasil diedit di:\n${targetPath}\n\nPerubahan akan aktif (hot-reload) dalam beberapa detik.`
    );
  } catch (e) {
    console.error(e);
    reply(`Gagal mengedit plugin:\n${e.message}`);
  }
};

handler.command = ["editplug", "saveplug"];
handler.owner = true;
handler.help = ["editplug"];
handler.tags = ["owner"];

export default handler;