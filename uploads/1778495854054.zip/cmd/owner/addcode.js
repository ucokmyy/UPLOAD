import fs from 'fs-extra'
import path from 'path'

let handler = async (m, { q, reply, quoted }) => {
  try {
    if (!quoted || !quoted.text) {
      return reply('Reply pesan yang berisi kode untuk dimasukkan ke buttons.js')
    }

    const fileName = q?.trim() || 'buttons.js'
    const finalName = fileName.endsWith('.js') ? fileName : fileName + '.js'

    if (finalName !== 'buttons.js') {
      return reply('File ini hanya diperbolehkan untuk buttons.js')
    }

    const rootDir = process.cwd()
    const targetPath = path.resolve(rootDir, './buttons.js')

    await fs.ensureFile(targetPath)
    await fs.writeFile(targetPath, quoted.text, 'utf8')

    reply(`Berhasil menulis kode ke:\n${targetPath}`)

  } catch (e) {
    console.error(e)
    reply(`Gagal menulis buttons.js:\n${e.message}`)
  }
}

handler.command = ['addcode']
handler.owner = true

export default handler