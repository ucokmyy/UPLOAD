import moment from "moment-timezone"
import { generateWAMessageFromContent } from "@whiskeysockets/baileys"

const DEFAULT_THUMB = "https://tse2.mm.bing.net/th?id=OIP.n1C1oxOvYLLyDIavrBFoNQHaHa&pid=Api&P=0&w=153&h=153"

function extractGroupCode(input = "") {
  const match = input.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i)
  return match ? match[1] : null
}

const handler = async (m, { conn, args, usedPrefix, command }) => {
  let input = args.join(" ").trim()

  if (!input && m.quoted) {
    input = (
      m.quoted.text ||
      m.quoted.caption ||
      m.quoted.contentText ||
      m.quoted.selectedDisplayText ||
      ""
    ).trim()
  }

  if (!input) {
    return m.reply(
      `╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command}
╠⪼ 𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶:
║   • ${usedPrefix + command} <link group>
║   • reply pesan berisi link group lalu ketik ${usedPrefix + command}
╠⪼ 𝗖𝗼𝗻𝘁𝗼𝗵:
║   • ${usedPrefix + command} https://chat.whatsapp.com/xxxxx
║
╚═════════════╝`
    )
  }

  const code = extractGroupCode(input)
  if (!code) return m.reply("Link group tidak valid.")

  await conn.sendMessage(m.chat, { react: { text: "🔍", key: m.key } })

  try {
    const res = await conn.query({
      tag: "iq",
      attrs: {
        type: "get",
        xmlns: "w:g2",
        to: "@g.us"
      },
      content: [{ tag: "invite", attrs: { code } }]
    })

    const attrs = res?.content?.[0]?.attrs || {}
    const groupIdRaw = attrs.id || "undefined"
    const groupJid = attrs.id ? `${attrs.id}@g.us` : "undefined"

    let pp = DEFAULT_THUMB
    if (attrs.id) {
      try {
        pp = await conn.profilePictureUrl(groupJid, "image")
      } catch {}
    }

    const subject = attrs.subject || "undefined"
    const descTime = attrs.s_t
      ? moment(attrs.s_t * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")
      : "undefined"
    const creatorJid = attrs.creator || null
    const creator = creatorJid ? `@${creatorJid.split("@")[0]}` : "undefined"
    const createdAt = attrs.creation
      ? moment(attrs.creation * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")
      : "undefined"
    const totalMember = attrs.size || "undefined"

    const caption = `乂 𝗜𝗡𝗙𝗢 𝗜𝗗 𝗚𝗥𝗢𝗨𝗣

▸ 𝗡𝗮𝗺𝗮 𝗚𝗿𝗼𝘂𝗽 : ${subject}
▸ 𝗜𝗗 𝗚𝗿𝗼𝘂𝗽 : ${groupJid}
▸ 𝗗𝗲𝘀𝗸𝗿𝗶𝗽𝘀𝗶 𝗗𝗶 𝗨𝗯𝗮𝗵 : ${descTime}
▸ 𝗣𝗲𝗺𝗯𝘂𝗮𝘁 : ${creator}
▸ 𝗚𝗿𝗼𝘂𝗽 𝗗𝗶𝗯𝘂𝗮𝘁 : ${createdAt}
▸ 𝗧𝗼𝘁𝗮𝗹 𝗠𝗲𝗺𝗯𝗲𝗿 : ${totalMember} Member

©${global.botname}`

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: caption
              },
              footer: {
                text: global.botname || ""
              },
              contextInfo: {
                mentionedJid: creatorJid ? [creatorJid] : [],
                externalAdReply: {
                  title: subject,
                  body: `${totalMember} Member`,
                  thumbnailUrl: pp,
                  sourceUrl: input,
                  mediaType: 1,
                  renderLargerThumbnail: true,
                  showAdAttribution: false
                }
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "Salin ID Group",
                      copy_code: groupJid
                    })
                  }
                ]
              }
            }
          }
        }
      },
      { quoted: m }
    )

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  } catch (e) {
    console.error("[IDGC ERROR]", e)
    m.reply("Gagal cek info group. Pastikan link valid dan belum di-reset.")
  }

  await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
}

handler.command = ["cekgc", "idgc", "getidgc"]
handler.help = ["idgc <link group>"]
handler.tags = ["owner"]
handler.owner = true

export default handler