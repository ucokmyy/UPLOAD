const handler = async (m, { conn, usedPrefix, command, isGroup, isGroupAdmins, isBotGroupAdmins }) => {
if (!m.isGroup) return m.reply("Hanya bisa digunakan dalam grup")
await conn.groupLeave(m.chat).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}
handler.command = ["leavegc", "lvgc"]
handler.owner = true
export default handler