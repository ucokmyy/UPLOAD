const modeLabel = {
  public: "PUBLIC",
  self: "SELF",
  ownerly: "OWNERONLY",
  oneown: "ONEOWN"
}

const handler = async (m, { conn, command }) => {
  const cmd = command.toLowerCase()
  const currentMode = global.mode || "public"

  const setMode = async (nextMode, successText) => {
    if (currentMode === nextMode) {
      return m.reply(`❌ Mode ${modeLabel[nextMode]} sudah aktif sebelumnya.`)
    }

    await global.saveMode(nextMode)
    conn.public = nextMode === "public"
    return m.reply(successText)
  }

  if (cmd === "public") {
    return setMode(
      "public",
      `Mode PUBLIC aktif

bot bisa dipakai semua orang di group maupun private`
    )
  }

  if (cmd === "self") {
    return setMode(
      "self",
      `Mode SELF aktif

bot hanya bisa dipakai:
• semua owner di private / group mana pun
• semua user di grup utama`
    )
  }

  if (cmd === "owneronly" || cmd === "ownerly") {
    return setMode(
      "ownerly",
      `Mode OWNERONLY aktif

bot sekarang hanya bisa dipakai oleh owner utama:
${global.primaryOwner}

owner ke-2 dan user biasa tidak bisa memakai bot sama sekali`
    )
  }

  if (cmd === "oneown") {
    return setMode(
      "oneown",
      `Mode ONEOWN aktif

yang bisa pakai bot:
• owner utama di semua chat + semua fitur owner
• owner ke-2 dan user biasa hanya di grup utama

catatan:
owner ke-2 tidak bisa memakai fitur owner saat mode ONEOWN aktif`
    )
  }

  if (cmd === "unowner") {
    return setMode(
      "self",
      `Mode khusus owner dimatikan

bot kembali ke mode SELF`
    )
  }
}

handler.command = ["self", "public", "owneronly", "ownerly", "oneown", "unowner"]
handler.tags = ["owner"]
handler.help = ["public", "self", "owneronly", "ownerly", "oneown", "unowner"]
handler.owner = true

export default handler