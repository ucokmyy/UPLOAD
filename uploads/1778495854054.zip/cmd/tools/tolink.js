import path from "path"
import fs from "fs"
import axios from "axios"
import FormData from "form-data"
import { exec } from "child_process"
import { fileURLToPath } from "url"
import { fileTypeFromBuffer } from "file-type"
import * as cheerio from "cheerio"
import fetch from "node-fetch"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const handler = async (m, { conn, command, prefix, reply }) => {
try {
let q = m.quoted ? m.quoted : m

if (!q || !q.download) {  
  return reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${prefix + command}
╠⪼ 𝗖𝗮𝗿𝗮: reply media dengan caption ${prefix + command}
║
╚═════════════╝`)
}

let media = await q.download()  
if (!media || !media.length) return reply("Media gagal diunduh.")  

let detected = await fileTypeFromBuffer(media)  
let ext = detected?.ext || "bin"  
let size = media.length  

let result = {  
  top4top: "🕑",  
  uguu: "🕑",  
  catbox: "🕑",  
  imgbb: "🕑",
  github: "🕑"
}  

const baseCaption = (status) => `
[ ${status} ]

🔗 Top4top: ${result.top4top}
🔗 Uguu: ${result.uguu}
🔗 Catbox: ${result.catbox}
🔗 ImgBB: ${result.imgbb}
🔗 GitHub: ${result.github}

📦 Size: ${size} Bytes
📄 Ext: ${ext}
`.trim()

let sent = await conn.sendMessage(  
  m.chat,  
  { text: baseCaption("UPLOAD PROSES") },  
  { quoted: m }  
)  

const update = async (done = false) => {  
  await conn.sendMessage(m.chat, {  
    text: baseCaption(done ? "UPLOAD SUCCESS" : "UPLOAD PROSES"),  
    edit: sent.key  
  })  
}  

/* =========================  
   TOP4TOP  
========================= */  
const uploadTop4top = async () => {  
  try {  
    const origin = "https://top4top.io"  
    const form = new FormData()  
    const filename = `${Date.now()}.${ext}`  

    form.append("file_1_", media, { filename })  
    form.append("submitr", "[ رفع الملفات ]")  

    const res = await fetch(origin + "/index.php", {  
      method: "POST",  
      body: form  
    })  

    if (!res.ok) return "-"  

    const html = await res.text()  

    const matches = html.matchAll(
      /value="(https:\/\/[^"]+)"/g
    )

    const arr = Array.from(matches)
    if (!arr.length) return "-"

    const downloadUrl = arr
      .map(v => v[1])
      .find(v => v.endsWith(ext))

    return downloadUrl || "-"
  } catch {
    return "-"
  }  
}  

/* =========================  
   UGUU  
========================= */  
const uploadUguu = async () => {  
  try {  
    const temp = path.join(__dirname, `${Date.now()}.${ext}`)  
    fs.writeFileSync(temp, media)  

    const out = await new Promise(r =>  
      exec(`curl -s -F "files[]=@${temp}" https://uguu.se/upload.php`, (_, o) => r(o))  
    )  

    fs.unlinkSync(temp)  
    const json = JSON.parse(out)  
    return json.files?.[0]?.url || "-"  
  } catch {  
    return "-"  
  }  
}  

/* =========================  
   CATBOX  
========================= */  
const uploadCatbox = async () => {  
  try {  
    const temp = path.join(__dirname, `${Date.now()}.${ext}`)  
    fs.writeFileSync(temp, media)  

    const form = new FormData()  
    form.append("reqtype", "fileupload")  
    form.append("fileToUpload", fs.createReadStream(temp))  

    const res = await axios.post(  
      "https://catbox.moe/user/api.php",  
      form,  
      { headers: form.getHeaders() }  
    )  

    fs.unlinkSync(temp)  
    return res.data.trim()  
  } catch {  
    return "-"  
  }  
}  

/* =========================  
   IMGBB  
========================= */ 
const uploadImgBB = async () => {  
  try {  
    const form = new FormData()  
    form.append("source", media, `${Date.now()}.${ext}`)  
    form.append("type", "file")  
    form.append("action", "upload")  
    form.append("timestamp", Date.now())  

    const { data } = await axios.post(  
      "https://imgbb.com/json",  
      form,  
      {  
        headers: {  
          ...form.getHeaders(),  
          "X-Requested-With": "XMLHttpRequest"  
        }  
      }  
    )  

    return data?.image?.url || "-"  
  } catch {  
    return "-"  
  }  
}  

/* =========================  
   GITHUB  
========================= */ 
const uploadGitHub = async () => {
  try {
    const token = "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"
    const owner = "ucokmyy"
    const repo = "UPLOAD"
    const filename = `${Date.now()}.${ext}`
    const filepath = `uploads/${filename}`

    const content = media.toString("base64")

    const res = await axios.put(
      `https://api.github.com/repos/${owner}/${repo}/contents/${filepath}`,
      {
        message: `Upload ${filename}`,
        content: content
      },
      {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/vnd.github.v3+json",
          "User-Agent": "NodeJS-Uploader"
        }
      }
    )

    return res.data.content.download_url || "-"
  } catch {
    return "-"
  }
}

const runners = [  
  uploadTop4top().then(r => { result.top4top = r; update() }),  
  uploadUguu().then(r => { result.uguu = r; update() }),  
  uploadCatbox().then(r => { result.catbox = r; update() }),  
  uploadImgBB().then(r => { result.imgbb = r; update() }),
  uploadGitHub().then(r => { result.github = r; update() })
]  

await Promise.allSettled(runners)  
await update(true)

} catch (e) {
console.error(e)
reply("Terjadi kesalahan.")
}
}

handler.command = ["tolink", "tourl"]
handler.tags = ["tools"]
handler.help = ["tolink", "tourl"]

export default handler