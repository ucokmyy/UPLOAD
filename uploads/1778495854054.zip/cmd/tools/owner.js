let handler = async (m, { conn }) => {
  const contacts = [
    {
      displayName: 'reyn',
      vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:𝖮𝗐𝗇𝖾𝗋 𝗋𝖾𝗒𝗇\nTEL;type=CELL;waid=6282296626024:6282296626024\nEND:VCARD`
    }
  ]

  const alamak = await conn.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: 'Owner Bot',
        contacts
      }
      /* 
      contextInfo: {
        externalAdReply: {
          title: "CONTACT OWNER",
          body: global.botname,
          thumbnailUrl: "https://j.top4top.io/p_3563araz21.jpg",
          sourceUrl: "https://wa.me/6282296626024",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
      */
    },
    { quoted: m }
  )

  await conn.sendMessage(
    m.chat,
    {
      text: `halo kaks @${m.sender.split("@")[0]}\n\nhubungi dia kalo ada perlu, dan jangan di spam ya!`,
      mentions: [m.sender]
    },
    { quoted: alamak }
  )
}

handler.command = ["owner"]
handler.help = ["owner"]
handler.tags = ["info"]

export default handler