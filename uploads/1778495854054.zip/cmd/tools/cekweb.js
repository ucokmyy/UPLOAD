import axios from "axios"

const handler = async (m, { text }) => {
  if (!text) return m.reply("Contoh: .cekweb https://example.com")

  let url = text.trim()
  if (!/^https?:\/\//i.test(url)) url = "https://" + url

  const userAgents = [
    {
      name: "Chrome Windows",
      ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    },
    {
      name: "Chrome Android",
      ua: "Mozilla/5.0 (Linux; Android 10; SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    },
    {
      name: "Safari iPhone",
      ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1"
    },
    {
      name: "Firefox Windows",
      ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0"
    }
  ]

  const results = []

  for (const agent of userAgents) {
    try {
      const res = await axios.get(url, {
        timeout: 15000,
        validateStatus: () => true,
        headers: {
          "User-Agent": agent.ua,
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "en-US,en;q=0.9",
          "Connection": "keep-alive"
        }
      })

      const blocked =
        res.status === 403 ||
        res.status === 503 ||
        res.data?.includes("cf-browser-verification") ||
        res.data?.includes("Cloudflare")

      results.push(
        `🔹 ${agent.name}\nStatus: ${res.status}\n${blocked ? "❌ Blocked" : "✅ Accessible"}`
      )

    } catch (err) {
      results.push(`🔹 ${agent.name}\n❌ Error`)
    }
  }

  m.reply(
    `🔎 Hasil cek: ${url}\n\n` +
    results.join("\n\n")
  )
}

handler.command = ["cekweb"]
handler.help = ["cekweb <url>"]
handler.tags = ["tools"]

export default handler