import fs from "fs"
import path from "path"
import { exec } from "child_process"
import { promisify } from "util"
import { Sticker, StickerTypes } from "wa-sticker-formatter"

const execAsync = promisify(exec)

const MIN_PX = 8
const MAX_PX = 360

function getExtFromMime(mime = "") {
  mime = String(mime).toLowerCase()
  if (mime.includes("webp")) return ".webp"
  if (mime.includes("png")) return ".png"
  if (mime.includes("jpg") || mime.includes("jpeg")) return ".jpg"
  if (mime.includes("mp4")) return ".mp4"
  if (mime.includes("video")) return ".mp4"
  if (mime.includes("image")) return ".jpg"
  return ".bin"
}

const handler = async (m, { conn, command, usedPrefix, text }) => {
  const guide = `
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command} <${MIN_PX}p-${MAX_PX}p>
╠⪼𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶:
║   • reply foto/stiker/video/view-once lalu ketik: .${command} 50p
║   • atau kirim foto/video dengan caption: .${command} 144p
║
╚═════════════╝`.trim()

  const needPixelMsg = `silahkan masukkan pilihan pixel
Mulai dari ${MIN_PX}p hingga ${MAX_PX}p\n\ncontoh .${command} 48p`

  const isStickerMode = /^buriks$/i.test(command)

  const target = m.quoted || m

  const isViewOnce = target?.message?.viewOnceMessage
  const msg = isViewOnce ? target.message.viewOnceMessage.message : target

  const mimetype =
    msg?.imageMessage?.mimetype ||
    msg?.videoMessage?.mimetype ||
    msg?.stickerMessage?.mimetype ||
    target?.mimetype ||
    (target.msg || target)?.mimetype ||
    ""

  const isImage = /image/.test(mimetype)
  const isVideo = /video/.test(mimetype)
  const isSticker = /webp/.test(mimetype) || /sticker/.test(mimetype)
  const hasMedia = isImage || isVideo || isSticker

  if (!hasMedia) return m.reply(guide)
  if (!text) return m.reply(needPixelMsg)

  const match = String(text).trim().match(/(\d{1,3})\s*p?/i)
  if (!match) return m.reply(needPixelMsg)

  let px = parseInt(match[1], 10)
  if (isNaN(px)) return m.reply(needPixelMsg)
  if (px < MIN_PX) return m.reply(`Minimal pixel adalah ${MIN_PX}p.`)
  if (px > MAX_PX) return m.reply(`Maksimal pixel adalah ${MAX_PX}p.`)

  await conn.sendMessage(m.chat, { react: { text: "🤢", key: m.key } })

  const extIn = getExtFromMime(mimetype)
  const inFile = path.join(process.cwd(), `burik_in_${Date.now()}${extIn}`)
  const outImg = path.join(process.cwd(), `burik_out_${Date.now()}.jpg`)
  const outVid = path.join(process.cwd(), `burik_out_${Date.now()}.mp4`)

  try {
    // ✅ DOWNLOAD MEDIA AMAN
    let media = null
    if (typeof target.download === "function") {
      media = await target.download()
    }

    // fallback kalau framework lu beda
    if (!media && typeof conn.downloadMediaMessage === "function") {
      media = await conn.downloadMediaMessage(target)
    }

    if (!media) throw new Error("Gagal download media")

    fs.writeFileSync(inFile, media)

    // =========================
    // VIDEO -> tetap kirim VIDEO
    // =========================
    if (isVideo) {
      const cmdVid =
        `ffmpeg -y -loglevel error -i "${inFile}" ` +
        `-vf "scale=-2:${px}:flags=neighbor,boxblur=2:1" ` +
        `-c:v libx264 -preset veryfast -crf 38 -b:v 150k -maxrate 150k -bufsize 300k ` +
        `-c:a aac -b:a 48k -movflags +faststart "${outVid}"`
      await execAsync(cmdVid)

      const out = fs.readFileSync(outVid)
      await conn.sendMessage(
        m.chat,
        { video: out, caption: `nih burik ${px}p 🤢😹` },
        { quoted: m }
      )
    } else {
      // =========================
      // IMAGE/STICKER -> hasil JPG
      // =========================
      const cmdImg =
        `ffmpeg -y -loglevel error -i "${inFile}" ` +
        `-vf "scale=-2:${px}:flags=neighbor,boxblur=2:1" ` +
        `-q:v 31 "${outImg}"`
      await execAsync(cmdImg)

      const out = fs.readFileSync(outImg)

      // ✅ buriks => kirim STIKER
      if (isStickerMode) {
        const stic = new Sticker(out, {
          pack: global.packname || "CIMMY BOT",
          author: global.author || global.botname || "CIMMY",
          type: StickerTypes.FULL,
          quality: 70
        })

        const buffer = await stic.toBuffer()
        await conn.sendMessage(m.chat, { sticker: buffer }, { quoted: m })
      } else {
        // ✅ burik => kirim IMAGE normal
        await conn.sendMessage(
          m.chat,
          { image: out, caption: `nih burik ${px}p 🤢😹` },
          { quoted: m }
        )
      }
    }
  } catch (e) {
    console.error(e)
    m.reply("Gagal bikin burik.")
  } finally {
    try {
      if (fs.existsSync(inFile)) fs.unlinkSync(inFile)
      if (fs.existsSync(outImg)) fs.unlinkSync(outImg)
      if (fs.existsSync(outVid)) fs.unlinkSync(outVid)
    } catch {}
    await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
  }
}

handler.command = /^(burik|blurik|buriks)$/i
handler.help = ["burik <8p-360p>", "buriks <8p-360p>"]
handler.tags = ["tools"]

export default handler