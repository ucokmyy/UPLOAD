import fetch from "node-fetch"
import { exec } from "child_process"
import fs from "fs"
import path from "path"
import axios from "axios"
import { fileURLToPath } from "url"
import FormData from "form-data"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// =========================
// UPLOAD KE UGUU (BUAT VIDEO)
// =========================
const uploadUguu = async (filePath) => {
  return new Promise((resolve, reject) => {
    exec(`curl -s -F files[]=@${filePath} https://uguu.se/upload.php`, (error, stdout) => {
      if (error) return reject("Gagal upload ke Uguu")
      try {
        const json = JSON.parse(stdout)
        resolve(json.files[0].url)
      } catch {
        reject("Gagal parsing respon Uguu")
      }
    })
  })
}

// =========================
// ILOVEIMG (DEFAULT SCALE 4)
// =========================
async function iloveimg_gettoken() {
  const html = await axios.get("https://www.iloveimg.com/upscale-image").then((r) => r.data)
  const token = html.match(/"token":"(eyJ[^"]+)"/)?.[1]
  const task = html.match(/ilovepdfConfig\.taskId\s*=\s*'([^']+)'/)?.[1]
  if (!token || !task) throw new Error("Gagal ambil token/task iloveimg")
  return { token, task }
}

async function iloveimg_upload(imgPath, token, task) {
  const form = new FormData()
  form.append("name", imgPath.split("/").pop())
  form.append("chunk", "0")
  form.append("chunks", "1")
  form.append("task", task)
  form.append("preview", "1")
  form.append("v", "web.0")
  form.append("file", fs.createReadStream(imgPath))

  const r = await axios.post("https://api29g.iloveimg.com/v1/upload", form, {
    headers: {
      ...form.getHeaders(),
      Authorization: `Bearer ${token}`,
      Origin: "https://www.iloveimg.com",
      Referer: "https://www.iloveimg.com/"
    }
  })

  if (!r.data || !r.data.server_filename) throw new Error("Gagal upload iloveimg")
  return r.data.server_filename
}

async function iloveimg_upscale(imgPath, scale = "4") {
  const config = ["2", "4"]
  if (!config.includes(String(scale))) throw new Error("invalid scale")

  const { token, task } = await iloveimg_gettoken()
  const serverfilename = await iloveimg_upload(imgPath, token, task)

  const form = new FormData()
  form.append("task", task)
  form.append("server_filename", serverfilename)
  form.append("scale", String(scale))

  const r = await axios.post("https://api29g.iloveimg.com/v1/upscale", form, {
    headers: {
      ...form.getHeaders(),
      Authorization: `Bearer ${token}`,
      Origin: "https://www.iloveimg.com",
      Referer: "https://www.iloveimg.com/"
    },
    responseType: "arraybuffer"
  })

  if (!r.data) throw new Error("Gagal upscale iloveimg")
  return Buffer.from(r.data)
}

// =========================
// HANDLER
// =========================
const handler = async (m, { conn, usedPrefix, command }) => {
  const quoted = m.quoted ? m.quoted : m
  const mime = (quoted.msg || quoted).mimetype || ""
  const isImage = /image/.test(mime)
  const isVideo = /video/.test(mime)

  if (!quoted || (!isImage && !isVideo)) {
    return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command}
╠⪼𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶: sertakan foto/video beserta caption ${usedPrefix + command}
╠⪼𝗖𝗮𝘁𝗮𝘁𝗮𝗻: semakin panjang durasi video, maka semakin besar size-nya
║
╚═════════════╝`.trim())
  }

  // PESAN PROSES
  await m.reply(`_✨tunggu yahh, sedang memproses..._`)

  const ext = isImage ? ".jpg" : ".mp4"
  const tempFile = path.join(__dirname, `temp_${Date.now()}${ext}`)

  try {
    const media = await quoted.download()
    fs.writeFileSync(tempFile, media)

    // =========================
    // FOTO: ILOVEIMG SAJA
    // =========================
    if (isImage) {
      const buffer = await iloveimg_upscale(tempFile, "4")
      await conn.sendMessage(
        m.chat,
        {
          image: buffer,
          caption: `✅ *HD Berhasil!*`
        },
        { quoted: m }
      )
      return
    }

    // =========================
    // VIDEO: TETAP API FAA
    // =========================
    if (isVideo) {
      const mediaUrl = await uploadUguu(tempFile)
      if (!mediaUrl) throw "Upload gagal"

      const apiUrl = `https://api-faa.my.id/faa/hdvid?url=${encodeURIComponent(mediaUrl)}`
      const res = await fetch(apiUrl)
      if (!res.ok) throw `HD Video gagal (${res.status})`

      const json = await res.json()
      if (!json.status) throw "API gagal memproses video"

      const dl = await fetch(json.result.download_url)
      const buffer = Buffer.from(await dl.arrayBuffer())

      await conn.sendMessage(
        m.chat,
        {
          video: buffer,
          caption: `✅HD video berhasil\nQuality: *${json.result.quality}*\n\njika video tidak dapat di putar di WhatsApp, silahkan buka di galeri kamu`
        },
        { quoted: m }
      )
    }
  } catch (e) {
    console.error(e)
    m.reply("saat ini fitur sedang tidak bisa di gunakan untuk video, silahkan coba lagi nanti.")
  } finally {
    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile)
  }
}

handler.command = ["hd", "hdin", "remini"]
handler.help = ["hd"]
handler.tags = ["tools"]

export default handler