import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { runtime } from '../../source/myfunc.js';
import { exec } from 'child_process';
import fetch from 'node-fetch';
import sharp from 'sharp';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const COOLDOWN_FILE = path.resolve(__dirname, '../../source/cooldown.json');

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

const ensureCooldownFile = async () => {
  await fs.ensureFile(COOLDOWN_FILE);

  const content = await fs.readFile(COOLDOWN_FILE, 'utf-8');

  if (content.trim() === '') {
    await fs.writeFile(COOLDOWN_FILE, '{}', 'utf-8');
  }
};

async function convert(input) {
  let buffer;

  if (typeof input === 'string') {
    const res = await fetch(input).catch(() => null);

    if (!res || !res.ok) {
      throw new Error(`Gagal download audio (${res?.status || 'offline'})`);
    }

    buffer = await res.buffer();
  } else if (Buffer.isBuffer(input)) {
    buffer = input;
  } else {
    throw new Error('Input harus berupa link atau buffer');
  }

  const tmpIn = path.join(__dirname, `in-${Date.now()}.mp3`);
  const tmpOut = path.join(__dirname, `out-${Date.now()}.opus`);

  await fs.promises.writeFile(tmpIn, buffer);

  await new Promise((resolve, reject) => {
    exec(
      `ffmpeg -y -i "${tmpIn}" -vn -c:a libopus -b:a 128k -ar 48000 -ac 1 "${tmpOut}"`,
      err => (err ? reject(err) : resolve())
    );
  });

  const audio = await fs.promises.readFile(tmpOut);

  await fs.promises.unlink(tmpIn);
  await fs.promises.unlink(tmpOut);

  return audio;
}

const listmenu = directory => {
  const results = [];

  try {
    const entries = fs.readdirSync(directory, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(directory, entry.name);

      if (entry.isDirectory()) {
        results.push(...listmenu(fullPath));
      } else if (entry.isFile() && fullPath.endsWith('.js')) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    console.error(`Gagal membaca direktori: ${directory}`, e);
  }

  return results;
};

const loadPluginsForMenu = async directory => {
  const plugins = [];
  const jsFiles = listmenu(directory);

  for (const filePath of jsFiles) {
    try {
      const cacheBust = Date.now();
      const modulePath = pathToFileURL(filePath).href;

      const module = await import(`${modulePath}?v=${cacheBust}`);

      if (module.default) {
        plugins.push({
          plugin: module.default,
          path: filePath
        });
      }
    } catch (error) {
      console.log(`Gagal memuat plugin untuk menu: ${filePath}`, error);
    }
  }

  return plugins;
};

let musikList = [
  'https://g.top4top.io/m_3748g9kgh1.mp3',
  'https://j.top4top.io/m_37483tazg1.mp3',
  'https://l.top4top.io/m_3748gi8t31.mp3'
];

let handler = async (m, { conn, prefix, reply, botNumber }) => {
  try {
    await ensureCooldownFile();

    if (m.isGroup) {
      const cooldownData = await fs.readJson(COOLDOWN_FILE);

      const lastTime = cooldownData[m.chat] || 0;
      const now = Date.now();

      const cooldown = 2 * 60 * 1000;

      if (now - lastTime < cooldown) {
        return reply(
          'menu hanya dapat di tampilkan setiap 2 menit sekali, dengan alasan untuk menghindari spam'
        );
      }

      cooldownData[m.chat] = now;

      await fs.writeJson(COOLDOWN_FILE, cooldownData, {
        spaces: 2
      });
    }

    const rootDir = process.cwd();
    const cmdDir = path.resolve(rootDir, './cmd');

    const plugins = await loadPluginsForMenu(cmdDir);

    const categories = {};

    const isOwner =
      global.owner.includes(m.sender.split('@')[0]) ||
      global.owner.includes(m.sender);

    for (const { plugin, path: filePath } of plugins) {
      if (!plugin.help || !plugin.command) continue;

      const relativePath = path.relative(cmdDir, filePath);
      const pathParts = relativePath.split(path.sep);

      const tagName = pathParts.length > 1 ? pathParts[0] : 'main';

      if (!categories[tagName]) {
        categories[tagName] = [];
      }

      const helpCommand = plugin.help[0];

      if (
        helpCommand &&
        !categories[tagName].some(p => p.command === helpCommand)
      ) {
        categories[tagName].push({
          command: helpCommand,
          owner: plugin.owner || false
        });
      }
    }

    const sortedCategories = Object.keys(categories).sort();

    let totalCommands = 0;
    let commandListText = '';

    for (const tag of sortedCategories) {
      if (tag.toLowerCase() === 'owner' && !isOwner) continue;

      const commands = categories[tag].filter(
        cmd => !(cmd.owner && !isOwner)
      );

      if (commands.length === 0) continue;

      totalCommands += commands.length;

      const categoryName =
        tag.charAt(0).toUpperCase() + tag.slice(1);

      commandListText += `*📁 ${categoryName} Menu*\n`;

      for (const cmd of commands) {
        commandListText += `❏ ${prefix}${cmd.command}\n`;
      }

      commandListText += '\n';
    }

    if (totalCommands === 0) {
      return reply('Tidak ada perintah menu yang tersedia untuk Anda.');
    }

    const botRuntime = runtime(process.uptime());

    const menuCaption = `
Hi @${m.sender.split("@")[0]} 🧊
𝖺𝗄𝗎 𝖺𝖽𝖺𝗅𝖺𝗁 𝖻𝗈𝗍 𝗐𝗁𝖺𝗍𝗌𝖺𝗉𝗉 𝗌𝗂𝗆𝗉𝖾𝗅 𝗒𝖺𝗇𝗀 𝖽𝗂 𝖼𝗂𝗉𝗍𝖺𝗄𝖺𝗇 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗆𝖻𝖺𝗇𝗍𝗎 𝗎𝗌𝖾𝗋 𝖻𝗈𝗍. 𝖺𝗀𝖺𝗋 𝗅𝖾𝖻𝗂𝗁 𝗆𝗎𝖽𝖺𝗁 𝗆𝖾𝗆𝖻𝗎𝖺𝗍 𝗌𝖾𝗌𝗎𝖺𝗍𝗎 𝖽𝖺𝗅𝖺𝗆 𝖻𝖾𝗇𝗍𝗎𝗄 𝖼𝗈𝗆𝗆𝖺𝗇𝖽/𝗉𝖾𝗋𝗂𝗇𝗍𝖺𝗁 𝗒𝖺𝗇𝗀 𝗌𝗎𝗅𝗂𝗍 𝖽𝗂 𝗅𝖺𝗄𝗎𝗄𝖺𝗇 𝗆𝖺𝗇𝗎𝗌𝗂𝖺. 𝖻𝗈𝗍 𝗂𝗇𝗂 𝖽𝗂 𝖻𝗎𝖺𝗍 𝗌𝖾𝗌𝗂𝗆𝗉𝖾𝗅 𝗆𝗎𝗇𝗀𝗄𝗂𝗇 𝖽𝖺𝗇 𝗅𝖾𝖻𝗂𝗁 𝖿𝗈𝗄𝗎𝗌 𝗄𝖾 𝗄𝖾𝖻𝗎𝗍𝗎𝗁𝖺𝗇 𝗆𝖾𝖽𝗂𝖺📱🌐

𝑟𝑒𝑛𝑎 - 𝐶𝐼𝑀𝑀𝑌 𝐵𝑂𝑇

💬𝗔 𝗟 𝗟  𝗙 𝗜 𝗧 𝗨 𝗥  𝗬 𝗔 𝗡 𝗚  𝗧 𝗘 𝗥 𝗦 𝗘 𝗗 𝗜 𝗔
🗣️"harap gunakan *(.) titik* di awal command"
${readMore}
${commandListText.trim()}

> © 𝑟𝑒𝑦𝑛𝑎𝑟𝑒𝑙𝑖𝑎 - 𝑴𝒀 𝑩𝑶𝑻
`.trim();

    const thumbUrl = 'https://f.top4top.io/p_3748bg4s81.jpg';

    const buffer = await (
      await fetch(thumbUrl)
    ).arrayBuffer().then(b => Buffer.from(b));

    const meta = await sharp(buffer).metadata();

    const { imageMessage: image } = await prepareWAMessageMedia(
      {
        image: buffer
      },
      {
        upload: conn.waUploadToServer,
        mediaTypeOverride: 'thumbnail-link'
      }
    );

    image.height = meta.height || 630;
    image.width = meta.width || 1200;

    await conn.sendMessage(
      m.chat,
      {
        text: `${thumbUrl}\n\n${menuCaption}`,
        mentions: [m.sender],
        linkPreview: {
          'matched-text': thumbUrl,
          title: '𝗋𝖾𝗇𝖺 - 𝖼𝗂𝗆𝗆𝗒 𝗕𝗢𝗧',
          description: '𝗄𝖾𝖻𝗂𝗃𝖺𝗄𝖺𝗇 𝖻𝗈𝗍 𝖺𝖽𝖺𝗅𝖺𝗁 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗆𝖻𝖺𝗇𝗍𝗎 𝗉𝖾𝗇𝗀𝗀𝗎𝗇𝖺𝖺𝗇 𝗇𝗒𝖺',
          previewType: 0,
          jpegThumbnail: buffer,
          highQualityThumbnail: image,
          linkPreviewMetadata: {
            linkMediaDuration: 0,
            socialMediaPostType: 1
          }
        },
        favicon: {
          url: thumbUrl
        }
      },
      {
        quoted: m
      }
    );

    try {
      const fakems = {
        key: {
          fromMe: false,
          participant: botNumber,
          ...(m.from ? { remoteJid: 'status@broadcast' } : {})
        },
        message: {
          extendedTextMessage: {
            text: '`santai, nikmati, dan percaya diri`'
          }
        }
      };

      const musik =
        musikList[Math.floor(Math.random() * musikList.length)];

      const audio = await convert(musik);

      await conn.sendMessage(
        m.chat,
        {
          audio,
          mimetype: 'audio/ogg; codecs=opus',
          ptt: true
        },
        {
          quoted: fakems
        }
      );
    } catch (err) {
      console.warn('ctbx err', err.message);
    }
  } catch (e) {
    console.error(e);
    reply('Gagal membuat menu. Silakan coba lagi.');
  }
};

handler.command = ['menu', 'help'];

export default handler;