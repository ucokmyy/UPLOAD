import fs from "fs";
import path from "path";
import FormData from "form-data";
import fetch from "node-fetch";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function pixa(img) {
  const form = new FormData();
  form.append("image", fs.createReadStream(img));
  form.append("format", "png");
  form.append("model", "v1");

  const res = await fetch("https://api2.pixelcut.app/image/matte/v1", {
    method: "POST",
    headers: {
      ...form.getHeaders(),
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/139.0.0.0 Mobile Safari/537.36",
      Accept: "application/json, text/plain, */*",
      "x-locale": "en",
      "x-client-version": "web:pixa.com:4a5b0af2",
      origin: "https://www.pixa.com",
      referer: "https://www.pixa.com/"
    },
    body: form
  });

  return Buffer.from(await res.arrayBuffer());
}

const handler = async (m, { conn, usedPrefix, command }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    if (!/image\/(jpe?g|png)/.test(mime)) {
      return conn.sendMessage(
        m.chat,
        { text: `Reply atau kirim foto dengan command:\n${usedPrefix + command}` },
        { quoted: m }
      );
    }

    await conn.sendMessage(
      m.chat,
      { text: "_Menghapus background..._" },
      { quoted: m }
    );

    let media = await q.download();
    let temp = path.join(__dirname, `${Date.now()}.jpg`);
    fs.writeFileSync(temp, media);

    let result = await pixa(temp);
    fs.unlinkSync(temp);

    await conn.sendMessage(
      m.chat,
      {
        image: result,
        caption: "✅ Background berhasil dihapus!"
      },
      { quoted: m }
    );
  } catch (e) {
    console.log("REMOVE BG ERROR:", e);
    conn.sendMessage(
      m.chat,
      { text: "❌ Gagal menghapus background gambar." },
      { quoted: m }
    );
  }
};

handler.help = ["removebg", "nobg"];
handler.tags = ["tools"];
handler.command = /^removebg|nobg$/i;

export default handler;