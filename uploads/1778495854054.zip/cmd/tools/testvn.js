import { exec } from "child_process"
import { promisify } from "util"
import fs from "fs"
import path from "path"
import fetch from "node-fetch"

const execAsync = promisify(exec)

async function convertBufferToOpusPTT(buffer) {
  const tmpIn = path.join(process.cwd(), `in-${Date.now()}.tmp`)
  const tmpOut = path.join(process.cwd(), `out-${Date.now()}.opus`)

  await fs.promises.writeFile(tmpIn, buffer)

  await execAsync(
    `ffmpeg -y -i "${tmpIn}" -vn -c:a libopus -b:a 128k -ar 48000 -ac 1 "${tmpOut}"`
  )

  const audio = await fs.promises.readFile(tmpOut)
  await fs.promises.unlink(tmpIn).catch(() => {})
  await fs.promises.unlink(tmpOut).catch(() => {})

  return audio
}

async function convertToOpusPTT(input) {
  // input bisa URL atau Buffer
  let buffer
  if (typeof input === "string") {
    const res = await fetch(input).catch(() => null)
    if (!res || !res.ok) throw new Error(`Gagal download audio (${res?.status || "offline"})`)
    buffer = await res.buffer()
  } else if (Buffer.isBuffer(input)) {
    buffer = input
  } else {
    throw new Error("Input harus berupa link atau buffer")
  }

  return convertBufferToOpusPTT(buffer)
}

const handler = async (m, { conn, args, usedPrefix, command, reply }) => {
  try {
    // =========================
    // MODE 1: REPLY AUDIO/VIDEO
    // =========================
    if (!args?.[0] && m.quoted) {
      const q = m.quoted
      const mime = (q.msg || q).mimetype || ""

      if (!/audio|video/.test(mime)) {
        return reply("Reply audio/mp3 atau video yang mau dijadiin VN, atau kasih link audio.")
      }

      const media = await q.download()
      if (!media) return reply("Gagal download media reply.")

      const audio = await convertToOpusPTT(media)
      await conn.sendMessage(
        m.chat,
        { audio, mimetype: "audio/ogg; codecs=opus", ptt: true },
        { quoted: m }
      )
      return
    }

    // =========================
    // MODE 2: VIA LINK (FUNGSI UTAMA)
    // =========================
    const url = args?.[0]
    if (!url) {
      return reply(
        `Contoh:\n` +
        `${usedPrefix + command} https://contoh.com/audio.mp3\n\n` +
        `Atau:\nReply audio/video lalu ketik *${usedPrefix + command}*`
      )
    }

    if (!/^https?:\/\//i.test(url)) return reply("Link harus diawali http/https.")

    const audio = await convertToOpusPTT(url)
    await conn.sendMessage(
      m.chat,
      { audio, mimetype: "audio/ogg; codecs=opus", ptt: true },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    reply(`Gagal bikin VN:\n${e.message}`)
  }
}

handler.command = ["testvn", "tvn"]
handler.owner = false
handler.help = ["testvn"]
handler.tags = ["tools"]

export default handler