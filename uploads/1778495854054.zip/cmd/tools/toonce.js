import { exec } from 'child_process'
import fs from 'fs'
import path from 'path'
import fetch from 'node-fetch'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

async function convert(input) {
  try {
    let buffer

    if (typeof input === 'string') {
      const res = await fetch(input)
      if (!res.ok) throw new Error(`Gagal download: ${res.statusText}`)
      buffer = await res.buffer()

    } else if (Buffer.isBuffer(input)) {
      buffer = input

    } else {
      throw new Error('Input harus berupa url atau buffer')
    }

    const tmpIn = path.join(__dirname, `in-${Date.now()}.mp3`)
    const tmpOut = path.join(__dirname, `out-${Date.now()}.opus`)

    fs.writeFileSync(tmpIn, buffer)

    await new Promise((resolve, reject) => {
      exec(`ffmpeg -y -i "${tmpIn}" -vn -c:a libopus -b:a 128k -ar 48000 -ac 1 "${tmpOut}"`,
        (err) => err ? reject(err) : resolve()
      )
    })

    const audio = fs.readFileSync(tmpOut)
    fs.unlinkSync(tmpIn)
    fs.unlinkSync(tmpOut)

    return audio
  } catch (e) {
    throw new Error(`Convert Error: ${e.message}`)
  }
}

const handler = async (m, { conn, prefix, command, reply }) => {
  try {
    const quoted = m.quoted ? m.quoted : m
    if (!quoted) return reply(`Reply Image/Video/Audio`)

    let mime = (quoted.msg || quoted).mimetype || ''
    if (!mime) return reply(`reply foto/video/audio`)

    if (/image/.test(mime)) {
      let media = await quoted.download?.()
      await conn.sendMessage(m.chat, {
        image: media,
        caption: "done",
        viewOnce: true
      }, { quoted: m })

    } else if (/video/.test(mime)) {
      let media = await quoted.download?.()
      await conn.sendMessage(m.chat, {
        video: media,
        caption: "done",
        viewOnce: true
      }, { quoted: m })

    } else if (/audio/.test(mime)) {
      let media = await quoted.download?.()
      let audio = await convert(media)
      await conn.sendMessage(m.chat, {
        audio,
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true,
        viewOnce: true
      }, { quoted: m })

    } else {
      return reply(`File tidak didukung`)
    }

  } catch (e) {
    console.error(e)
    reply(`error: ${e.message}`)
  }
}

handler.command = /^(toonce|viewonce|vonce|sv1)$/
handler.tags = ["tools"]
handler.help = ["toonce"]
export default handler