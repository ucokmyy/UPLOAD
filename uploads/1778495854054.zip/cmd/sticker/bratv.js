import fetch from "node-fetch"
import moment from "moment-timezone"
import fs from "fs-extra"
import path from "path"
import { fileURLToPath } from "url"
import { makeStickerFromUrl } from "../../source/events/_sticker.js"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const COOLDOWN_FILE = path.resolve(__dirname, "../../source/bratv.json")

const ensureCooldownFile = async () => {
  await fs.ensureFile(COOLDOWN_FILE)
  const content = await fs.readFile(COOLDOWN_FILE, "utf-8")
  if (content.trim() === "") {
    await fs.writeFile(COOLDOWN_FILE, "{}", "utf-8")
  }
}

async function fetchVideoBuffer(url) {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`API error (${res.status})`)
  const buf = Buffer.from(await res.arrayBuffer())
  if (!buf || buf.length < 50) throw new Error("Empty result")
  return buf
}

const handler = async (m, { conn, args, command, prefix, reply }) => {
  await ensureCooldownFile()

  const commandName = "bratv"
  const cooldownKey = m.isGroup ? m.chat : m.sender
  const cooldown = 10 * 1000

  const allCooldownData = await fs.readJson(COOLDOWN_FILE)
  if (!allCooldownData[commandName]) allCooldownData[commandName] = {}

  const lastTime = allCooldownData[commandName][cooldownKey] || 0
  const now = Date.now()

  if (now - lastTime < cooldown) {
    return reply("jangan spam, harap tunggu 10 detik")
  }

  const text = args.join(" ")
  if (!text) {
    return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${prefix + command} (brat video)
╠⪼ 𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶: sertakan teks
╠⪼ 𝗖𝗼𝗻𝘁𝗼𝗵: ${prefix + command} halo cuy
║
╚═════════════╝`)
  }

  allCooldownData[commandName][cooldownKey] = now
  await fs.writeJson(COOLDOWN_FILE, allCooldownData, { spaces: 2 })

  await conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } })

  try {
    // =========================
    // ZENX = API UTAMA (ada delay)
    // =========================
    const zenxUrl =
      `https://api.zenzxz.my.id/api/maker/bratvid?text=` +
      encodeURIComponent(text) +
      `&isAnimated=true&delay=500`

    let buffer
    try {
      buffer = await fetchVideoBuffer(zenxUrl)
    } catch (e) {
      // =========================
      // RHNX = CADANGAN (tanpa delay)
      // =========================
      const rhnxUrl =
        `https://brat.siputzx.my.id/gif?text=` +
        encodeURIComponent(text)

      buffer = await fetchVideoBuffer(rhnxUrl)
    }

    const mime = "video/mp4"
    const videoUrl = `data:${mime};base64,${buffer.toString("base64")}`

    await makeStickerFromUrl(videoUrl, conn, m, reply)
  } catch (e) {
    console.log(e)
    m.reply("Gagal membuat stiker brat video!")
  }

  await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
}

handler.help = ["bratv"]
handler.tags = ["sticker"]
handler.command = ["bratv", "bratvid", "vbrat", "bratvideo", "videobrat", "vidbrat"]

export default handler