import { Sticker } from 'wa-sticker-formatter'
import Jimp from 'jimp'

async function handler(m, { conn, text, command, prefix }) {
  try {
    if (!text) return m.reply(`_harap masukkan emoji_\n_Contoh: *${prefix + command} 😜*_\n_emoji bisa lebih dari 1 *${prefix + command} ✊😜👊*_`)

    let cleanText = text.replace(/\s+/g, '')
    let segmenter = new Intl.Segmenter('id', { granularity: 'grapheme' })
    let emojis = Array.from(segmenter.segment(cleanText)).map(s => s.segment)

    if (emojis.length > 5) return m.reply("_Maksimal 5 emoji saja agar tidak kekecilan_")

    let images = []

    for (let emoji of emojis) {
      let url = `https://emojicdn.elk.sh/${encodeURIComponent(emoji)}?style=apple`
      try {
        let img = await Jimp.read(url)
        images.push(img)
      } catch (err) {
        return m.reply(`Emoji ${emoji} tidak ditemukan\nSilakan pakai Emoji lain`)
      }
    }

    if (images.length === 0) return

    const STICKER_SIZE = 512
    const numEmojis = images.length
    const targetWidthPerEmoji = Math.floor((STICKER_SIZE - 20) / numEmojis)

    let totalResizedWidth = 0
    let maxResizedHeight = 0

    for (let img of images) {
      img.resize(targetWidthPerEmoji, Jimp.AUTO)
      totalResizedWidth += img.bitmap.width
      if (img.bitmap.height > maxResizedHeight) {
        maxResizedHeight = img.bitmap.height
      }
    }

    let baseCanvas = new Jimp(STICKER_SIZE, STICKER_SIZE, 0x00000000)

    let currentX = Math.floor((STICKER_SIZE - totalResizedWidth) / 2)
    let startY = Math.floor((STICKER_SIZE - maxResizedHeight) / 2)

    for (let img of images) {
      let yOffset = startY + Math.floor((maxResizedHeight - img.bitmap.height) / 2)
      baseCanvas.composite(img, currentX, yOffset)
      currentX += img.bitmap.width
    }

    let combinedBuffer = await baseCanvas.getBufferAsync(Jimp.MIME_PNG)

    let sticker = new Sticker(combinedBuffer, {
      pack: "Emoji iPhone Sticker",
      author: "generate by cimmy bot",
      type: "full",
      background: "transparent",
      quality: 80
    })

    let buffer = await sticker.toBuffer()

    await conn.sendMessage(
      m.chat,
      { sticker: buffer },
      { quoted: m }
    )

  } catch (e) {
    console.log(e)
    return m.reply(`errrror: ${e.message}`)
  }
}

handler.command = ["imoji"]
handler.tags = ["sticker"]
handler.help = ["imoji"]

export default handler