import axios from "axios"
import { imageToWebp, writeExifImg } from "../../source/events/exif.js"

const handler = async (m, { conn, args, prefix, command }) => {
  const pushname = m.pushName || "Pengguna"

  // =========================
  // LIST WARNA BARU (API)
  // =========================
  const validColors = [
    "red","blue","green","yellow","black","white","purple","brown","orange",
    "cyan","magenta","fuchsia","lime","indigo","violet","gold","silver",
    "beige","turquoise","peach","salmon","mint","lavender","chartreuse",
    "khaki","plum","olive","orchid","sienna","tomato","tan","snow","azure",
    "slategray","royalblue","navy","maroon","teal","lavenderblush","gray","grey",
    "pink"
  ]

  // =========================
  // MAP WARNA INDONESIA
  // =========================
  const indoColorMap = {
    "merah": "red",
    "merah muda": "pink",
    "pink": "pink",
    "biru": "blue",
    "hijau": "green",
    "kuning": "yellow",
    "hitam": "black",
    "putih": "white",
    "ungu": "purple",
    "coklat": "brown",
    "oranye": "orange",
    "jingga": "orange",
    "cyan": "cyan",
    "magenta": "magenta",
    "lime": "lime",
    "nila": "indigo",
    "violet": "violet",
    "emas": "gold",
    "perak": "silver",
    "krem": "beige",
    "toska": "turquoise",
    "peach": "peach",
    "salmon": "salmon",
    "mint": "mint",
    "lavender": "lavender",
    "chartreuse": "chartreuse",
    "khaki": "khaki",
    "plum": "plum",
    "zaitun": "olive",
    "olive": "olive",
    "orchid": "orchid",
    "sienna": "sienna",
    "tomat": "tomato",
    "tan": "tan",
    "salju": "snow",
    "biru langit": "azure",
    "abu": "gray",
    "abu abu": "gray",
    "abu-abu": "gray",
    "abu tua": "slategray",
    "biru royal": "royalblue",
    "biru laut": "navy",
    "marun": "maroon",
    "teal": "teal",
    "lavender blush": "lavenderblush"
  }

  if (!args.length && !m.quoted?.text) {
    return m.reply(`╔══⪻ 𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆 ⪼══╗
║ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${prefix + command}
║ 𝗖𝗮𝗿𝗮 𝗽𝗮𝗸𝗮𝗶: ${prefix + command} [warna] teks
║ 𝗖𝗼𝗻𝘁𝗼𝗵: ${prefix + command} biru laut halo
║            ${prefix + command} halo
╚═════════════════╝

Ketik *.listwarna* untuk melihat warna apa saja yang bisa digunakan`)
  }

  let rawInput = args.length
    ? args.join(" ")
    : m.quoted?.text

  if (rawInput.length > 1000)
    return m.reply("Maksimal 1000 karakter.")

  let words = rawInput.trim().toLowerCase().split(" ")
  let color = "black"
  let text = rawInput.trim()

  // =========================
  // CEK 2 KATA PERTAMA
  // =========================
  if (words.length >= 2) {
    const twoWords = words[0] + " " + words[1]

    if (indoColorMap[twoWords]) {
      color = indoColorMap[twoWords]
      text = words.slice(2).join(" ")
    } else if (validColors.includes(twoWords.replace(" ", ""))) {
      color = twoWords.replace(" ", "")
      text = words.slice(2).join(" ")
    }
  }

  // =========================
  // CEK 1 KATA
  // =========================
  if (color === "black") {
    const firstWord = words[0]

    if (indoColorMap[firstWord]) {
      color = indoColorMap[firstWord]
      text = words.slice(1).join(" ")
    } else if (validColors.includes(firstWord)) {
      color = firstWord
      text = words.slice(1).join(" ")
    }
  }

  if (!text.trim()) return m.reply("Teks tidak boleh kosong setelah warnanya.")

  let ppUser
  try {
    ppUser = await conn.profilePictureUrl(m.sender, "image")
  } catch {
    ppUser =
      "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"
  }

  try {
    const url = `https://api.deline.web.id/maker/qc?text=${encodeURIComponent(
      text
    )}&color=${encodeURIComponent(color)}&avatar=${encodeURIComponent(
      ppUser
    )}&nama=${encodeURIComponent(pushname)}`

    const res = await axios.get(url, {
      responseType: "arraybuffer",
      timeout: 25000
    })

    if (!res.data || res.data.length < 100)
      throw new Error("INVALID_COLOR")

    const webpBuffer = await imageToWebp(res.data)

    const exifSticker = await writeExifImg(webpBuffer, {
      packname: global.packname || "Cmy",
      author: global.author || "Bot"
    })

    await conn.sendMessage(
      m.chat,
      { sticker: { url: exifSticker } },
      { quoted: m }
    )
  } catch (err) {
    console.error("QC Error:", err)
    return m.reply("Terjadi kesalahan saat membuat sticker.")
  }
}

handler.help = ["qc"]
handler.tags = ["sticker"]
handler.command = ["qc", "quotly"]

export default handler