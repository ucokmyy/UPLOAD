import fs from "fs";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

function getRandom(ext) {
  return `${Math.floor(Math.random() * 10000)}${ext}`;
}

let handler = async (m, { conn, command, usedPrefix }) => {
  try {
    if (!m.quoted) return m.reply("reply stiker yang ingin di jadiin gambar");

    const q = m.quoted;
    const mime = (q.msg || q).mimetype || "";

    if (!/webp/.test(mime))
      return m.reply(`Reply sticker dengan teks *${usedPrefix + command}*`);

    // 🛑 CEK STIKER GERAK / GIF
    const qmsg = q.msg || q;
    if (qmsg.isAnimated) {
      return m.reply("stiker yang gerak ngk bisa di jadiin foto cuy, pake .tovideo");
    }

    // ✅ DOWNLOAD STIKER
    const media = await q.download();
    if (!media) return m.reply("Gagal download stiker.");

    // Simpan dengan path absolut biar ffmpeg nggak rewel
    const input = path.join(process.cwd(), getRandom(".webp"));
    const output = path.join(process.cwd(), getRandom(".png"));

    fs.writeFileSync(input, media);

    try {
      // -y = overwrite, -loglevel error biar nggak spam
      await execAsync(`ffmpeg -y -loglevel error -i "${input}" "${output}"`);
    } catch (err) {
      console.error("toimg ffmpeg error:", err);
      fs.existsSync(input) && fs.unlinkSync(input);
      return m.reply(
        "Stiker ini nggak bisa diubah ke foto.\n" +
        "Biasanya karena format stikernya nggak didukung ffmpeg (sering kejadian di stiker buatan WhatsApp).\n\n" +
        "Coba di jadiin .s dulu baru .toimg"
      );
    }

    if (!fs.existsSync(output)) {
      fs.existsSync(input) && fs.unlinkSync(input);
      return m.reply("Gagal mengubah stiker ke foto.");
    }

    const buffer = fs.readFileSync(output);
    await conn.sendMessage(m.chat, { image: buffer }, { quoted: m });

    fs.unlinkSync(input);
    fs.unlinkSync(output);
  } catch (e) {
    console.error(e);
    m.reply("Terjadi error saat mengubah stiker.");
  }
};

handler.help = ["toimg"];
handler.tags = ["sticker"];
handler.command = ["toimg"];

export default handler;