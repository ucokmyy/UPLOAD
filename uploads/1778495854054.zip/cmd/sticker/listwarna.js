const handler = async (m) => {

  const warnaIndo = [
    "merah",
    "merah muda",
    "pink",
    "biru",
    "hijau",
    "kuning",
    "hitam",
    "putih",
    "ungu",
    "coklat",
    "oranye",
    "cyan",
    "magenta",
    "lime",
    "nila",
    "violet",
    "emas",
    "perak",
    "krem",
    "toska",
    "peach",
    "salmon",
    "mint",
    "lavender",
    "chartreuse",
    "khaki",
    "plum",
    "zaitun",
    "orchid",
    "sienna",
    "tomat",
    "tan",
    "salju",
    "biru langit",
    "abu",
    "abu abu",
    "abu tua",
    "biru royal",
    "biru laut",
    "marun",
    "teal",
    "lavender blush"
  ]

  let teks = `🎨 *DAFTAR WARNA QC*

Gunakan format:
.qc [warna] teks

Contoh:
.qc biru halo
.qc biru laut halo
.qc halo (default hitam)

────────────────────

`

  teks += warnaIndo.map(w => `❏ ${w}`).join("\n")

  m.reply(teks)
}

handler.help = ["listwarna"]
handler.tags = ["sticker"]
handler.command = ["listwarna", "warnaqc"]

export default handler