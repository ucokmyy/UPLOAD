import fs from "fs"
import { Sticker, StickerTypes } from "wa-sticker-formatter"

const handler = async (m, { conn, args, command }) => {
  if (m.quoted?.viewOnce)
    return m.reply("Tidak mendukung media sekali lihat")

  if (!m.quoted)
    return m.reply(`Reply stiker yang ingin di ganti ${command}nya`)

  // =========================
  // PARSE INPUT
  // =========================
  const text = args.join(" ")
  let packname = ""
  let author = ""

  if (text.includes("|")) {
    const split = text.split("|")
    packname = split[0]?.trim() || ""
    author = split[1]?.trim() || ""
  } else {
    packname = text.trim() || ""
    author = ""
  }

  try {
    const media = await m.quoted.download()
    if (!media) return m.reply("Gagal mengunduh media.")

    const sticker = new Sticker(media, {
      pack: packname,
      author: author,
      type: StickerTypes.FULL,
      categories: ["🤩", "🎉"],
      id: "12345",
      quality: 70,
      background: "#FFFFFF00"
    })

    const buffer = await sticker.toBuffer()
    await conn.sendMessage(
      m.chat,
      { sticker: buffer },
      { quoted: m }
    )

  } catch (e) {
    console.error("Error sticker/wm.js:", e)
    m.reply("Terjadi error saat membuat stiker.")
  }
}

handler.help = ["wm"]
handler.tags = ["sticker"]
handler.command = ["scolong", "wm"]

export default handler