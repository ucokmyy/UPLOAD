import { Sticker, StickerTypes } from "wa-sticker-formatter"

const handler = async (m, { conn }) => {
  if (m.quoted?.viewOnce)
    return m.reply("Tidak mendukung media sekali lihat")

  if (!m.quoted)
    return m.reply("Reply stiker yang ingin dihapus watermarknya")

  try {
    const media = await m.quoted.download()
    if (!media) return m.reply("Gagal mengunduh stiker.")

    const sticker = new Sticker(media, {
      pack: "",
      author: "",
      type: StickerTypes.FULL,
      quality: 70,
      background: "#FFFFFF00"
    })

    const buffer = await sticker.toBuffer()

    await conn.sendMessage(
      m.chat,
      { sticker: buffer },
      { quoted: m }
    )

  } catch (e) {
    console.error("Error sticker/delwm.js:", e)
    m.reply("Gagal menghapus watermark stiker.")
  }
}

handler.help = ["delwm"]
handler.tags = ["sticker"]
handler.command = ["delwm", "nowm", "unwm"]

export default handler