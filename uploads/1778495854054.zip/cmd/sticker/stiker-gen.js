import { makeStickerFromUrl } from "../../source/events/_sticker.js"

const handler = async (m, { conn, reply, prefix, command }) => {
  const quotedMessage = m.quoted ? m.quoted : m
  const mime = (quotedMessage.msg || quotedMessage).mimetype || ""

  if (!/image|video/.test(mime)) {
    return reply(`Reply sebuah gambar/video dengan caption ${prefix}${command}`)
  }

  try {
    if (/image/.test(mime)) {
      const media = await quotedMessage.download()
      const imageUrl = `data:${mime};base64,${media.toString("base64")}`
      await makeStickerFromUrl(imageUrl, conn, m, reply)

    } else if (/video/.test(mime)) {
      const seconds = (quotedMessage?.msg || quotedMessage)?.seconds || 0
      if (seconds > 10) return reply("Durasi video maksimal 10 detik!")

      const media = await quotedMessage.download()
      const videoUrl = `data:${mime};base64,${media.toString("base64")}`
      await makeStickerFromUrl(videoUrl, conn, m, reply)
    }

  } catch (error) {
    console.error(error)
    return reply("Terjadi kesalahan saat memproses media. Coba lagi.")
  }
}

handler.command = ["s", "sticker", "stiker", "stc", "st", "stik"]
handler.help = ["stiker (foto jadi stiker)"]
handler.tags = ["sticker"]

export default handler