import fs from 'fs'
import path from 'path'
import { Canvas, loadImage } from 'skia-canvas'
import { Sticker } from 'wa-sticker-formatter'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

async function generateTtp(inputText) {
  const width = 400
  const height = 400

  const canvas = new Canvas(width, height)
  const ctx = canvas.getContext('2d')

  ctx.clearRect(0, 0, width, height)

  const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu
  const emojis = inputText.match(emojiRegex) || []
  const text = inputText.replace(emojiRegex, '').trim()
  const selectedEmojis = emojis.slice(0, 3)
  const words = text.split(' ')

  let fsize = 80
  let lines = []
  const gap = 10

  while (fsize > 20) {
    ctx.font = `bold ${fsize}px Arial`
    lines = []
    let line = ''
    let exceedsWidth = false
    const expectedEmojiWidth = selectedEmojis.length > 0 ? (fsize * selectedEmojis.length) + (gap * selectedEmojis.length) : 0

    for (let word of words) {
      if (!word) continue
      if (ctx.measureText(word).width > width - 40) exceedsWidth = true
      const test = line + word + ' '
      if (ctx.measureText(test).width > width - 40 && line !== '') {
        lines.push(line.trim())
        line = word + ' '
      } else {
        line = test
      }
    }

    if (line.trim() !== '') {
      let lastLineWidth = ctx.measureText(line.trim()).width
      if (lastLineWidth + expectedEmojiWidth > width - 40) {
        if (expectedEmojiWidth > width - 40) exceedsWidth = true
        lines.push(line.trim())
        lines.push('')
      } else {
        lines.push(line.trim())
      }
    } else if (selectedEmojis.length > 0) {
      if (expectedEmojiWidth > width - 40) exceedsWidth = true
      lines.push('')
    }

    const totalHeight = lines.length * fsize
    if (totalHeight <= height - 40 && !exceedsWidth) {
      break
    }

    fsize -= 10
  }

  ctx.fillStyle = 'white'
  ctx.textBaseline = 'middle'

  const emojiImgs = await Promise.all(
    selectedEmojis.map(async (emj) => {
      try {
        const emojiUrl = `https://emojicdn.elk.sh/${encodeURIComponent(emj)}?style=apple`
        return await loadImage(emojiUrl)
      } catch (e) {
        return null
      }
    })
  ).then(imgs => imgs.filter(img => img !== null))

  const totalHeight = lines.length * fsize
  let y = (height - totalHeight) / 2 + fsize / 2
  const emojiSize = fsize

  for (let i = 0; i < lines.length; i++) {
    const l = lines[i]
    const isLastLine = i === lines.length - 1
    const lineWidth = ctx.measureText(l).width

    let totalLineWidth = lineWidth
    let addedEmojiWidth = 0

    if (isLastLine && emojiImgs.length > 0) {
      addedEmojiWidth = (emojiSize * emojiImgs.length) + (gap * (emojiImgs.length - 1))
      if (lineWidth > 0) addedEmojiWidth += gap
      totalLineWidth += addedEmojiWidth
    }

    const startX = (width - totalLineWidth) / 2

    ctx.textAlign = 'left'
    ctx.fillText(l, startX, y)

    if (isLastLine && emojiImgs.length > 0) {
      let currentEmojiX = startX + lineWidth + (lineWidth > 0 ? gap : 0)
      const emojiY = y - emojiSize / 2
      
      for (const img of emojiImgs) {
        ctx.drawImage(img, currentEmojiX, emojiY, emojiSize, emojiSize)
        currentEmojiX += emojiSize + gap
      }
    }

    y += fsize
  }

  return await canvas.png
}

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('_harap masukkan teks_\n_contoh: *.ttp aku sebenarnya begini cuman ya begini aja*_')

  try {
    const buffer = await generateTtp(text)

    const sticker = new Sticker(buffer, {  
      pack: global.packname,  
      author: global.author,  
      type: 'full',  
      quality: 100,  
      background: 'transparent'  
    })  

    await conn.sendMessage(  
      m.chat,  
      await sticker.toMessage(),  
      { quoted: m }  
    )

  } catch (err) {
    console.error(err)
    m.reply('gagal membuat sticker, silahkan coba lagi nanti')
  }
}

handler.command = ['ttp']
handler.tags = ['sticker']
handler.help = ['ttp <text>']

export default handler