import fs from "fs";
import { exec } from "child_process";
import { Sticker, StickerTypes } from "wa-sticker-formatter";

async function uploadUguu(filePath) {
    return new Promise((resolve, reject) => {
        exec(`curl -s -F files[]=@${filePath} https://uguu.se/upload.php`, (err, stdout) => {
            if (err) return reject("Gagal upload ke Uguu");
            try {
                const json = JSON.parse(stdout);
                resolve(json.files[0].url);
            } catch {
                reject("Upload gagal parsing");
            }
        });
    });
}

const handler = async (m, { conn, usedPrefix, command }) => {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    const text = m.text?.split(" ").slice(1).join(" ");

    if (!/image|webp/.test(mime)) return m.reply(`Kirim/reply gambar dengan format:\n${usedPrefix + command} teks|teks`);
    if (!text) return m.reply(`Contoh: ${usedPrefix + command} teks atas|teks bawah`);

    try {
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        if (!fs.existsSync("./temp")) fs.mkdirSync("./temp", { recursive: true });

        const [atas, bawah] = text.split("|");
        const media = await quoted.download();
        const tmpFile = `./temp/${Date.now()}.jpg`;

        fs.writeFileSync(tmpFile, media);

        const upl = await uploadUguu(tmpFile);
        const img = `https://api.memegen.link/images/custom/${encodeURIComponent(atas || "-")}/${encodeURIComponent(bawah || "-")}.png?background=${encodeURIComponent(upl)}`;

        const stc = new Sticker(img, {
            pack: "CIMMY",
            author: "Ren 🤏",
            type: StickerTypes.FULL,
            categories: ["🫩"],
            id: Date.now(),
            quality: 70,
            background: "transparent"
        });

        const buffer = await stc.toBuffer();
        await conn.sendMessage(m.chat, { sticker: buffer }, { quoted: m });

        fs.unlinkSync(tmpFile);
        await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });

    } catch (e) {
        m.reply(`error: ${e}`);
    }
};

handler.help = ["smeme <teks>|<teks>"];
handler.tags = ["sticker"];
handler.command = ["smeme"];

export default handler;