import axios from "axios"
import * as cheerio from "cheerio"
import fs from "fs"
import { exec } from "child_process"
import path from "path"

function uploadUguu(filePath) {
    return new Promise((resolve, reject) => {
        exec(`curl -s -F files[]=@${filePath} https://uguu.se/upload.php`, (error, stdout) => {
            if (error) return reject("gagal upload ke Uguu")
            try {
                let json = JSON.parse(stdout)
                resolve(json.files[0].url)
            } catch {
                reject("gagal parsing hasil upload")
            }
        })
    })
}

async function webpToMp4(url) {
    let res1 = await axios.post(
        "https://ezgif.com/webp-to-mp4",
        new URLSearchParams({
            "new-image-url": url,
            upload: "Upload!"
        }).toString(),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    )

    let $ = cheerio.load(res1.data)
    let formAction = $("form[action*='webp-to-mp4']").attr("action")
    let file = $("input[name=file]").val()
    if (!formAction || !file) throw "gagal ambil form convert"
    if (!formAction.startsWith("http")) formAction = "https://ezgif.com" + formAction

    let res2 = await axios.post(
        formAction,
        new URLSearchParams({
            file,
            convert: "Convert WebP to MP4!"
        }).toString(),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    )

    $ = cheerio.load(res2.data)
    let mp4src = $("video > source").attr("src")
    if (!mp4src) throw "MP4 tidak ditemukan"
    if (!mp4src.startsWith("http")) mp4src = "https:" + mp4src
    return mp4src
}

const handler = async (m, { conn, command, usedPrefix }) => {
    if (!m.quoted || !/webp/.test(m.quoted.mimetype))
        return m.reply(`reply stiker gerak dengan command ${usedPrefix + command}`)
    const buffer = await m.quoted.download()
    const mediaPath = path.join("./", Date.now() + ".webp")
    fs.writeFileSync(mediaPath, buffer)

    try {
        let urlUguu = await uploadUguu(mediaPath)
        let videoUrl = await webpToMp4(urlUguu)
        await conn.sendMessage(
            m.chat,
            { video: { url: videoUrl }, caption: "Done" },
            { quoted: m }
        )
    } catch (e) {
        m.reply(String(e))
    } finally {
        if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath)
    }
}

handler.command = ["tovideo"]
handler.help = ["tovideo"]
handler.tags = ["sticker"]
export default handler