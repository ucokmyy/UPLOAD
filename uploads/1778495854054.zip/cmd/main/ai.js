import axios from "axios"
import { exec } from "child_process"
import { promisify } from "util"
import fs from "fs"
import path from "path"
import fetch from "node-fetch"

const execAsync = promisify(exec)

// =========================
// CONVERT BUFFER -> OPUS PTT
// =========================
async function convertBufferToOpusPTT(buffer) {
  const tmpIn = path.join(process.cwd(), `in-${Date.now()}.tmp`)
  const tmpOut = path.join(process.cwd(), `out-${Date.now()}.opus`)

  await fs.promises.writeFile(tmpIn, buffer)

  await execAsync(
    `ffmpeg -y -i "${tmpIn}" -vn -c:a libopus -b:a 128k -ar 48000 -ac 1 "${tmpOut}"`
  )

  const audio = await fs.promises.readFile(tmpOut)

  await fs.promises.unlink(tmpIn).catch(() => {})
  await fs.promises.unlink(tmpOut).catch(() => {})

  return audio
}

// =========================
// FETCH TTS (CEWEK)
// =========================
async function fetchAnabotTTS(text) {
  const apikey = "freeApikey"
  const url = `https://anabot.my.id/api/ai/text2voice?text=${encodeURIComponent(text)}&apikey=${apikey}`

  const { data } = await axios.get(url)

  if (!data.success || !data.data || !data.data.result) {
    throw new Error("API TTS error")
  }

  const audioUrl = data.data.result
  const audioRes = await axios.get(audioUrl, { responseType: "arraybuffer" })

  return Buffer.from(audioRes.data)
}

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("iyaa? Ada yang bisa di bantu?")

  const systemPrompt = `Kamu adalah ai yang cerdas. Gaya bicara kamu santai dan akrab kayak temen, pakai campuran kata gua, lu, aku, kamu sesuai konteks biar natural. Kalau user lagi ngobrol biasa dan tidak butuh penjelasan apa apa yang serius, kamu wajib jawab singkat, to the point, dan jelas, cukup 1–2 kalimat kalau sudah menjawab maksudnya.    

Bahasa lu ngk usah formal banget, kasih jawaban yang cukup panjang tapi jangan terlalu panjang hingga membuat orang malas baca, jangan bikin kalimat menyambung terus terusan, kasih jarak/enter antar paragraf, intinya ngomong jangan terlalu kaku, apalagi kalo kasih penjelasan, santai aja.

jangan menggunakan simbol asteris * di sorotan teks pakai font gede aja berikut font nya: 𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭 - 𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇, dan kalau kamu menyebut angka jangan pakai angka biasa, gunakan kalimat, misalnya 1 ubah jadi satu, jangan gunakan angka biasa, ubah ke teks, dalam percakapan apapun.

untuk codingan atau javascript, mohon gunakan tanda kutip seperti ini \`\`\`code\`\`\`

Kamu nggak boleh pakai emoji di semua percakapan, dan kamu hanya boleh pakai emoji kalau jawaban kamu panjang atau penjelasan rumit, itu pun secukupnya dan jangan kebanyakan. Untuk jawaban singkat atau ngobrol biasa, tanpa emoji.`

  const url = `https://api.shinzu.web.id/api/ai-chat/gemini?prompt=${encodeURIComponent(text)}&system=${encodeURIComponent(systemPrompt)}`

  try {
    // =========================
    // 1. AI RESPONSE
    // =========================
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" }
    })

    const json = await res.json()

    if (!json.status || !json.data || !json.data.response) {
      throw new Error("AI gagal")
    }

    const aiText = json.data.response

    // =========================
    // 2. PROSES VN (COBA)
    // =========================
    let opusAudio = null

    try {
      const inputBuffer = await fetchAnabotTTS(aiText)
      opusAudio = await convertBufferToOpusPTT(inputBuffer)
    } catch (vnErr) {
      console.error("[VN ERROR]", vnErr)
    }

    // =========================
    // 3. KIRIM HASIL
    // =========================
    await m.reply(aiText)

    if (opusAudio) {
      await conn.sendMessage(
        m.chat,
        { audio: opusAudio, mimetype: "audio/ogg; codecs=opus", ptt: true },
        { quoted: m }
      )
    }

  } catch (e) {
    console.error("[AI ERROR]", e)
    m.reply("❌ Error saat memproses AI")
  }
}

handler.command = ["reyy","rey","reyyy","reyyyy","reyyyyy"]
handler.help = ["reyy <teks>"]
handler.tags = ["main"]

export default handler