import axios from "axios"

const handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command}
╠⪼𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶:
║   • ${usedPrefix + command} teks
║   • 𝗰𝗼𝗻𝘁𝗼𝗵: ${usedPrefix + command} allah maha besar الله أكبر
║
╚═════════════╝`)

  // nama user
  let username = m.pushName || conn.getName(m.sender) || "PENGGUNA"

  // ambil pp
  let avatar
  try {
    avatar = await conn.profilePictureUrl(m.sender, "image")
  } catch {
    avatar = "https://l.top4top.io/p_3633xzwtq1.jpg"
  }

  // ⏰ Jam realtime WIB
  let time = new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).format(new Date())

  // react
  await conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } })

  try {
    // ✅ API BARU (sesuai docs & screenshot)
    let url = `https://api.zenitsu.web.id/api/maker/fakestory?user=${encodeURIComponent(
      username
    )}&caption=${encodeURIComponent(text)}&pp=${encodeURIComponent(avatar)}`

    // response image
    let res = await axios.get(url, { responseType: "arraybuffer" })
    let buffer = Buffer.from(res.data)

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `✅Instagram story berhasil dibuat\n🕒 Jam: ${time} WIB`
      },
      { quoted: m }
    )

    // hapus react
    await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
    return m.reply(`Gagal membuat story!`)
  }
}

handler.command = /^postig$/i
handler.tags = ["main"]
handler.help = ["postig"]
export default handler