import axios from "axios"
import { exec } from "child_process"
import { promisify } from "util"
import fs from "fs"
import path from "path"

const execAsync = promisify(exec)

// =========================
// CONVERT BUFFER -> OPUS PTT (BIAR JADI VN WA)
// =========================
async function convertBufferToOpusPTT(buffer) {
  const tmpIn = path.join(process.cwd(), `in-${Date.now()}.tmp`)
  const tmpOut = path.join(process.cwd(), `out-${Date.now()}.opus`)

  await fs.promises.writeFile(tmpIn, buffer)

  // Convert audio apapun ke format opus ptt whatsapp
  await execAsync(
    `ffmpeg -y -i "${tmpIn}" -vn -c:a libopus -b:a 128k -ar 48000 -ac 1 "${tmpOut}"`
  )

  const audio = await fs.promises.readFile(tmpOut)

  // Bersihin file sampah
  await fs.promises.unlink(tmpIn).catch(() => {})
  await fs.promises.unlink(tmpOut).catch(() => {})

  return audio
}

// =========================
// FETCH AUDIO DARI ANABOT
// =========================
async function fetchAnabotTTS(text, type) {
  const apikey = "freeApikey"
  let url = ""

  // Tentukan endpoint berdasarkan tipe (cowok/cewek)
  if (type === "cowok") {
    // API Cowok (voiceEdge)
    url = `https://anabot.my.id/api/ai/voiceEdge?text=${encodeURIComponent(text)}&voice=id-ID-ArdiNeural&apikey=${apikey}`
  } else {
    // API Cewek (text2voice)
    url = `https://anabot.my.id/api/ai/text2voice?text=${encodeURIComponent(text)}&apikey=${apikey}`
  }

  // 1. Request ke API buat dapetin URL audionya (JSON)
  const { data } = await axios.get(url)

  if (!data.success || !data.data || !data.data.result) {
    throw new Error("API Anabot error atau limit habis.")
  }

  const audioUrl = data.data.result

  // 2. Download file audio dari URL yang dikasih API
  const audioRes = await axios.get(audioUrl, { responseType: "arraybuffer" })

  return Buffer.from(audioRes.data)
}

function guide(usedPrefix) {
  return `
╔══⪻ 𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆 ⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 :
║   • ${usedPrefix}covn (Suara Cowok)
║   • ${usedPrefix}cevn (Suara Cewek)
╠⪼ 𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶 :
║   • ${usedPrefix}covn <teks>
║   • ${usedPrefix}cevn <teks>
║   • reply pesan teks lalu ketik ${usedPrefix}covn / ${usedPrefix}cevn
╠⪼ 𝗖𝗼𝗻𝘁𝗼𝗵 :
║   • ${usedPrefix}covn halo bang
║   • ${usedPrefix}cevn halo sayang
║
╚═════════════╝`.trim()
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  // Peringatan kalau pakai .vn biasa
  if (command === "vn") {
    return m.reply(
      `Harap gunakan ini ya:
.cevn = Suara Cewek
.covn = Suara Cowok

Command .vn sudah diganti jadi .cevn/.covn`
    )
  }

  // Ambil teks dari input langsung atau dari reply
  let inputText = text?.trim()
  if (!inputText && m.quoted) {
    inputText = (
      m.quoted.text ||
      m.quoted.caption ||
      m.quoted.contentText ||
      m.quoted.selectedDisplayText ||
      ""
    ).trim()
  }

  // Harus ada teks
  if (!inputText) {
    return m.reply(guide(usedPrefix))
  }

  await conn.sendPresenceUpdate("recording", m.chat)

  try {
    let inputBuffer

    // =========================
    // SELEKSI COMMAND
    // =========================
    if (command === "covn") {
      inputBuffer = await fetchAnabotTTS(inputText, "cowok")
    } else {
      inputBuffer = await fetchAnabotTTS(inputText, "cewek")
    }

    // Convert ke format PTT WhatsApp (Opus)
    const opusAudio = await convertBufferToOpusPTT(inputBuffer)

    // Kirim Audio
    await conn.sendMessage(
      m.chat,
      { audio: opusAudio, mimetype: "audio/ogg; codecs=opus", ptt: true },
      { quoted: m }
    )
  } catch (e) {
    console.error(`[VN ERROR - ${command}]`, e)
    m.reply("gagal membuat vn, silahkan coba lagi")
  }
}

handler.command = ["vn", "covn", "cevn"]
handler.help = ["covn <teks>", "cevn <teks>"]
handler.tags = ["main"]

export default handler