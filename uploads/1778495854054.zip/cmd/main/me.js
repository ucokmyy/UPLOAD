import fs from "fs"
import fetch from "node-fetch"
import sharp from "sharp"
import { prepareWAMessageMedia } from "@whiskeysockets/baileys"

const handler = async (m, { conn }) => {

  const sender = m.sender
  const number = sender.split("@")[0]

  // =====================
  // LOAD DATABASE
  // =====================

  const totalAfk = fs.existsSync("./source/database/totalafk.json")
    ? JSON.parse(fs.readFileSync("./source/database/totalafk.json"))
    : {}

  const totalUse = fs.existsSync("./source/database/totaluse.json")
    ? JSON.parse(fs.readFileSync("./source/database/totaluse.json"))
    : {}

  const welcome = fs.existsSync("./source/database/welcome.json")
    ? JSON.parse(fs.readFileSync("./source/database/welcome.json"))
    : { groups: {}, joins: {} }

  // =====================
  // JOIN DATE
  // =====================

  let joinText = "-"
  let hariText = "-"

  if (
    welcome.joins &&
    welcome.joins[m.chat] &&
    welcome.joins[m.chat][sender]
  ) {
    const joinTime = welcome.joins[m.chat][sender]

    const date = new Date(joinTime)

    joinText = date.toLocaleDateString("id-ID", {
      day: "2-digit",
      month: "long",
      year: "numeric"
    })

    const diff = Date.now() - joinTime
    const days = Math.floor(diff / 86400000)

    if (days === 0) {
      hariText = "baru join hari ini"
    } else if (days === 1) {
      hariText = "Sejak kemarin"
    } else {
      hariText = days + " hari yang lalu"
    }
  }

  // =====================
  // AFK TERLAMA
  // =====================

  let afkText = "Kamu belum pernah .afk"

  if (totalAfk[sender]) {
    const ms = totalAfk[sender].time

    const second = 1000
    const minute = second * 60
    const hour = minute * 60
    const day = hour * 24
    const month = day * 30
    const year = month * 12

    if (ms < minute) {
      afkText = "*" + Math.floor(ms / second) + "* detik"
    } else if (ms < hour) {
      afkText =
        "*" + Math.floor(ms / minute) +
        "* menit lebih *" +
        Math.floor((ms % minute) / second) +
        "* detik"
    } else if (ms < day) {
      afkText =
        "*" + Math.floor(ms / hour) +
        "* jam lebih *" +
        Math.floor((ms % hour) / minute) +
        "* menit"
    } else if (ms < month) {
      afkText =
        "*" + Math.floor(ms / day) +
        "* hari lebih *" +
        Math.floor((ms % day) / hour) +
        "* jam"
    } else if (ms < year) {
      afkText =
        "*" + Math.floor(ms / month) +
        "* bulan lebih *" +
        Math.floor((ms % month) / day) +
        "* hari"
    } else {
      afkText =
        "*" + Math.floor(ms / year) +
        "* tahun lebih *" +
        Math.floor((ms % year) / month) +
        "* bulan"
    }
  }

  // =====================
  // TOTAL USE
  // =====================

  let useText = "0"

  if (totalUse[sender]) {
    useText = totalUse[sender]
  }

  // =====================
  // PROFILE PICTURE
  // =====================

  let pp
  try {
    pp = await conn.profilePictureUrl(sender, "image")
  } catch {
    pp = "https://i.ibb.co.com/p63Zc5Yf/7601f57a17473be024d6638225cd2d90.jpg"
  }

  // ambil buffer + metadata (kayak relay.js)
  let buffer = await (await fetch(pp)).arrayBuffer().then(b => Buffer.from(b))
  let meta = await sharp(buffer).metadata()

  const { imageMessage: image } = await prepareWAMessageMedia(
    { image: buffer },
    {
      upload: conn.waUploadToServer,
      mediaTypeOverride: "thumbnail-link"
    }
  )

  image.height = meta.height || 630
  image.width = meta.width || 1200

  // =====================
  // CAPTION
  // =====================

  const caption =
`─ 𝗜 𝗗   𝗖 𝗔 𝗥 𝗗 🪪

👤𝗡𝗔𝗠𝗘𝗧𝗔𝗚 : @${number}

🗓️𝗧𝗔𝗡𝗚𝗚𝗔𝗟 𝗝𝗢𝗜𝗡 𝗚𝗥𝗨𝗣 : ${joinText}

🧮𝗦𝗨𝗗𝗔𝗛 𝗕𝗘𝗥𝗚𝗔𝗕𝗨𝗡𝗚 : ${hariText}

🏆𝗔𝗙𝗞 𝗧𝗘𝗥𝗟𝗔𝗠𝗔 : ${afkText}

𝗄𝖺𝗆𝗎 𝗌𝗎𝖽𝖺𝗁 𝗆𝖾𝗇𝗀𝗀𝗎𝗇𝖺𝗄𝖺𝗇 𝖿𝗂𝗍𝗎𝗋 𝖻𝗈𝗍 𝗂𝗇𝗂 𝗌𝖾𝖻𝖺𝗇𝗒𝖺𝗄 *${useText}* 𝗄𝖺𝗅𝗂`

  await conn.sendMessage(
    m.chat,
    {
      text: `${pp}\n\n${caption}`,
      mentions: [sender],
      linkPreview: {
        "matched-text": pp,
        title: "𝗬 𝗢 𝗨 𝗥   𝗣 𝗥 𝗢 𝗙 𝗜 𝗟 𝗘",
        previewType: 0,
        jpegThumbnail: buffer,
        highQualityThumbnail: image,
        linkPreviewMetadata: {
          linkMediaDuration: 0,
          socialMediaPostType: 1
        }
      },
      favicon: {
        url: pp
      }
    },
    { quoted: m }
  )
}

handler.command = ["me", "profile"]
handler.tags = ["main"]
handler.help = ["me"]

export default handler