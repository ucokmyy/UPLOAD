const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command}
╠⪼𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶:
║   • ${usedPrefix + command} teks
║   • 𝗰𝗼𝗻𝘁𝗼𝗵: ${usedPrefix + command} jagoan aku
║
╚═════════════╝`.trim())

  // 🔥 TIME REAL
  let time = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).format(new Date())

  // 🔥 RANDOM BATTERY & SIGNAL
  const battery = Math.floor(Math.random() * 100) + 1
  const signal = Math.floor(Math.random() * 4) + 1

  // 🔥 RANDOM OPERATOR INDONESIA
  const operators = [
    "TELKOMSEL",
    "XL",
    "INDOSAT",
    "TRI",
    "SMARTFREN",
    "AXIS",
    "BY.U"
  ]
  const carrier = operators[Math.floor(Math.random() * operators.length)]

  // 🔥 API UTAMA (TERMAI)
  let mainApi = `https://api.termai.cc/api/maker/iqc?text=${encodeURIComponent(text.trim())}&timestamp=${encodeURIComponent(time)}&emojiType=ios&statusBarTime=${encodeURIComponent(time)}&signal=${signal}&battery=${battery}&carrier=${encodeURIComponent(carrier)}&key=Bell409`

  // 🔥 API CADANGAN (ANABOT - TETAP)
  let fallbackApi = `https://anabot.my.id/api/maker/iqc?text=${encodeURIComponent(text.trim())}&chatTime=${encodeURIComponent(time)}&statusBarTime=${encodeURIComponent(time)}&bubbleColor=%23272a2f&menuColor=%23272a2f&textColor=%23FFFFFF&fontName=Arial&signalName=Telkomsel&apikey=freeApikey`

  try {
    await conn.sendMessage(m.chat, {
      image: { url: mainApi },
      caption: `✅ IQC berhasil dibuat\n🕒 Jam: ${time}\n📶 Sinyal: ${signal}\n🔋 Baterai: ${battery}%\n📡 Operator: ${carrier}`
    }, { quoted: m })
  } catch (e) {
    await conn.sendMessage(m.chat, {
      image: { url: fallbackApi },
      caption: `✅ IQC berhasil dibuat\n🕒 Jam: ${time}`
    }, { quoted: m })
  }
}

handler.help = ['iqc <pesan>']
handler.tags = ['maker']
handler.command = ['iqc']

export default handler