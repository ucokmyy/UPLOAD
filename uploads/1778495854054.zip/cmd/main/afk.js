import { loadAfk, saveAfk } from "../../source/lib/afk.js"

const handler = async (m, { text }) => {
  const afk = loadAfk()

  afk[m.sender] = {
    reason: text || "",
    time: Date.now()
  }

  saveAfk(afk)

  let msg = `@${m.sender.split("@")[0]} telah AFK`
  if (text) msg += `\n𝗱𝗲𝗻𝗴𝗮𝗻 𝗮𝗹𝗮𝘀𝗮𝗻: ${text}`

  await m.reply(msg, {
    mentions: [m.sender]
  })
}

handler.command = ["afk"]
handler.help = ["afk <alasan>"]
handler.tags = ["main"]
export default handler