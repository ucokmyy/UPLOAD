import { exec } from "child_process"
import fs from "fs"
import path from "path"
import fetch from "node-fetch"
import { fileURLToPath } from "url"
import { generateWAMessageFromContent, generateWAMessage } from "@whiskeysockets/baileys"

const handler = async (m, { conn, args, command, usedPrefix, reply }) => {
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const reynn = { 
                key: {
                    fromMe: false, 
                    participant: `0@s.whatsapp.net`, 
                    remoteJid: "0@s.whatsapp.net"
                },
                message: { 
                    extendedTextMessage: { text: "*TIKTOK SLIDE 📷*" } 
                }
            };

async function getFileSizeFromUrl(url) {
  try {
    const res = await fetch(url, { method: "HEAD" })
    const size = res.headers.get("content-length")
    return size ? parseInt(size) : 0
  } catch {
    return 0
  }
}

function formatSize(bytes) {
  if (!bytes) return "Tidak diketahui"
  const sizes = ["B","KB","MB","GB","TB"]
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return (bytes / Math.pow(1024, i)).toFixed(2) + " " + sizes[i]
}     

async function convert(input) {
  let buffer

  if (typeof input === "string") {
    const res = await fetch(input)
    if (!res.ok) throw new Error(`gagal download: ${res.statusText}`)
    buffer = await res.buffer()
  } else if (Buffer.isBuffer(input)) {
    buffer = input
  } else {
    throw new Error("input must be a link or buffer")
  }

  const tmpIn = path.join(__dirname, `in-${Date.now()}.mp4`)
  const tmpOut = path.join(__dirname, `out-${Date.now()}.mp3`)
  fs.writeFileSync(tmpIn, buffer)

  await new Promise((resolve, reject) => {
    exec(
      `ffmpeg -y -i "${tmpIn}" -vn -c:a libmp3lame -b:a 192k "${tmpOut}"`,
      err => (err ? reject(err) : resolve())
    )
  })

  const audio = fs.readFileSync(tmpOut)
  fs.unlinkSync(tmpIn)
  fs.unlinkSync(tmpOut)
  return audio
}

function extractTiktokUrl(text = "") {
  const regex = /https?:\/\/\S*tiktok\.com\/\S+/i
  const match = text.match(regex)
  return match ? match[0] : null
}

async function fetchZenx(url) {
  const r = await fetch(
    `https://api.cuki.biz.id/api/downloader/tiktok?apikey=cuki-x&url=${encodeURIComponent(url)}`
  )
  const json = await r.json().catch(() => ({}))
  const data = json?.results
  if (!json?.success || !data) throw new Error("link tidak valid atau video tidak tersedia")
  return { provider: "zenx", data }
}

// 🔥 API CADANGAN BARU (RYNEKO)
async function fetchRyneko(url) {
  const r = await fetch(
    `https://rynekoo-api.hf.space/downloader/tiktok?url=${encodeURIComponent(url)}`
  )
  const json = await r.json().catch(() => ({}))
  if (!json?.success || !json?.result) throw new Error("link tidak valid atau video tidak tersedia")
  return { provider: "ryneko", data: json.result }
}

function normalize(provider, data) {
  if (provider === "zenx") {
    const images = Array.isArray(data.images) ? data.images : []
    const video = data.nowm || null
    const audioUrl = data.music_info?.play || data.music || null

    const author =
      data.author?.nickname ||
      data.author?.unique_id ||
      "Tidak diketahui"

    const soundTitle =
      data.music_info?.title ||
      data.music_info?.author ||
      "-"

    const stats = {
      likes: data.stats?.digg_count ?? null,
      comments: data.stats?.comment_count ?? null,
      shares: data.stats?.share_count ?? null,
      views: data.stats?.play_count ?? null
    }

    return {
      type: data.type === "photo" ? "image" : (data.type === "video" ? "video" : (images.length ? "image" : (video ? "video" : "unknown"))),
      title: data.title || data.caption || "-",
      images,
      video,
      audioUrl,
      author,
      soundTitle,
      stats
    }
  }

  if (provider === "ryneko") {
    const images = Array.isArray(data.images) ? data.images : []
    const video = data.videoUrl || null
    const audioUrl = data.musicUrl || null

    const stats = {
      likes: data.stats?.like ?? null,
      comments: data.stats?.comment ?? null,
      shares: data.stats?.share ?? null,
      views: data.stats?.play ?? null
    }

    return {
      type: images.length ? "image" : (video ? "video" : "unknown"),
      title: data.title || "-",
      images,
      video,
      audioUrl,
      author: data.author?.name || data.author?.username || "Tidak diketahui",
      soundTitle: data.music_info?.title || "-",
      stats
    }
  }

  return { type: "unknown" }
}

function formatNumberShort(num) {
  if (num === null || num === undefined) return "-"
  if (typeof num !== "number") return num

  if (num >= 1_000_000_000) return `${(num / 1e9).toFixed(1)} 𝗺`
  if (num >= 1_000_000) return `${(num / 1e6).toFixed(1)} 𝗷𝘁`
  if (num >= 10_000) return `${(num / 1e3).toFixed(1)} 𝗿𝗯`
  return num.toLocaleString("id-ID")
}

function formatStats(stats = {}) {
  return `❤️ 𝗟𝗶𝗸𝗲 : ${formatNumberShort(stats.likes)}
💬 𝗖𝗼𝗺𝗺𝗲𝗻𝘁 : ${formatNumberShort(stats.comments)}
📤 𝗦𝗵𝗮𝗿𝗲 : ${formatNumberShort(stats.shares)}
👀 𝗩𝗶𝗲𝘄𝘀 : ${formatNumberShort(stats.views)}`
}

async function sendAlbumMessage(client, jid, medias, options = {}) {
  const caption = options.text || options.caption || ""

  const album = generateWAMessageFromContent(jid, {
    albumMessage: {
      expectedImageCount: medias.filter(m => m.type === "image").length,
      expectedVideoCount: medias.filter(m => m.type === "video").length,
      ...(options.quoted ? {
        contextInfo: {
        mentionedJid: [m.sender],
          remoteJid: options.quoted.key.remoteJid,
          fromMe: options.quoted.key.fromMe,
          stanzaId: options.quoted.key.id,
          participant: options.quoted.key.participant || options.quoted.key.remoteJid,
          quotedMessage: options.quoted.message
        }
      } : {})
    }
  }, {quoted: reynn})

  await client.relayMessage(album.key.remoteJid, album.message, {
    messageId: album.key.id
  })

  for (let i = 0; i < medias.length; i++) {
    const media = medias[i]
    const msg = await generateWAMessage(album.key.remoteJid, {
      [media.type]: media.data,
      ...(i === 0 ? { caption } : {})
    }, {
      upload: client.waUploadToServer
    })

    msg.message.messageContextInfo = {
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    }

    await client.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id
    })
  }

  return album
}

  let url = args[0] || ""

  if (!url && m.quoted) {
    const qt = m.quoted.text || m.quoted.caption || ""
    url = extractTiktokUrl(qt) || ""
  }

  if (!url) {
    return reply(
`╔══⪻ 𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆 ⪼══╗
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 : ${usedPrefix + command}
╠⪼ 𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶 :
║   • ${usedPrefix + command} <link vt>
║   • atau reply pesan yang berisi link vt lalu ketik *${usedPrefix + command}*
╠⪼ 𝗖𝗼𝗻𝘁𝗼𝗵 : ${usedPrefix + command} https://vt.tiktok.com/xxxx
╚════════════╝`
    )
  }

  await conn.sendMessage(m.chat, { react: { text: "📥", key: m.key } })

  try {
    let fetched
    try {
      fetched = await fetchZenx(url)
    } catch {
      fetched = await fetchRyneko(url)
    }

    const norm = normalize(fetched.provider, fetched.data)

    if (norm.type === "image" && norm.images.length > 1) {
      if (norm.images.length > 18) return reply("Slide maksimal 18")

      const caption =
`乂 𝗧 𝗜 𝗞 𝗧 𝗢 𝗞   𝗦 𝗟 𝗜 𝗗 𝗘

• 𝗖𝗔𝗣𝗧𝗜𝗢𝗡
${norm.title}

👤 𝗔𝘂𝘁𝗵𝗼𝗿 : ${norm.author}
🎵 𝗦𝗼𝘂𝗻𝗱 : ${norm.soundTitle}

${formatStats(norm.stats)}

©${global.botname}`

      const medias = norm.images.map(url => ({
        type: "image",
        data: { url }
      }))

      await sendAlbumMessage(conn, m.chat, medias, { caption, quoted: m })

      if (norm.audioUrl) {
        const audio = await convert(norm.audioUrl)
        await conn.sendMessage(m.chat, { audio, mimetype: "audio/mpeg" }, { quoted: m })
      }

    } else if (norm.type === "image" && norm.images.length === 1) {
      const caption =
`乂 𝗧 𝗜 𝗞 𝗧 𝗢 𝗞   𝗙 𝗢 𝗧 𝗢

• 𝗖𝗔𝗣𝗧𝗜𝗢𝗡
${norm.title}

👤 𝗔𝘂𝘁𝗵𝗼𝗿 : ${norm.author}
🎵 𝗦𝗼𝘂𝗻𝗱 : ${norm.soundTitle}

${formatStats(norm.stats)}

©${global.botname}`

      await conn.sendMessage(
        m.chat,
        { image: { url: norm.images[0] }, caption },
        { quoted: m }
      )

      if (norm.audioUrl) {
        const audio = await convert(norm.audioUrl)
        await conn.sendMessage(m.chat, { audio, mimetype: "audio/mpeg" }, { quoted: m })
      }

} else if (norm.type === "video" && norm.video) {

  const size = await getFileSizeFromUrl(norm.video)
  const maxSize = 90 * 1024 * 1024

  const caption =
`乂 𝗧 𝗜 𝗞 𝗧 𝗢 𝗞   𝗩 𝗜 𝗗 𝗘 𝗢

• 𝗝𝘂𝗱𝘂𝗹 : ${norm.title}
• 𝗔𝘂𝘁𝗵𝗼𝗿 : ${norm.author}
• 𝗦𝗼𝘂𝗻𝗱 : ${norm.soundTitle}

${formatStats(norm.stats)}

©${global.botname}`

  if (size > maxSize) {
    return reply(
`⚠️ 𝗙𝗜𝗟𝗘 𝗧𝗘𝗥𝗟𝗔𝗟𝗨 𝗕𝗘𝗦𝗔𝗥 𝗨𝗡𝗧𝗨𝗞 𝗗𝗜 𝗞𝗜𝗥𝗜𝗠 𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗦𝗘𝗕𝗔𝗚𝗔𝗜 𝗩𝗜𝗗𝗘𝗢 

Video tidak dapat dikirim secara langsung karena melebihi batas maksimal WhatsApp (90MB).  

Kamu bisa download manual dengan menekan link di bawah  

*DETAIL VIDEO :*  
📦 𝗨𝗸𝘂𝗿𝗮𝗻 : ${formatSize(size)}  
🚫 𝗕𝗮𝘁𝗮𝘀 : 90 MB  
🖥️ 𝗧𝗶𝘁𝗹𝗲 : ${norm.title}  
👤 𝗔𝘂𝘁𝗵𝗼𝗿 : ${norm.author}  
🎵 𝗦𝗼𝘂𝗻𝗱 : ${norm.soundTitle}  

🔗 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗠𝗮𝗻𝘂𝗮𝗹 :  
${norm.video}  

${formatStats(norm.stats)}  

©${global.botname}`
    )
  }

  const audio = norm.audioUrl ? await convert(norm.audioUrl) : null

  await conn.sendMessage(
    m.chat,
    { video: { url: norm.video }, caption },
    { quoted: m }
  )

  if (audio) {
    await conn.sendMessage(
      m.chat,
      { audio, mimetype: "audio/mpeg" },
      { quoted: m }
    )
  }
} else {
      reply("Media tidak ditemukan atau tidak didukung.")
    }

  } catch (e) {
    reply(`Terjadi kesalahan: ${e.message}\n\n_Silahkan gunakan *.tt2*_`)
  }

  await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
}

handler.command = ["tiktok", "tt", "ttfoto"]
handler.tags = ["download"]
handler.help = ["tiktok"]

export default handler