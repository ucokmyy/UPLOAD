import fs from "fs"
import path from "path"
import { fileURLToPath } from "url"
import fetch from "node-fetch"
import axios from "axios"
import * as cheerio from "cheerio"
import CryptoJS from "crypto-js"
import qs from "qs"
import { generateWAMessageFromContent, generateWAMessage } from "@whiskeysockets/baileys"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// =========================
// SCRAPER: reelsvideo.io (support reels/video/photo/story/slide)
// =========================
const RV_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  Accept: "*/*",
  "hx-request": "true",
  "hx-current-url": "https://reelsvideo.io/",
  "hx-target": "target",
  "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
  Origin: "https://reelsvideo.io",
  Referer: "https://reelsvideo.io/"
}

function generateTS() {
  return Math.floor(Date.now() / 1000)
}

function generateTT(ts) {
  return CryptoJS.MD5(String(ts) + "X-Fc-Pp-Ty-eZ").toString()
}

async function reelsvideoScrape(igUrl) {
  const ts = generateTS()
  const tt = generateTT(ts)

  const body = new URLSearchParams()
  body.append("id", igUrl)
  body.append("locale", "en")
  body.append("cf-turnstile-response", "")
  body.append("tt", tt)
  body.append("ts", String(ts))

  // NOTE:
  // reelsvideo.io kadang punya endpoint dinamis.
  // Ini dibuat 2 langkah: coba endpoint generic, kalau fail coba endpoint sample dari kamu.
  const endpoints = [
    "https://reelsvideo.io/reel/",
    "https://reelsvideo.io/reel/DUU67gXiTwU/?igsh=MTZxdm1yd3pnN3Rvdg==/"
  ]

  let html = null
  let lastErr = null
  for (const ep of endpoints) {
    try {
      const res = await axios.post(ep, body, { headers: RV_HEADERS })
      html = res.data
      break
    } catch (e) {
      lastErr = e
    }
  }
  if (!html) throw lastErr || new Error("Gagal request reelsvideo.io")

  const $ = cheerio.load(html)

  const username = $(".bg-white span.text-400-16-18").first().text().trim() || null
  const thumb = $("div[data-bg]").first().attr("data-bg") || null

  const videos = []
  $("a.type_videos").each((_, el) => {
    const href = $(el).attr("href")
    if (href) videos.push(href)
  })

  const images = []
  $("a.type_images").each((_, el) => {
    const href = $(el).attr("href")
    if (href) images.push(href)
  })

  const mp3 = []
  $("a.type_audio").each((_, el) => {
    const href = $(el).attr("href")
    const id = $(el).attr("data-id")
    if (href && id) mp3.push({ id, url: href })
  })

  let type = "unknown"
  if (videos.length && images.length) type = "carousel"
  else if (videos.length) type = "video"
  else if (images.length) type = "photo"

  return { type, username, thumb, videos, images, mp3 }
}

// =========================
// IG GraphQL (buat caption/like/comment kalau post/reel/tv)
// =========================
const IG_GQL_HEADERS = {
  Accept: "*/*",
  "Accept-Language": "en-US,en;q=0.5",
  "Content-Type": "application/x-www-form-urlencoded",
  "X-FB-Friendly-Name": "PolarisPostActionLoadPostQueryQuery",
  "X-CSRFToken": "RVDUooU5MYsBbS1CNN3CzVAuEP8oHB52",
  "X-IG-App-ID": "1217981644879628",
  "X-FB-LSD": "AVqbxe3J_YA",
  "X-ASBD-ID": "129477",
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent":
    "Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-G973U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36"
}

function getInstagramPostId(url) {
  const regex =
    /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:p|tv|reel)\/([^/?#&]+).*/i
  const match = String(url || "").match(regex)
  return match ? match[1] : null
}

function encodeGraphqlRequestData(shortcode) {
  const requestData = {
    av: "0",
    __d: "www",
    __user: "0",
    __a: "1",
    __req: "3",
    __hs: "19624.HYP:instagram_web_pkg.2.1..0.0",
    dpr: "3",
    __ccg: "UNKNOWN",
    __rev: "1008824440",
    __s: "xf44ne:zhh75g:xr51e7",
    __hsi: "7282217488877343271",
    __dyn:
      "7xeUmwlEnwn8K2WnFw9-2i5U4e0yoW3q32360CEbo1nEhw2nVE4W0om78b87C0yE5ufz81s8hwGwQwoEcE7O2l0Fwqo31w9a9x-0z8-U2zxe2GewGwso88cobEaU2eUlwhEe87q7-0iK2S3qazo7u1xwIw8O321LwTwKG1pg661pwr86C1mwraCg",
    __csr: "somevalue",
    __comet_req: "7",
    lsd: "AVqbxe3J_YA",
    jazoest: "2957",
    __spin_r: "1008824440",
    __spin_b: "trunk",
    __spin_t: "1695523385",
    fb_api_caller_class: "RelayModern",
    fb_api_req_friendly_name: "PolarisPostActionLoadPostQueryQuery",
    variables: JSON.stringify({
      shortcode,
      fetch_comment_count: null,
      fetch_related_profile_media_count: null,
      parent_comment_count: null,
      child_comment_count: null,
      fetch_like_count: null,
      fetch_tagged_user_count: null,
      fetch_preview_comment_count: null,
      has_threaded_comments: false,
      hoisted_comment_id: null,
      hoisted_reply_id: null
    }),
    server_timestamps: "true",
    doc_id: "10015901848480474"
  }

  return qs.stringify(requestData)
}

async function getIgMeta(url) {
  const shortcode = getInstagramPostId(url)
  if (!shortcode) return null

  const encoded = encodeGraphqlRequestData(shortcode)
  const res = await axios.post("https://www.instagram.com/api/graphql", encoded, {
    headers: IG_GQL_HEADERS
  })

  const mediaData = res?.data?.data?.xdt_shortcode_media
  if (!mediaData) return null

  return {
    caption: mediaData.edge_media_to_caption?.edges?.[0]?.node?.text || null,
    username: mediaData.owner?.username || null,
    like: mediaData.edge_media_preview_like?.count ?? null,
    comment: mediaData.edge_media_to_comment?.count ?? null
  }
}

// =========================
// Helpers
// =========================
function extractIgUrl(text = "") {
  const regex =
    /(https?:\/\/(?:www\.)?instagram\.com\/(?:p|reel|tv|stories)\/[^\s]+)/i
  const match = String(text || "").match(regex)
  return match ? match[0] : null
}

function isIgStoryUrl(url = "") {
  return /instagram\.com\/stories\//i.test(String(url))
}

async function getFileSizeFromUrl(url) {
  try {
    const res = await fetch(url, { method: "HEAD" })
    const size = res.headers.get("content-length")
    return size ? parseInt(size) : 0
  } catch {
    return 0
  }
}

function formatSize(bytes) {
  if (!bytes) return "Tidak diketahui"
  const sizes = ["B", "KB", "MB", "GB", "TB"]
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return (bytes / Math.pow(1024, i)).toFixed(2) + " " + sizes[i]
}

function formatNumberShort(num) {
  if (num === null || num === undefined) return "-"
  if (typeof num !== "number") return String(num)
  if (num >= 1_000_000_000) return `${(num / 1e9).toFixed(1)} 𝗺`
  if (num >= 1_000_000) return `${(num / 1e6).toFixed(1)} 𝗷𝘁`
  if (num >= 10_000) return `${(num / 1e3).toFixed(1)} 𝗿𝗯`
  return num.toLocaleString("id-ID")
}

function formatStats(stats = {}) {
  return `❤️ 𝗟𝗶𝗸𝗲 : ${formatNumberShort(stats.likes)}
💬 𝗖𝗼𝗺𝗺𝗲𝗻𝘁 : ${formatNumberShort(stats.comments)}
📤 𝗦𝗵𝗮𝗿𝗲 : ${formatNumberShort(stats.shares)}
👀 𝗩𝗶𝗲𝘄𝘀 : ${formatNumberShort(stats.views)}`
}

// Album sender (copy pola .tt)
async function sendAlbumMessage(client, jid, medias, options = {}) {
  const caption = options.text || options.caption || ""

  const reynn = {
    key: {
      fromMe: false,
      participant: `0@s.whatsapp.net`,
      remoteJid: "0@s.whatsapp.net"
    },
    message: {
      extendedTextMessage: { text: "*INSTAGRAM SLIDE 📷*" }
    }
  }

  const album = generateWAMessageFromContent(
    jid,
    {
      albumMessage: {
        expectedImageCount: medias.filter(m => m.type === "image").length,
        expectedVideoCount: medias.filter(m => m.type === "video").length,
        ...(options.quoted
          ? {
              contextInfo: {
                mentionedJid: [options.quoted.sender],
                remoteJid: options.quoted.key.remoteJid,
                fromMe: options.quoted.key.fromMe,
                stanzaId: options.quoted.key.id,
                participant:
                  options.quoted.key.participant || options.quoted.key.remoteJid,
                quotedMessage: options.quoted.message
              }
            }
          : {})
      }
    },
    { quoted: reynn }
  )

  await client.relayMessage(album.key.remoteJid, album.message, {
    messageId: album.key.id
  })

  for (let i = 0; i < medias.length; i++) {
    const media = medias[i]
    const msg = await generateWAMessage(
      album.key.remoteJid,
      {
        [media.type]: media.data,
        ...(i === 0 ? { caption } : {})
      },
      { upload: client.waUploadToServer }
    )

    msg.message.messageContextInfo = {
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    }

    await client.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id
    })
  }

  return album
}

// =========================
// Plugin
// =========================
const handler = async (m, { conn, args, command, usedPrefix, reply }) => {
  let url = args[0] || ""

  if (!url && m.quoted) {
    const qt = m.quoted.text || m.quoted.caption || ""
    url = extractIgUrl(qt) || ""
  }

  if (!url) {
    return reply(
      `╔══⪻ 𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆 ⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 : ${usedPrefix + command}
╠⪼ 𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶 :
║   • ${usedPrefix + command} <link instagram>
║   • atau reply pesan yang berisi link lalu ketik *${usedPrefix + command}*
╠⪼ 𝗖𝗼𝗻𝘁𝗼𝗵 :
║   • ${usedPrefix + command} https://www.instagram.com/reel/xxxx
║
╚═════════════╝`
    )
  }

  await conn.sendMessage(m.chat, { react: { text: "📥", key: m.key } })

  try {
    const rv = await reelsvideoScrape(url)

    // =========================
    // KHUSUS INSTAGRAM STORIES
    // =========================
    if (isIgStoryUrl(url)) {
      const usernameStory = rv.username || "-"

      const storyCaption = `乂 𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠  𝗦 𝗧 𝗢 𝗥 𝗜 𝗘 𝗦

👤 𝗨𝘀𝗲𝗿 : ${usernameStory}

©${global.botname}`

      const storyMedias = []
      for (const img of rv.images || []) storyMedias.push({ type: "image", url: img })
      for (const vid of rv.videos || []) storyMedias.push({ type: "video", url: vid })

      if (!storyMedias.length) {
        if (rv.thumb) {
          await conn.sendMessage(
            m.chat,
            { image: { url: rv.thumb }, caption: storyCaption },
            { quoted: m }
          )
        } else {
          await conn.sendMessage(
            m.chat,
            { text: "Story tidak ditemukan atau sudah hilang." },
            { quoted: m }
          )
        }
        await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
        return
      }

      for (let i = 0; i < storyMedias.length; i++) {
        const media = storyMedias[i]
        if (media.type === "video") {
          await conn.sendMessage(
            m.chat,
            { video: { url: media.url }, caption: i === 0 ? storyCaption : undefined },
            { quoted: m }
          )
        } else {
          await conn.sendMessage(
            m.chat,
            { image: { url: media.url }, caption: i === 0 ? storyCaption : undefined },
            { quoted: m }
          )
        }
      }

      await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
      return
    }

    // =========================
    // NON-STORY: REELS/POST/SLIDE
    // =========================
    let meta = null
    try {
      meta = await getIgMeta(url)
    } catch {
      meta = null
    }

    const username = meta?.username || rv.username || "-"
    const captionText = meta?.caption || "-"

    // reelsvideo nggak ngasih share/views,
    // jadi kita tampilkan '-' biar formatnya tetap kayak .tt
    const stats = {
      likes: meta?.like ?? null,
      comments: meta?.comment ?? null,
      shares: null,
      views: null
    }

    const baseCaption = `乂 𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠

• 𝗖𝗔𝗣𝗧𝗜𝗢𝗡
${captionText}

👤 𝗨𝘀𝗲𝗿 : ${username}

${formatStats(stats)}

©${global.botname}`

    const medias = []
    for (const img of rv.images || []) medias.push({ type: "image", data: { url: img } })
    for (const vid of rv.videos || []) medias.push({ type: "video", data: { url: vid } })

    if (!medias.length) {
      if (rv.thumb) {
        await conn.sendMessage(
          m.chat,
          { image: { url: rv.thumb }, caption: baseCaption },
          { quoted: m }
        )
      } else {
        await conn.sendMessage(
          m.chat,
          { text: "Media tidak ditemukan atau tidak didukung." },
          { quoted: m }
        )
      }
    } else if (rv.type === "carousel" || medias.length > 1) {
      if (medias.length > 15) return reply("Slide maksimal 15")

      const title = rv.videos?.length ? "𝗦 𝗟 𝗜 𝗗 𝗘 / 𝗔 𝗟 𝗕 𝗨 𝗠" : "𝗦 𝗟 𝗜 𝗗 𝗘"
      const caption =
        `乂 𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠   ${title}\n\n` +
        baseCaption.replace(/^乂 𝗜 𝗡 𝗦 𝗧 𝗔 𝗚 𝗥 𝗔 𝗠\n\n/m, "")

      await sendAlbumMessage(conn, m.chat, medias, { caption, quoted: m })
    } else {
      const one = medias[0]

      if (one.type === "video") {
        const size = await getFileSizeFromUrl(rv.videos?.[0])
        const maxSize = 100 * 1024 * 1024

        if (size > maxSize) {
          return reply(
            `⚠️ 𝗙𝗜𝗟𝗘 𝗧𝗘𝗥𝗟𝗔𝗟𝗨 𝗕𝗘𝗦𝗔𝗥 𝗨𝗡𝗧𝗨𝗞 𝗗𝗜 𝗞𝗜𝗥𝗜𝗠 𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚

📦 𝗨𝗸𝘂𝗿𝗮𝗻 : ${formatSize(size)}
🚫 𝗕𝗮𝘁𝗮𝘀 : 100 MB
👤 𝗨𝘀𝗲𝗿 : ${username}

🔗 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗠𝗮𝗻𝘂𝗮𝗹 :
${rv.videos?.[0]}

${formatStats(stats)}

©${global.botname}`
          )
        }

        await conn.sendMessage(
          m.chat,
          { video: { url: rv.videos?.[0] }, caption: baseCaption },
          { quoted: m }
        )
      } else {
        await conn.sendMessage(
          m.chat,
          { image: { url: rv.images?.[0] }, caption: baseCaption },
          { quoted: m }
        )
      }
    }

    // kirim audio jika ada (untuk non-story)
    if (rv.mp3 && rv.mp3.length) {
      const a = rv.mp3[0]
      await conn.sendMessage(
        m.chat,
        { audio: { url: a.url }, mimetype: "audio/mpeg" },
        { quoted: m }
      )
    }
  } catch (e) {
    reply(`Terjadi kesalahan: ${e?.message || e}`)
  }

  await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
}

handler.command = ["ig", "instagram", "igdl"]
handler.tags = ["download"]
handler.help = ["ig <link>"]

export default handler