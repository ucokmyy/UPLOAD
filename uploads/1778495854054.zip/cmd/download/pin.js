import axios from "axios"

const SEARCH_API = "https://api.nexray.web.id/search/pinterest?q="
const DL_API = "https://api.deline.web.id/downloader/pinterest?url="

// 🔥 API CADANGAN BARU (BAGUSS)
const DL_API_BACKUP = "https://api.baguss.xyz/api/download/pinterest?url="

function extractPinterestUrl(text = "") {
  const match = text.match(/https?:\/\/(?:www\.)?(?:pinterest\.com|pin\.it)\/[^\s]+/i)
  return match ? match[0] : null
}

function pickRandom(arr = []) {
  return arr[Math.floor(Math.random() * arr.length)]
}

// 🔥 SEARCH (TETEP)
async function searchPinterest(query) {
  const { data } = await axios.get(
    `${SEARCH_API}${encodeURIComponent(query)}`,
    { timeout: 20000 }
  )

  if (!data?.status || !Array.isArray(data?.result)) {
    throw new Error("Tidak ditemukan hasil.")
  }

  const results = data.result.map(item => {
    const desc = item.description?.trim()
    const source = item.link && item.link !== "-" ? item.link : item.pin

    return {
      __type: "image",
      image_url: item.images_url,
      created_at: item.created_at || "-",
      pin: item.pin || "-",
      link: source || "-",
      description: desc && desc.length > 5 ? desc : "Tidak ada deskripsi",
      username: item.pinner?.username || "-",
      full_name: item.pinner?.full_name || "-"
    }
  })

  if (!results.length) throw new Error("Tidak ditemukan hasil.")

  return pickRandom(results)
}

const handler = async (m, { conn, text, usedPrefix, reply }) => {
  const example = `╔══⪻ 𝙋𝙄𝙉𝙏𝙀𝙍𝙀𝙎𝙏 ⪼══╗
║
╠⪼ Command:
║ • ${usedPrefix}pin <query>
║ • ${usedPrefix}pin <url>
║
╠⪼ Contoh:
║ • ${usedPrefix}pin mobil sport
║ • ${usedPrefix}pin https://pin.it/xxxxx
║
╚══════════════╝`

  const rawText = text || m.quoted?.text || m.quoted?.caption || ""
  if (!rawText) return reply(example)

  const url = extractPinterestUrl(rawText)

  // ===============================
  // DOWNLOADER MODE
  // ===============================
  if (url) {
    try {
      reply("⏳ Mengambil media dari Pinterest...")

      let res

      try {
        // 🔥 API UTAMA (TETEP)
        const api = DL_API + encodeURIComponent(url)
        const { data } = await axios.get(api, { timeout: 20000 })

        if (data?.status && data?.result) {
          res = data.result
        } else {
          throw "fail"
        }
      } catch {
        // 🔥 BACKUP BAGUSS
        const api2 = DL_API_BACKUP + encodeURIComponent(url)
        const { data } = await axios.get(api2, { timeout: 20000 })

        if (!data?.status || !data?.result) {
          throw new Error("Backup API gagal.")
        }

        const media = data.result.media

        res = {
          original_url: url,
          video: media?.type === "MP4" ? media.url : null,
          image: media?.type !== "MP4" ? media.url : null
        }
      }

      const caption = `
📌 *Pinterest Downloader*
━━━━━━━━━━━━━━━━━━
🔗 ${res.original_url || url}
━━━━━━━━━━━━━━━━━━`.trim()

      if (res.video) {
        await conn.sendMessage(
          m.chat,
          {
            video: { url: res.video },
            caption
          },
          { quoted: m }
        )
        return
      }

      if (res.image) {
        await conn.sendMessage(
          m.chat,
          {
            image: { url: res.image },
            caption
          },
          { quoted: m }
        )
        return
      }

      return reply("❌ Media tidak ditemukan.")
    } catch (e) {
      console.error("Pinterest downloader error:", e)
      return reply("⚠ Gagal mengambil media.\nCoba lagi nanti.")
    }
  }

  // ===============================
  // SEARCH MODE
  // ===============================
  try {
    const query = rawText.trim()
    const pick = await searchPinterest(query)

    const caption = `
乂 𝗣 𝗜 𝗡 𝗧 𝗘 𝗥 𝗘 𝗦 𝗧   𝗦 𝗘 𝗔 𝗥 𝗖 𝗛

🔎 *Pencarian*   : ${query}
👤 *User*             : ${pick.full_name}
🧾 *Username*  : ${pick.username}
📅 *Upload*        : ${pick.created_at}

📝 *Deskripsi*    : ${pick.description}

🌐 *Sumber*
${pick.link}
`.trim()

    const buttons = [
      {
        buttonId: `${usedPrefix}pin ${query}`,
        buttonText: { displayText: "Next ⏭️" },
        type: 1
      }
    ]

    if (pick.image_url) {
      await conn.sendMessage(
        m.chat,
        {
          image: { url: pick.image_url },
          caption,
          buttons,
          headerType: 4
        },
        { quoted: m }
      )
      return
    }

    return reply("❌ Hasil tidak valid.")
  } catch (e) {
    console.error("Pinterest search error:", e)
    return reply("❌ Gagal mengambil hasil.\nCoba lagi nanti.")
  }
}

handler.command = ["pin", "pinterest"]
handler.tags = ["downloader", "search"]
handler.help = ["pin <query/link>"]

export default handler