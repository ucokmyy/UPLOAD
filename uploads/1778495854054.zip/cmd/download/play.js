import fetch from 'node-fetch'
import axios from 'axios'
import crypto from "crypto"
import yts from "yt-search"

// =========================
// 🔥 SCRAPE BARU (SAVETUBE)
// =========================
async function ytdlMp3(query) {
  const { all } = await yts(query)
  const metadata = all[0]
  if (!metadata?.url) throw new Error("Video tidak ditemukan")

  const url = metadata.url

  const client = axios.create({
    headers: {
      "content-type": "application/json",
      "origin": "https://yt.savetube.me",
      "user-agent": "Mozilla/5.0 (Android)"
    }
  })

  // ambil videoId
  const idMatch = url.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/)
  if (!idMatch) throw new Error("Invalid URL")
  const videoId = idMatch[1]

  // ambil CDN
  const { data: cdnRes } = await client.get("https://media.savetube.vip/api/random-cdn")
  const cdn = cdnRes.cdn

  // ambil encrypted data
  const { data: infoRes } = await client.post(`https://${cdn}/v2/info`, {
    url: `https://www.youtube.com/watch?v=${videoId}`
  })

  // decrypt
  const encrypted = Buffer.from(infoRes.data, "base64")
  const key = Buffer.from("C5D58EF67A7584E4A29F6C35BBC4EB12", "hex")
  const iv = encrypted.subarray(0, 16)

  const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv)
  const decrypted = Buffer.concat([
    decipher.update(encrypted.subarray(16)),
    decipher.final()
  ])

  const meta = JSON.parse(decrypted.toString())

  // request download
  const { data: dlRes } = await client.post(`https://${cdn}/download`, {
    id: videoId,
    downloadType: 'audio',
    quality: '128',
    key: meta.key
  })

  const download = dlRes?.data?.downloadUrl
  if (!download) throw new Error("Gagal ambil audio")

  return {
    title: metadata.title,
    channel: metadata.author?.name || "-",
    duration: metadata.timestamp,
    cover: meta.thumbnail,
    url: metadata.url,
    dl: download
  }
}

// =========================
// HELPER THUMB
// =========================
async function getThumbBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 })
    const buf = Buffer.from(res.data)
    if (!buf || buf.length < 50) return null
    return buf
  } catch {
    return null
  }
}

// =========================
// HANDLER
// =========================
const handler = async (m, { conn, text, usedPrefix, command }) => {
  const owner = "6282296626024@s.whatsapp.net"
  const isOwner = m.sender === owner

  const forbiddenPattern = /(baon cikadap|lagu jorok|ngentod|bokep|porno|memek|kontol|konten dewasa)/i
  if (!isOwner && forbiddenPattern.test(text)) {
    return m.reply("Tidak bisa melanjutkan pencarian, karena mengarah ke hal sensitif")
  }

  if (!text) {
    return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command}
╠⪼𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶: sertakan judul lagu
╠⪼𝗖𝗼𝗻𝘁𝗼𝗵: .play serana
║
╚═════════════╝`)
  }

  m.reply("⏳ Tunggu sebentar...")

  try {
    const data = await ytdlMp3(text)

    if (!data?.dl) return m.reply("Link download tidak ditemukan")

    const thumbBuf = data.cover ? await getThumbBuffer(data.cover) : null

    await conn.sendMessage(m.chat, {
      audio: { url: data.dl },
      mimetype: 'audio/mpeg',
      ptt: false,
      contextInfo: {
        externalAdReply: {
          title: data.title,
          body: `Channel: ${data.channel} • Duration: ${data.duration}`,
          mediaType: 2,
          mediaUrl: data.url,
          sourceUrl: data.url,
          renderLargerThumbnail: true,
          ...(thumbBuf ? { thumbnail: thumbBuf } : { thumbnailUrl: data.cover })
        }
      }
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply("❌ Gagal mengambil audio, coba lagi nanti.")
  }
}

handler.help = ['play <query>']
handler.tags = ['download']
handler.command = ['play']

export default handler