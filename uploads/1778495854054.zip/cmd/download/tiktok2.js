import fetch from "node-fetch"
import axios from "axios"
import pkg from "@whiskeysockets/baileys"

const {
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  proto
} = pkg

const handler = async (m, { conn, command, text, prefix }) => {

  async function tiktokDownloaderVideo(url) {
    return new Promise(async (resolve, reject) => {
      try {
        let data = []
        function formatNumber(integer) {
          let numb = parseInt(integer)
          return Number(numb).toLocaleString().replace(/,/g, '.')
        }

        function formatDate(n, locale = 'en') {
          let d = new Date(n)
          return d.toLocaleDateString(locale, {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric'
          })
        }

        let domain = 'https://www.tikwm.com/api/';
        let res = (await axios.post(domain, {}, {
          headers: {
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Origin': 'https://www.tikwm.com',
            'Referer': 'https://www.tikwm.com/',
            'User-Agent': 'Mozilla/5.0'
          },
          params: {
            url: url,
            count: 12,
            cursor: 0,
            web: 1,
            hd: 1
          }
        })).data.data

        if (!res.size) {
          res.images.map(v => {
            data.push({ type: 'photo', url: v })
          })
        } else {
          data.push(
            { type: 'watermark', url: 'https://www.tikwm.com' + res.wmplay },
            { type: 'nowatermark', url: 'https://www.tikwm.com' + res.play },
            { type: 'nowatermark_hd', url: 'https://www.tikwm.com' + res.hdplay }
          )
        }

        resolve({
          status: true,
          title: res.title,
          durations: res.duration,
          images: res.images,
          data: data,
          music_info: {
            url: 'https://www.tikwm.com' + (res.music || res.music_info.play)
          }
        })
      } catch (e) {
        reject(e)
      }
    })
  }

  try {
    if (!text) return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${prefix + command}
╠⪼ 𝗖𝗮𝗿𝗮: kirim link tiktok
║
╚═════════════╝`)

    if (!/tiktok.com/.test(text)) return m.reply("Link Tidak Valid!")

    m.reply("Processing...")

    let tiktokUrl = text
    let scrape = await tiktokDownloaderVideo(tiktokUrl)

    let videoNowm = scrape.data.find(a => a.type === "nowatermark_hd")?.url ||
                    scrape.data.find(a => a.type === "nowatermark")?.url

    let isImageSlide = scrape.durations === 0 && scrape.images?.length > 1

    // SLIDE
    if (isImageSlide) {
      let cards = []
      for (let [i, img] of scrape.images.entries()) {
        const media = await prepareWAMessageMedia({ image: await fetch(img).then(r => r.buffer()) }, { upload: conn.waUploadToServer })
        cards.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Foto Slide Ke ${i + 1}`,
            hasMediaAttachment: true,
            ...media
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [{
              name: "cta_url",
              buttonParamsJson: `{\"display_text\":\"Link Foto\",\"url\":\"${img}\",\"merchant_url\":\"https://google.com\"}`
            }]
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: `Slide TikTok`
          })
        })
      }

      const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: "Hasil Slide TikTok"
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards
              })
            })
          }
        }
      }, { quoted: m })

      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

      if (scrape.music_info.url) {
        await conn.sendMessage(m.chat, {
          audio: { url: scrape.music_info.url },
          mimetype: "audio/mpeg"
        }, { quoted: m })
      }

      return
    }
    if (videoNowm) {
      await conn.sendMessage(m.chat, {
        video: { url: videoNowm },
        caption: "✅ Done"
      }, { quoted: m })
    }
    if (scrape.music_info.url) {
      await conn.sendMessage(m.chat, {
        audio: { url: scrape.music_info.url },
        mimetype: "audio/mpeg"
      }, { quoted: m })
    }

  } catch (e) {
    m.reply("Error: " + e)
  }
}

handler.command = /^(tiktok2|tt2|ttfoto2)$/i
handler.help = ["tt2"]
handler.tags = ["download"]

export default handler