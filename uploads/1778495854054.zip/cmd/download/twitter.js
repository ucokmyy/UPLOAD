import axios from "axios"

// =========================
// SCRAPER X/TWITTER
// =========================
async function twitter(url) {
  try {
    if (!url) throw new Error("url required")

    const r = await axios.post(
      "https://savetwitter.net/api/ajaxSearch",
      new URLSearchParams({ q: url, lang: "id", cftoken: "" }),
      {
        headers: {
          "User-Agent": "Mozilla/5.0",
          "Content-Type": "application/x-www-form-urlencoded",
          "X-Requested-With": "XMLHttpRequest",
          origin: "https://savetwitter.net",
          referer: "https://savetwitter.net/id3"
        }
      }
    )

    const h = r.data?.data
    if (!h) throw new Error("fetch failed")

    const mp4 = [...h.matchAll(/href="(https:\/\/dl\.snapcdn\.app\/get\?token=[^"]+)".*?MP4\s*\(([^)]+)\)/g)]
      .map((x) => ({ quality: x[2], url: x[1] }))

    return {
      title: h.match(/<h3>(.*?)<\/h3>/)?.[1]?.trim() || null,
      duration: h.match(/<p>(\d+:\d+)<\/p>/)?.[1] || null,
      thumbnail: h.match(/<img src="([^"]+)"/)?.[1] || null,
      mp4
    }
  } catch (e) {
    return { error: e.message }
  }
}

// helper ambil url dari teks
function extractXUrl(text = "") {
  const regex = /https?:\/\/(www\.)?(x\.com|twitter\.com)\/\S+/i
  const match = String(text || "").match(regex)
  return match ? match[0] : null
}

// ambil angka kualitas dari "1920p" -> 1920
function parseQuality(q = "") {
  const m = String(q).match(/(\d+)/)
  return m ? parseInt(m[1], 10) : 0
}

// =========================
// HANDLER
// =========================
const handler = async (m, { conn, args, command, usedPrefix, reply }) => {
  let url = args[0] || ""

  // kalau gak ada args, coba ambil dari reply
  if (!url && m.quoted) {
    const qt =
      m.quoted.text ||
      m.quoted.caption ||
      m.quoted?.message?.conversation ||
      ""
    url = extractXUrl(qt) || ""
  }

  // guide
  if (!url) {
    return reply(`
╔══⪻ 𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆 ⪼══╗
║
╠⪼ 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 : ${usedPrefix + command}
╠⪼ 𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶 :
║   • ${usedPrefix + command} <link x/twitter>
║   • atau reply pesan yang berisi link lalu ketik *${usedPrefix + command}*
╠⪼ 𝗖𝗼𝗻𝘁𝗼𝗵 : ${usedPrefix + command} https://x.com/xxxx/status/xxxx
║
╚═════════════╝`.trim())
  }

  if (!/(x\.com|twitter\.com)/i.test(url)) {
    return reply("URL Yang Tuan Berikan *Salah!!!*")
  }

  await conn.sendMessage(m.chat, { react: { text: "📥", key: m.key } })

  try {
    const res = await twitter(url)
    if (res.error) throw new Error(res.error)

    const list = Array.isArray(res.mp4) ? res.mp4 : []

    // ✅ kalau gak ada mp4, berarti kemungkinan tweet foto / tanpa video
    if (!list.length) {
      return reply("Lah bukannya di Twitter udah bisa download foto langsung yak, download di bot hanya untuk video")
    }

    // pilih kualitas tertinggi
    const best = list.sort((a, b) => parseQuality(b.quality) - parseQuality(a.quality))[0]

    const caption = `
乂 𝗫 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗘𝗥

• Judul : ${res.title || "-"}
• Durasi : ${res.duration || "-"}
• Quality : ${best.quality || "-"}
©${global.botname}
`.trim()

    await conn.sendMessage(
      m.chat,
      {
        video: { url: best.url },
        caption
      },
      { quoted: m }
    )
  } catch (e) {
    console.error("[X ERROR]", e?.message || e)
    reply("Terjadi error saat mengambil video. Coba link lain atau ulangi nanti.")
  }

  await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
}

handler.command = ["x", "twitter", "tw"]
handler.tags = ["download"]
handler.help = ["twitter"]

export default handler