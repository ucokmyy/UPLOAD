import axios from "axios"

function extractYouTubeUrl(text) {
  const regex =
    /(https?:\/\/(?:www\.)?(?:youtube\.com\/watch\?v=|youtube\.com\/live\/|youtu\.be\/|youtube\.com\/shorts\/)[^\s]+)/gi

  const match = regex.exec(String(text || ""))
  if (!match) return null

  let url = match[1]
  url = url.split("&")[0]

  return url
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function formatSize(bytes) {
  if (!bytes || bytes === 0) return "Unknown"
  const sizes = ["B","KB","MB","GB","TB"]
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return (bytes / Math.pow(1024, i)).toFixed(2) + " " + sizes[i]
}

async function getFileSize(url) {
  try {
    const res = await axios.head(url)
    return parseInt(res.headers["content-length"]) || 0
  } catch {
    return 0
  }
}

async function fetchQuality(url, quality) {
  const api =
    "https://api.ootaizumi.web.id/downloader/youtube?url=" +
    encodeURIComponent(url) +
    "&format=" + quality

  const res = await axios.get(api, { timeout: 60000 })

  if (!res.data?.status || !res.data?.result?.download)
    throw new Error(res.data?.message || "API gagal")

  return res.data.result
}

const handler = async (m, { conn, text, usedPrefix, command, reply }) => {

  let url = extractYouTubeUrl(text)

  if (!url && m.quoted) {
    url = extractYouTubeUrl(m.quoted.text || m.quoted.caption || "")
  }

  if (!url) {
    return reply(`Contoh penggunaan:
${usedPrefix + command} https://youtu.be/xxxxx`)
  }

  reply("⏳ Mengambil data video...")

  try {

    const base = await fetchQuality(url, 360)

    const qualities = ["360","720","1080"]

    let downloadText = ""

    for (let q of qualities) {
      try {
        const dataQ = await fetchQuality(url, q)
        const size = await getFileSize(dataQ.download)

        downloadText += `📦 ${q}p (*${formatSize(size)}*)
${dataQ.download}

`
      } catch {}
    }

    const caption = `乂 𝗬 𝗢 𝗨 𝗧 𝗨 𝗕 𝗘   𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥
    
*Link download 📥* 👇
${downloadText}🖼 Thumbnail
${base.thumbnail}

*• Title :* ${base.title}
${readMore}
━━━━━━━━━━━━━━━━━━
👤 Channel  : ${base.author?.name || "-"}
📅 Upload   : ${base.uploadDate || "-"}
👁 Views    : ${base.views || "-"}
⏱ Durasi   : ${base.duration?.timestamp || "-"}
━━━━━━━━━━━━━━━━━━`

    await conn.sendMessage(m.chat, {
      text: caption,
      contextInfo: {
        externalAdReply: {
          title: base.title,
          body: base.author?.name || "YouTube Downloader",
          thumbnailUrl: base.thumbnail,
          mediaType: 1,
          renderLargerThumbnail: true,
          sourceUrl: url
        }
      }
    }, { quoted: m })

  } catch (e) {
    reply("❌ Gagal mengambil data.\nError: " + e.message)
  }
}

handler.command = ["yt","youtube"]
handler.help = ["yt <url>"]
handler.tags = ["downloader"]

export default handler