const handler = async (m, { conn, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya untuk grup");
  /*if (!isAdmin) return m.reply("Khusus petinggi");*/
  if (!isBotAdmin) return m.reply("Bot harus jadi admin");
  if (!m.quoted) return m.reply("Reply pesan yang ingin dihapus!");

  const q = m.quoted;

  // ✅ ambil ID pesan dengan aman
  const msgId = q.id || (q.key && q.key.id);
  if (!msgId) return m.reply("Pesan ini tidak bisa dihapus.");
await conn.sendPresenceUpdate('paused', m.chat)
  // ✅ tentukan participant dengan aman
  const participant =
    q.sender ||
    q.participant ||
    (q.key && q.key.participant);

  try {
    await conn.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        id: msgId,
        fromMe: q.fromMe || (q.key && q.key.fromMe) || false,
        participant: participant,
      },
    });
  } catch (e) {
    console.error(e);
    m.reply("Gagal menghapus pesan.");
  }
};

handler.help = ["delete"];
handler.tags = ["group"];
handler.command = ["delete", "d", "del", "deleted", "hapus", "delet", "deletee"];

export default handler;