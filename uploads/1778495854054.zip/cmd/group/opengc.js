const handler = async (m, { conn, isAdmin, isBotAdmin, command }) => {
  try {
    const isOwner =
      global.owner.includes(m.sender.split("@")[0]) ||
      global.owner.includes(m.sender);

    if (!isAdmin && !isOwner)
      return m.reply("Cuma admin atau owner yang bisa bang!");

    if (!m.isGroup) return m.reply("Khusus grup bang.");

    if (!isBotAdmin)
      return m.reply("Bot bukan admin, gabisa buka/tutup grup.");

    if (/open|buka|opengc/i.test(command)) {
      await conn.groupSettingUpdate(m.chat, "not_announcement");
      return m.reply("Grup sudah *dibuka* 🔓");
    }

    if (/close|tutup|closegc/i.test(command)) {
      await conn.groupSettingUpdate(m.chat, "announcement");
      return m.reply("Grup sudah *ditutup* 🔒");
    }

  } catch (e) {
    console.error(e);
    m.reply("Error: " + e.message);
  }
};

handler.help = ["open/close"]
handler.tags = ["group"]
handler.command = ["open", "close", "buka", "tutup", "opengc", "closegc"]

export default handler;