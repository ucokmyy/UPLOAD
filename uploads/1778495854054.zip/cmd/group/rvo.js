const handler = async (m, { conn, usedPrefix, command, isAdmin, isBotAdmin }) => {
    if (!m.isGroup) return m.reply("Fitur ini hanya untuk admin grup.");
    if (!isAdmin) return m.reply("khusus admin");
    if (!isBotAdmin) return m.reply("Bot harus jadi admin!"); // ✅ dibalik

    const quoted = m.quoted;
    if (!quoted) return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼𝗖𝗼𝗺𝗺𝗮𝗻𝗱: ${usedPrefix + command}
╠⪼𝗖𝗮𝗿𝗮 𝗣𝗮𝗸𝗮𝗶: reply media vn/foto/video 1×
║
╚═════════════╝`);

    const isViewOnce = quoted?.message?.viewOnceMessage;
    const message = isViewOnce ? quoted.message.viewOnceMessage.message : quoted;

    const mimetype =
        message.imageMessage?.mimetype ||
        message.videoMessage?.mimetype ||
        message.audioMessage?.mimetype ||
        quoted.mimetype;
    const caption =
        message.imageMessage?.caption ||
        message.videoMessage?.caption ||
        quoted.caption ||
        '';
    const mentions = Array.from(new Set(
        (caption.match(/@(\d{5,16})/g) || []).map(v => v.replace('@', '') + '@s.whatsapp.net')
    ));

    if (/image/.test(mimetype)) {
        let media = await quoted.download();
        await conn.sendMessage(m.chat, { image: media, caption, mentions }, { quoted: m });
    } else if (/video/.test(mimetype)) {
        let media = await quoted.download();
        await conn.sendMessage(m.chat, { video: media, caption, mentions }, { quoted: m });
    } else if (/audio/.test(mimetype)) {
        let media = await quoted.download();
        await conn.sendMessage(m.chat, { audio: media, mimetype: "audio/mpeg", ptt: false }, { quoted: m });
    } else {
        return m.reply("File yang dibalas harus berupa gambar, video, atau audio");
    }
};

handler.tags = ["group"];
handler.help = ["rvo"];
handler.command = ["rvo"];

export default handler;