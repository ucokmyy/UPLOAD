const delay = ms => new Promise(res => setTimeout(res, ms))

const handler = async (m, { conn, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya untuk admin grup.")
  if (!isAdmin) return m.reply("khusus admin")
  if (!isBotAdmin) return m.reply("Bot harus jadi admin!")

  const from = m.chat
  const botJid = String(conn.user.id).split('@')[0].split(':')[0]
  const botLid = conn.user?.lid ? String(conn.user.lid).split('@')[0] : (conn.authState?.creds?.me?.lid ? String(conn.authState.creds.me.lid).split('@')[0] : '')
  const ownerNumbers = global.owner.map(o => String(typeof o === 'string' ? o : o[0]).split('@')[0].split(':')[0])

  // =========================
  // KD MODE (Kick + Delete replied message)
  // =========================
  if (command === "kd") {
    if (!m.quoted) {
      return m.reply(`
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼ *Command:* ${usedPrefix + command}
╠⪼ *Cara Pakai:* Reply pesan target
╠⪼ *Contoh:* Reply pesan lalu ketik ${usedPrefix + command}
║
╚═════════════╝`)
    }

    const target = m.quoted.sender
    if (!target) return m.reply("Target tidak ditemukan.")

    const targetNumber = String(target).split('@')[0].split(':')[0]

    if (targetNumber === botJid || (botLid && targetNumber === botLid)) return m.reply("Bot tidak bisa menendang dirinya sendiri!")
    if (ownerNumbers.includes(targetNumber)) return m.reply("Nomor owner tidak dapat di-kick!")

    try {
      await conn.sendMessage(from, {
        delete: {
          remoteJid: from,
          fromMe: false,
          id: m.quoted.id,
          participant: m.quoted.sender
        }
      })
    } catch (e) {
      console.error("[KD] gagal delete:", e?.message || e)
    }

    await conn.groupParticipantsUpdate(from, [target], "remove")
    return m.reply("Done✅")
  }

  // =========================
  // MULTI KICK MODE
  // =========================
  let users = m.mentionedJid || []

  // fallback kalau reply 1 orang
  if (!users.length && m.quoted?.sender) {
    users = [m.quoted.sender]
  }

  if (!users.length) {
    return await conn.sendMessage(m.chat, { text: `
╔══⪻𝙋𝙀𝙏𝙐𝙉𝙅𝙐𝙆⪼══╗
║
╠⪼ *Command:* ${usedPrefix + command}
╠⪼ *Cara Pakai:* Tag / reply orangnya
╠⪼ *Contoh:* ${usedPrefix + command} @user @user2
║
╚═════════════╝`, mentions: [m.sender] }, { quoted: m })
  }

  if (users.length === 1) {
    const singleTargetNumber = String(users[0]).split('@')[0].split(':')[0]
    if (singleTargetNumber === botJid || (botLid && singleTargetNumber === botLid)) return m.reply("Bot tidak bisa menendang dirinya sendiri!")
    if (ownerNumbers.includes(singleTargetNumber)) return m.reply("Nomor owner tidak dapat di-kick!")
  }

  let sukses = []
  let gagal = []

  for (let user of users) {
    const userNumber = String(user).split('@')[0].split(':')[0]

    if (userNumber === botJid || (botLid && userNumber === botLid)) {
      gagal.push(`@${user.split("@")[0]}`)
      continue
    }

    if (ownerNumbers.includes(userNumber)) {
      gagal.push(`@${user.split("@")[0]}`)
      continue
    }

    try {
      await conn.groupParticipantsUpdate(from, [user], "remove")
      sukses.push(`@${user.split("@")[0]}`)
      await delay(400) // 🔥 delay 2 detik tiap kick
    } catch (e) {
      gagal.push(`@${user.split("@")[0]}`)
    }
  }

  return conn.sendMessage(m.chat, {
    text: `
✅ *Kick selesai*`.trim(),
    mentions: [...users]
  }, { quoted: m })
}

handler.command = ["kick", "k", "kd"]
handler.tags = ["group"]
handler.help = ["kick", "kd"]

export default handler