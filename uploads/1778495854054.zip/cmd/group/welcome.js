import { setWelcomeEnabled, isWelcomeEnabled } from "../../source/database/welcome.js"

const handler = async (m, { isAdmin, isOwner, text, reply }) => {
  if (!m.isGroup) return reply("Fitur khusus grup.")
  if (!isAdmin && !isOwner) return reply("Khusus admin grup.")

  const arg = String(text || "").trim().toLowerCase()

  if (!arg || !["on", "off"].includes(arg)) {
    const status = isWelcomeEnabled(m.chat) ? "ON" : "OFF"
    return reply(`Contoh:\n.welcome on\n.welcome off\n\nStatus welcome di grup ini: *${status}*`)
  }

  const currentStatus = isWelcomeEnabled(m.chat)
  const enabled = arg === "on"

  // =========================
  // TEGURAN JIKA SUDAH AKTIF / NONAKTIF
  // =========================
  if (currentStatus && enabled) {
    return reply("⚠️ Welcome sudah dalam keadaan *ON* di grup ini.")
  }

  if (!currentStatus && !enabled) {
    return reply("⚠️ Welcome sudah dalam keadaan *OFF* di grup ini.")
  }

  setWelcomeEnabled(m.chat, enabled)
  return reply(`Welcome berhasil di-*${enabled ? "ON" : "OFF"}* di grup ini.`)
}

handler.command = ["welcome"]
handler.tags = ["group"]
handler.help = ["welcome on/off"]

export default handler