const handler = async (m, { conn, usedPrefix, command, isBotAdmin }) => {
  if (!m.isGroup) return m.reply('Fitur ini hanya untuk admin grup.')
  if (!isBotAdmin) return m.reply('jadikan saya atmin dulu')

  const from = m.chat
  const response = await conn.groupInviteCode(from)
  const groupLink = `https://chat.whatsapp.com/${response}`
  const groupMetadata = await conn.groupMetadata(from)
  const groupname = groupMetadata.subject

  const buttons = [
    {
      name: 'cta_copy',
      buttonParamsJson: JSON.stringify({
        display_text: 'COPY LINK 📋',
        copy_code: groupLink
      })
    }
  ]

  const payload = {
    text: `*Link Group:* ${groupname}`,
    footer: global.botname,
    interactiveButtons: buttons
  }

  await conn.sendMessage(m.chat, payload, { quoted: m })
}

handler.command = ['linkgc', 'lgc']
handler.help = ['linkgc']
handler.tags = ['group']

export default handler