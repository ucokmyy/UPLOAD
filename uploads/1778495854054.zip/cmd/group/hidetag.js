import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const COOLDOWN_FILE = path.resolve(__dirname, '../../source/hidetag.json'); 

const ensureCooldownFile = async () => {
    await fs.ensureFile(COOLDOWN_FILE);
    const content = await fs.readFile(COOLDOWN_FILE, 'utf-8');
    if (content.trim() === '') {
        await fs.writeFile(COOLDOWN_FILE, '{}', 'utf-8');
    }
};

const handler = async (m, { conn, text, isGroup, isGroupAdmins, isBotGroupAdmins, isAdmin, isBotAdmin, command, usedPrefix, reply }) => {
    
    if (!m.isGroup) return reply("Fitur ini hanya untuk admin grup.");
    if (!isAdmin) return reply("khusus admin");

    // ✅ OWNER GA KENA COOLDOWN
    const isOwner = global.owner.includes(m.sender.split("@")[0]) || global.owner.includes(m.sender);

    await ensureCooldownFile();
    
    const commandName = 'hidetag'; 
    const cooldownKey = m.chat; 
    const cooldown = 30 * 60 * 1000; 

    const allCooldownData = await fs.readJson(COOLDOWN_FILE);
    
    if (!allCooldownData[commandName]) {
        allCooldownData[commandName] = {};
    }
    
    const commandCooldowns = allCooldownData[commandName];
    const lastTime = commandCooldowns[cooldownKey] || 0;
    const now = Date.now();
    
    // ✅ cek cooldown cuma kalau BUKAN owner
    if (!isOwner && now - lastTime < cooldown) {
        const remainingMs = cooldown - (now - lastTime);
        const hours = Math.floor(remainingMs / (60 * 60 * 1000));
        const minutes = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000));
        const seconds = Math.ceil((remainingMs % (60 * 60 * 1000)) / 1000);
        
        let timeRemaining = [];
        if (hours > 0) timeRemaining.push(`${hours} jam`);
        if (minutes > 0) timeRemaining.push(`${minutes} menit`);
        if (seconds > 0) timeRemaining.push(`${seconds} detik`);
        
        return reply(`Command *${usedPrefix + command}* baru saja di gunakan
harap gunakan setelah 30 menit, dengan alasan menghindari spam`);
    }

    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants.map(a => a.id);

    const tek = m.quoted?.text || text || ""

    const fkontak = {
        key: {
            participants: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            fromMe: false,
            id: "Halo"
        },
        message: {
            contactMessage: {
                vcard:
                    `BEGIN:VCARD\nVERSION:3.0\n` +
                    `N:Sy;Bot;;;\nFN:y\n` +
                    `item1.TEL;waid=${m.sender.split("@")[0]}:${m.sender.split("@")[0]}\n` +
                    `item1.X-ABLabel:Ponsel\nEND:VCARD`
            }
        },
        participant: "0@s.whatsapp.net"
    };

    await conn.sendMessage(
        m.chat,
        { text: tek, mentions: participants },
        { quoted: fkontak }
    );

    // ✅ simpan cooldown cuma kalau BUKAN owner
    if (!isOwner) {
        commandCooldowns[cooldownKey] = now;
        allCooldownData[commandName] = commandCooldowns;
        await fs.writeJson(COOLDOWN_FILE, allCooldownData, { spaces: 2 });
    }
};

handler.help = ["hidetag"];
handler.tags = ["group"];
handler.command = ["hidetag", "h", "htag"];

export default handler;