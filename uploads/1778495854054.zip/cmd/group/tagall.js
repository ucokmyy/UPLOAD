import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename)
const COOLDOWN_FILE = path.resolve(__dirname, '../../source/tagall.json'); 
const ensureCooldownFile = async () => {
    await fs.ensureFile(COOLDOWN_FILE);
    const content = await fs.readFile(COOLDOWN_FILE, 'utf-8');
    if (content.trim() === '') {
        await fs.writeFile(COOLDOWN_FILE, '{}', 'utf-8');
    }
};

const handler = async (m, { conn, usedPrefix, command, isGroup, isGroupAdmins, isBotGroupAdmins, isAdmin, isBotAdmin, text, reply }) => {
    
    if (!isGroup) return reply("Fitur ini hanya untuk admin grup")
    if (!isAdmin) return reply("khusus admin")
    await ensureCooldownFile();
    
    const commandName = 'tagall'
    const cooldownKey = m.chat
    const cooldown = 30 * 60 * 1000

    const allCooldownData = await fs.readJson(COOLDOWN_FILE);
    
    if (!allCooldownData[commandName]) {
        allCooldownData[commandName] = {};
    }
    
    const commandCooldowns = allCooldownData[commandName];
    const lastTime = commandCooldowns[cooldownKey] || 0;
    const now = Date.now();
    
    if (now - lastTime < cooldown) {
        const remainingMs = cooldown - (now - lastTime);
        const hours = Math.floor(remainingMs / (60 * 60 * 1000));
        const minutes = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000));
        const seconds = Math.ceil((remainingMs % (60 * 1000)) / 1000);
        
        let timeRemaining = [];
        if (hours > 0) timeRemaining.push(`${hours} jam`);
        if (minutes > 0) timeRemaining.push(`${minutes} menit`);
        if (seconds > 0) timeRemaining.push(`${seconds} detik`);
        
        return reply(`Command *${usedPrefix + command}* baru saja di gunakan, harap tunggu sekitar 30 menit`);
    }
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants.map(a => a.id);
    const q = text ? text : 'none';

    let teks = `
╔═════▣「 ALL TAG 🚨 」▣═════▣
║ 💬 *Pesan : ${q}*
╠═══════════════════════▣
`;

    for (let mem of participants) {
        if (mem) {
            teks += `║ • @${mem.split('@')[0]}\n`;
        }
    }

    await conn.sendMessage(m.chat, { text: teks, mentions: participants }, { quoted: m });
    commandCooldowns[cooldownKey] = now;
    allCooldownData[commandName] = commandCooldowns;
    await fs.writeJson(COOLDOWN_FILE, allCooldownData, { spaces: 2 });
};

handler.help = ["tagall"];
handler.command = ["tagall"];
handler.tags = ["group"];
export default handler;