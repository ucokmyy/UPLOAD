const handler = async (m, { conn, isGroup, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di grup.")

  if (!isAdmin) return m.reply("Khusus Admin.")

  try {
    const pp = await conn.profilePictureUrl(m.chat, "image")
    
    await conn.sendMessage(
      m.chat,
      {
        image: { url: pp },
        caption: `📸 Profile Picture Group`
      },
      { quoted: m }
    )

  } catch (e) {
    m.reply("Grup ini tidak memiliki foto profil.")
  }
}

handler.command = ["getppgc"]
handler.tags = ["group"]
handler.help = ["getppgc"]

export default handler