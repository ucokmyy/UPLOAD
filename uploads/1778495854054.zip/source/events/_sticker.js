import "../../settings/config.js";
import axios from 'axios';
import sharp from 'sharp';
import fs from 'fs';
import {
    imageToWebp,
    videoToWebp,
    writeExifImg,
    writeExifVid,
    addExif
} from './exif.js';

export async function makeStickerFromUrl(mediaUrl, sock, m, reply) {
    try {
        let buffer;
        let contentType;
        if (mediaUrl.startsWith("data:")) {
            const base64Data = mediaUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
            contentType = mediaUrl.split(';')[0].split(':')[1];
        
        } else {
            const response = await axios.get(mediaUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data); 
            contentType = response.headers['content-type'];
        }

        let webpBuffer;

        console.log(`Media type terdeteksi: ${contentType}`);
        if (contentType && contentType.includes('video')) {
            console.log('Memproses sebagai video...');
            webpBuffer = await videoToWebp(buffer);

        } else if (contentType && (contentType.includes('image') || contentType.includes('gif'))) {
            console.log('Memproses sebagai gambar/gif...');
            webpBuffer = await sharp(buffer, { animated: true })
                .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
                .webp({ quality: 80 })
                .toBuffer();
        } else {

            throw new Error(`Unsupported media type: ${contenType || 'unknown'}`);
        }
        const stickerWithExif = await addExif(webpBuffer, global.namebotz, global.footer);

        await sock.sendMessage(m.chat, {
            sticker: stickerWithExif/*,
            contextInfo: {
                externalAdReply: {
                    title: global.namebotz,
                    body: global.nameown,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    thumbnailUrl: `https://files.catbox.moe/prewfa.jpg`,
                    sourceUrl: global.YouTube
                }
            }*/
        }, { quoted: m });

    } catch (error) {
        console.error("Error creating sticker:", error);
        reply('Gagal membuat stiker. Pastikan format media didukung (Gambar/Video/GIF).');
    }
}
