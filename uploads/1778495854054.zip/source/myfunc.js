import {
default as makeWASocket,
useMultiFileAuthState,
jidDecode,
getContentType,
DisconnectReason,
generateWAMessage,
areJidsSameUser,
downloadContentFromMessage
} from "@whiskeysockets/baileys";
import chalk from 'chalk'
import axios from "axios";
import fs from "fs";
import fetch from "node-fetch";
import * as jimp from "jimp";
import { fileTypeFromBuffer } from "file-type";

async function downloadFromMessageContent(contentObj, mtype) {
const typeMap = {
imageMessage: "image",
videoMessage: "video",
stickerMessage: "sticker",
documentMessage: "document",
audioMessage: "audio"
};
const mediaKind = typeMap[mtype];
if (!mediaKind) return null;
const stream = await downloadContentFromMessage(contentObj, mediaKind);
let buffer = Buffer.alloc(0);
for await (const chunk of stream) {
buffer = Buffer.concat([buffer, chunk]);
}
return buffer;
}

export const smsg = (conn, m, store) => {
if (!m || m.mtype === "protocolMessage" || m.mtype === "senderKeyDistributionMessage") {
return m;
}
if (m.key) {
m.id = m.key.id;
m.isBaileys = m.id && m.id.startsWith("BAE5") && m.id.length === 16;
m.chat = m.key.remoteJid;
m.fromMe = m.key.fromMe;
m.isGroup = m.chat ? m.chat.endsWith("@g.us") : false;
m.sender = conn.decodeJid(
(m.fromMe && conn.user.id) ||
m.participant ||
m.key.participant ||
m.chat ||
""
);
if (m.isGroup) m.participant = conn.decodeJid(m.key.participant) || "";
}
if (m.message) {
m.mtype = getContentType(m.message);
m.msg = m.mtype === "viewOnceMessage"
? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)]
: m.message[m.mtype];
m.body =
m.message.conversation ||
m.msg?.caption ||
m.msg?.text ||
(m.mtype === "listResponseMessage" && m.msg?.singleSelectReply?.selectedRowId) ||
(m.mtype === "buttonsResponseMessage" && m.msg?.selectedButtonId) ||
(m.mtype === "interactiveResponseMessage" && JSON.parse(m.msg.nativeFlowResponseMessage?.paramsJson || "{}")?.id) ||
(m.mtype === "viewOnceMessage" && m.msg?.caption) ||
m.text;

let quoted = (m.quoted = m.msg?.contextInfo ? m.msg.contextInfo.quotedMessage : null);
m.mentionedJid = m.msg?.contextInfo ? m.msg.contextInfo.mentionedJid : [];
if (m.quoted) {
let type = Object.keys(m.quoted)[0];
m.quoted = m.quoted[type];
if (type === "productMessage") {
type = Object.keys(m.quoted)[0];
m.quoted = m.quoted[type];
}
if (typeof m.quoted === "string") {
m.quoted = { text: m.quoted };
}
m.quoted.mtype = type;
m.quoted.id = m.msg.contextInfo.stanzaId;
m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat;
m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith("BAE5") && m.quoted.id.length === 16 : false;
m.quoted.sender = conn.decodeJid(m.msg.contextInfo.participant);
m.quoted.fromMe = m.quoted.sender === conn.decodeJid(conn.user.id);
m.quoted.text =
m.quoted.text ||
m.quoted.caption ||
m.quoted.conversation ||
m.quoted.contentText ||
m.quoted.selectedDisplayText ||
m.quoted.title ||
"";
m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
m.getQuotedObj = m.getQuotedMessage = async () => {
if (!m.quoted.id) return false;
const q = await store.loadMessage(m.chat, m.quoted.id, conn);
return smsg(conn, q, store);
};
let vM = (m.quoted.fakeObj = JSON.parse(JSON.stringify(m)));
m.quoted.delete = () => conn.sendMessage(m.quoted.chat, { delete: vM.key });
m.quoted.copyNForward = (jid, forceForward = false, options = {}) => conn.copyNForward(jid, vM, forceForward, options);
m.quoted.download = async () => downloadFromMessageContent(m.quoted, type);
}
}
if (m.msg?.url) m.download = async () => downloadFromMessageContent(m.msg, m.mtype);
m.text =
m.msg?.text ||
m.msg?.caption ||
m.message?.conversation ||
m.msg?.contentText ||
m.msg?.selectedDisplayText ||
m.msg?.title ||
"";
m.reply = async (text, options = {}) => {
if (Buffer.isBuffer(text)) {
return conn.sendMedia(m.chat, text, "file", "", m, { ...options });
} else {
let mentionIds = [];
if (options.mentions) {
mentionIds = options.mentions;
delete options.mentions;
}
return conn.sendText(m.chat, text, m, { mentions: mentionIds, ...options });
}
};
m.copy = () => smsg(conn, JSON.parse(JSON.stringify(m)));
m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => conn.copyNForward(jid, m, forceForward, options);
conn.appenTextMessage = async (text, chatUpdate) => {
let messages = await generateWAMessage(
m.chat,
{ text: text, mentions: m.mentionedJid },
{ userJid: conn.user.id, quoted: m.quoted && m.quoted.fakeObj }
);
messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id);
messages.key.id = m.key.id;
messages.pushName = m.pushName;
if (m.isGroup) messages.participant = m.sender;
let msg = { ...chatUpdate, messages: [messages], type: "append" };
conn.ev.emit("messages.upsert", msg);
};
return m;
};

export const generateProfilePicture = async (buffer) => {
const j1 = await jimp.read(buffer);
const resized = j1.getWidth() > j1.getHeight() ? j1.resize(550, jimp.AUTO) : j1.resize(jimp.AUTO, 650);
return { img: await resized.getBufferAsync(jimp.MIME_JPEG) };
};

export const resizeImage = async (buffer, width, height) => {
try {
const image = await jimp.read(buffer);
const resizedImage = image.resize(width, height);
const resultBuffer = await resizedImage.getBufferAsync(jimp.MIME_JPEG);
return resultBuffer;
} catch {
return null;
}
};

export const getRandom = (ext) => `${Math.floor(Math.random() * 10000)}${ext}`;

export const getBuffer = async (url, options) => {
try {
const res = await axios({
method: "get",
url,
headers: { DNT: 1, "Upgrade-Insecure-Request": 1 },
...options,
responseType: "arraybuffer"
});
return res.data;
} catch {}
};

export const fetchJson = (url, options) => new Promise((resolve, reject) => {
fetch(url, options).then(r => r.json()).then(resolve).catch(reject);
});

export const fetchText = (url, options) => new Promise((resolve, reject) => {
fetch(url, options).then(r => r.text()).then(resolve).catch(reject);
});

export const getGroupAdmins = (participants) => {
let admins = [];
for (let i of participants) if (i.admin !== null) admins.push(i.id);
return admins;
};

export const runtime = (seconds) => {
seconds = Number(seconds);
let d = Math.floor(seconds / 86400);
let h = Math.floor(seconds % 86400 / 3600);
let m = Math.floor(seconds % 3600 / 60);
let s = Math.floor(seconds % 60);
return (d ? d + " day, " : "") + (h ? h + " hour, " : "") + (m ? m + " minute, " : "") + (s ? s + " second" : "");
};

export const removeEmojis = (string) => {
return string.replace(/(?:[\u2700-\u27bf]|[\ud800-\udfff])/g, "");
};

export const calculate_age = (dob) => {
return Math.abs(new Date(Date.now() - dob.getTime()).getUTCFullYear() - 1970);
};

export const sleep = (ms) => new Promise(r => setTimeout(r, ms));

export const url = (url) => {
return url.match(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/gi);
};

export const makeid = (length) => {
let result = "";
const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
for (let i = 0; i < length; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
return result;
};
global.loadConnect = async function (t) {
  try {
    console.log(chalk.blue('Good luck'))
  } catch (e) {
  }
}