import fs from 'fs';

export const qtext = {
  key: {
    remoteJid: 'status@broadcast',
    fromMe: false,
    participant: '0@s.whatsapp.net'
  },
  message: {
    newsletterAdminInviteMessage: {
      newsletterJid: '120363320632446478@newsletter',
      caption: `CIMMY WA BOT !`,
      inviteExpiration: 0
    }
  }
};

export const metaai = {
  key: {
    remoteJid: "status@broadcast",
    fromMe: false,
    id: 'FAKE_META_ID_001',
    participant: '13135550002@s.whatsapp.net'
  },
  message: {
    contactMessage: {
      displayName: 'CIMMY WA BOT',
      vcard: `BEGIN:VCARD
VERSION:3.0
N:XzVortex;;;;
FN:XzVortex🚀
TEL;waid=13135550002:+1 313 555 0002
END:VCARD`
    }
  }
};