/*
    © credate by fauzialifatah 
    ~> hargai pembuatan script base, karna saya tau alur dan susunan script tersebut terimakasih🚀🎉
    
*/
import "../settings/config.js";
import {
BufferJSON,
WA_DEFAULT_EPHEMERAL,
generateWAMessageFromContent,
generateWAMessageContent,
generateWAMessage,
prepareWAMessageMedia,
areJidsSameUser,
getContentType
} from "@whiskeysockets/baileys";
import moment from 'moment-timezone'
const cooldown = new Map()
const msgStore = new Map();
import fs from "fs-extra";
import util from "util";
import chalk from "chalk";
import { exec, spawn } from "child_process";
import axios from "axios";
import fetch from 'node-fetch';
import syntaxerror from "syntax-error";
import { fileURLToPath } from "url";
import path from "path";
import os from "os";
import * as jimp from "jimp";
import speed from "performance-now";
import {
generateProfilePicture,
getBuffer,
fetchJson,
fetchText,
getRandom,
runtime,
sleep,
makeid
} from "../source/myfunc.js";

import { qtext, metaai } from "../source/quoted.js";
import { runPlugins, pluginsLoader } from "../handler.js";
import { makeStickerFromUrl } from "../source/events/_sticker.js";
import { loadAfk, saveAfk, formatDuration } from "./lib/afk.js"
import { isAllowedGroup } from "./database/grupakses.js"

global.autoRestartStart = global.autoRestartStart || Date.now()

global.AUTO_RESTART_HOURS = 5
global.AUTO_RESTART_MS = global.AUTO_RESTART_HOURS * 60 * 60 * 1000


if (global.__AUTO_RESTART_INTERVAL__) {
  clearInterval(global.__AUTO_RESTART_INTERVAL__)
  global.__AUTO_RESTART_INTERVAL__ = null
}

global.__AUTO_RESTART_INTERVAL__ = setInterval(() => {
  try {
    const now = Date.now()
    const runtime = now - global.autoRestartStart

    if (runtime >= global.AUTO_RESTART_MS) {
      console.log(`\n[ AUTO RESTART ] Triggered after ${global.AUTO_RESTART_HOURS} hours\n`)

      
      global.autoRestartStart = Date.now()


      process.exit(1)
    }
  } catch (e) {
    console.error("AUTO RESTART ERROR:", e)
  }
}, 1000)

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const uploadUguu = async (filePath) => {
return new Promise(resolve => {
exec(`curl -s -F "files[]=@${filePath}" https://uguu.se/upload.php`, (_, out) => {
try {
resolve(JSON.parse(out).files[0].url)
} catch {
resolve(null)
}
})
})
}

let prefix = ".";

function levenshtein(a, b) {
const dp = Array.from({ length: a.length + 1 }, (_, i) =>
Array.from({ length: b.length + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
);
for (let i = 1; i <= a.length; i++) {
for (let j = 1; j <= b.length; j++) {
dp[i][j] =
a[i - 1] === b[j - 1]
? dp[i - 1][j - 1]
: Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]) + 1;
}
}
return dp[a.length][b.length];
}

function similarityPercent(a, b) {
const maxLength = Math.max(a.length, b.length);
if (maxLength === 0) return 100;
const distance = levenshtein(a, b);
const similarity = ((maxLength - distance) / maxLength) * 100;
return Math.round(similarity);
}

async function getCaseCommands(filePath) {
try {
const code = await fs.promises.readFile(filePath, "utf8");
const regex = /case\s+['"](.*?)['"]/g;
const matches = [];
let match;
while ((match = regex.exec(code)) !== null) matches.push(match[1]);
return matches;
} catch {
return [];
}
}

function getWIBTime() {
  return new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  })
    .format(new Date())
    .replace(/\./g, ":")
}

export default async (conn, m) => {
  try {
    try {
      const raw =
        m.body ||
        m.text ||
        m.message?.conversation ||
        m.message?.extendedTextMessage?.text ||
        m.message?.imageMessage?.caption ||
        m.message?.videoMessage?.caption ||
        "";

      if (/^\.\s+/.test(raw)) {
        const fixed = raw.replace(/^\.\s+/, ".");
        m.text = fixed;
        m.body = fixed;
      }
    } catch {}

    let msg = m.message || {};
    if (msg?.ephemeralMessage) msg = msg.ephemeralMessage.message;
    if (msg?.viewOnceMessage) msg = msg.viewOnceMessage.message;

    let parsedBody = "";

    if (msg.conversation) parsedBody = msg.conversation;
    else if (msg.extendedTextMessage) parsedBody = msg.extendedTextMessage.text;
    else if (msg.imageMessage) parsedBody = msg.imageMessage.caption || "";
    else if (msg.videoMessage) parsedBody = msg.videoMessage.caption || "";
    else if (msg.documentMessage) parsedBody = msg.documentMessage.caption || "";
    else if (msg.buttonsResponseMessage)
      parsedBody = msg.buttonsResponseMessage.selectedButtonId;
    else if (msg.listResponseMessage)
      parsedBody = msg.listResponseMessage.singleSelectReply.selectedRowId;
    else if (msg.templateButtonReplyMessage)
      parsedBody = msg.templateButtonReplyMessage.selectedId;
    else if (msg.interactiveResponseMessage) {
      try {
        const json = JSON.parse(
          msg.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson
        );
        parsedBody = json.id || "";
      } catch {}
    }

    if (parsedBody) {
      m.text = parsedBody;
      m.body = parsedBody;
    }

let body = m.body || m.text || "";
const afk = loadAfk();
let budy = body;


    async function resolveJid(jid, conn) {
      if (!jid) return jid;
      if (jid.includes(":")) {
        jid = jid.split(":")[0] + jid.substring(jid.indexOf("@"));
      }
      if (jid.endsWith("@lid")) {
        try {
          const pn = await conn?.signalRepository?.lidMapping?.getPNForLID?.(jid);
          if (pn) {
            jid = pn;
            if (jid.includes(":")) {
              jid = jid.split(":")[0] + jid.substring(jid.indexOf("@"));
            }
          }
        } catch {}
      }
      return jid;
    }

    async function addLIDIfMissing(jid, afk, conn) {
      if (!jid || jid.endsWith("@lid")) return;
      if (!afk[jid]) return;
      try {
        if (!afk[jid].lid) {
          let lid = await conn.signalRepository?.lidMapping?.getLIDForPN(jid).catch(() => null);
          if (!lid) lid = (await conn.onWhatsApp(jid).then(a => a?.[0]?.lid).catch(() => null)) || null;
          if (lid) {
            if (lid.includes(":")) lid = lid.split(":")[0] + lid.substring(lid.indexOf("@"));
            afk[jid].lid = lid;
          }
        }
      } catch {}
    }

let bodyText = (
  m.body ||
  m.text ||
  m.message?.conversation ||
  m.message?.extendedTextMessage?.text ||
  m.message?.imageMessage?.caption ||
  m.message?.videoMessage?.caption ||
  ""
).trim();

let isEditMessage = false;
let textBeforeEdit = "";
let textAfterEdit = "";

if (m.mtype === 'protocolMessage') {
  const pm = m.msg || m.message?.protocolMessage;
  if (pm && pm.type === 14) {
    isEditMessage = true;
    const editKey = pm.key?.id;
    textBeforeEdit = msgStore.get(editKey) || "(tidak diketahui)";
    const edited = pm.editedMessage || {};
    const newText = edited.conversation || edited.extendedTextMessage?.text || '';
    if (newText) {
      textAfterEdit = newText;
      body = newText;
      budy = newText;
      bodyText = newText;
      m.text = newText;
      m.body = newText;
      if (editKey) msgStore.set(editKey, newText);
    }
  }
} else if (m.key?.id && bodyText) {
  msgStore.set(m.key.id, bodyText);
}


    const isMediaMessage = [
      "stickerMessage",
      "audioMessage",
      "videoMessage",
      "imageMessage",
      "documentMessage",
      "locationMessage",
    ].includes(m.mtype);

    const isGif =
      m.mtype === "videoMessage" &&
      m.message?.videoMessage?.gifPlayback === true;

    const isRealUserActivity =
      !m.key.fromMe &&
      !m.isBot &&
      !m.message?.protocolMessage &&
      m.mtype !== "reactionMessage" &&
      (bodyText.length > 0 || isMediaMessage || isGif);

    const isFreshMessage =
      !m.messageTimestamp ||
      Math.abs(Date.now() - m.messageTimestamp * 1000) < 60000;

    const sender1 = await resolveJid(m.sender, conn);

    if (isRealUserActivity && isFreshMessage && afk[sender1]) {
      const data = afk[sender1];
      const duration = Date.now() - data.time;

      try {
        const totalAfkPath = "./source/database/totalafk.json";
        let totalAfk = {};

        if (fs.existsSync(totalAfkPath)) {
          totalAfk = JSON.parse(fs.readFileSync(totalAfkPath));
        }

        if (!totalAfk[sender1]) totalAfk[sender1] = { time: 0 };
        if (duration > totalAfk[sender1].time) totalAfk[sender1].time = duration;

        fs.writeFileSync(totalAfkPath, JSON.stringify(totalAfk, null, 2));
      } catch {}

      delete afk[sender1];
      saveAfk(afk);

      const reasonText = data.reason ? ` setelah ${data.reason}` : "";

      await conn.sendMessage(
        m.chat,
        {
          text: `*@${sender1.split("@")[0]}* telah kembali dari AFK${reasonText}\n𝗦𝗲𝗹𝗮𝗺𝗮: ${formatDuration(duration)}`,
          mentions: [sender1],
        },
        { quoted: m }
      );
    }

    let rawTargets = [];
    const contextInfo =
      msg?.extendedTextMessage?.contextInfo ||
      msg?.imageMessage?.contextInfo ||
      msg?.videoMessage?.contextInfo ||
      msg?.documentMessage?.contextInfo ||
      msg?.contextInfo ||
      {};

    if (Array.isArray(contextInfo.mentionedJid)) {
      rawTargets.push(...contextInfo.mentionedJid);
    }

    if (contextInfo.participant) {
      rawTargets.push(contextInfo.participant);
    }

    if (m?.quoted?.sender) {
      rawTargets.push(m.quoted.sender);
    }

    const finalTargets = [
      ...new Set(
        (
          await Promise.all(rawTargets.map(jid => resolveJid(jid, conn)))
        ).filter(v => v && v.includes("@"))
      ),
    ];

    await Promise.all(Object.keys(afk).map(jid => addLIDIfMissing(jid, afk, conn)));
    saveAfk(afk);

    if (!m.key.fromMe) {
      for (const jid of finalTargets) {
        if (jid === sender1) continue;

        const data =
          afk[jid] ||
          Object.values(afk).find(v => v.lid === jid || v.id === jid);

        if (!data) continue;

        const duration = Date.now() - data.time;
        let txt = ""

const isReply = m.quoted && m.quoted.sender === jid

if (isReply) {
  txt = `orang yang kamu reply lagi AFK`
} else {
  txt = `orang yang kamu tag lagi AFK`
}

if (data.reason) {
  txt += `\n𝗞𝗮𝘁𝗮𝗻𝘆𝗮: ${data.reason}`
}

txt += `\n𝖽𝗂𝖺 𝗎𝖽𝖺𝗁 𝖺𝖿𝗄 𝗌𝖾𝗅𝖺𝗆𝖺 ${formatDuration(duration)}`

        await conn.sendMessage(
          m.chat,
          { text: txt },
          { quoted: m }
        );
      }
    }

    const args = body
      .slice(typeof prefix !== 'undefined' ? prefix.length : 1)
      .trim()
      .split(/\s+/)
      .slice(1);

    const text = args.join(" ");
    
const q = text
const sender = m.sender
const ownerNumbers = Array.isArray(global.owner)
  ? global.owner.map(v => String(v).replace(/[^0-9]/g, ""))
  : []

const primaryOwnerNumber = String(global.primaryOwner || "").replace(/[^0-9]/g, "")
const senderNumber = String(sender || "").replace(/[^0-9]/g, "")

const rawIsOwner =
  global.owner.includes(sender.split("@")[0]) ||
  global.owner.includes(sender) ||
  ownerNumbers.some(num => senderNumber.startsWith(num))

const isPrimaryOwner = !!primaryOwnerNumber && senderNumber.startsWith(primaryOwnerNumber)

const currentMode = global.mode || "public"

// owner efektif untuk owner eval / shell / fitur owner built-in
const isOwner =
  currentMode === "ownerly" || currentMode === "oneown"
    ? isPrimaryOwner
    : rawIsOwner
if (body.startsWith("$")) {
  if (!isOwner) return

  const q = body.slice(1).trim()
  if (!q) return m.reply("Command kosong")

  await m.reply("_Executing..._")
  exec(q, { timeout: 15000, maxBuffer: 1024 * 1024 }, async (err, stdout, stderr) => {
    if (err) return m.reply(String(err))
    if (stderr) await m.reply(String(stderr))
    if (stdout) await m.reply(String(stdout))
  })
  return
}

if (body.startsWith(">")) {  
  if (!isOwner) return  
  try {  
    const txtt = util.format(await eval(`(async()=>{ ${q} })()`));  
    m.reply(txtt);  
  } catch (e) {  
    let _syntax = "";  
    let _err = util.format(e);  
    let err = syntaxerror(q, "EvalError", {  
      allowReturnOutsideFunction: true,  
      allowAwaitOutsideFunction: true,  
      sourceType: "module"  
    });  
    if (err) _syntax = err + "\n\n";  
    m.reply(util.format(_syntax + _err));  
  }  
}  

if (body.startsWith("=>")) {  
  if (!isOwner) return  
  try {  
    const txtt = util.format(await eval(`(async()=>{ return ${q} })()`));  
    m.reply(txtt);  
  } catch (e) {  
    let _syntax = "";  
    let _err = util.format(e);  
    let err = syntaxerror(q, "EvalError", {  
      allowReturnOutsideFunction: true,  
      allowAwaitOutsideFunction: true,  
      sourceType: "module"  
    });  
    if (err) _syntax = err + "\n\n";  
    m.reply(util.format(_syntax + _err));  
  }  
}

/*//AUTO AI NIEEEE
const BOT_JID = '6282159019459@s.whatsapp.net';
const q_ai = m.quoted;
if (m.key.fromMe) return
if (q_ai && q_ai.sender === BOT_JID && body && !body.startsWith(prefix)) {
  let prompt = m.text;

  const bucket = Math.floor(Date.now() / 1800000);
  const param = new URLSearchParams({
    text: prompt,
    systemPrompt: `Kamu adalah AI bernama Reyy. Gaya bicara kamu santai dan akrab kayak temen, pakai campuran kata gua, elu, aku, kamu sesuai konteks biar natural. Kalau user lagi ngobrol biasa atau cuma basa-basi, kamu wajib jawab singkat, to the point, dan jelas, cukup 1–2 kalimat kalau sudah menjawab maksudnya.

Bahasa lu ngk usah formal banget, hasil jawaban lu ngk usah banyak yappiing dan penjelasan yang ngk perlu di berikan ke user, kasih jawaban yang kelas dan cool jangan baku, kalo jawaban nya ada list list, kasih list aja ngk usah pakai penjelasan.

Kamu nggak boleh pakai emoji di semua percakapan, dan kamu hanya boleh pakai emoji kalau jawaban kamu panjang atau penjelasan rumit, itu pun secukupnya dan jangan kebanyakan. Untuk jawaban singkat atau ngobrol biasa, tanpa emoji.`,
    sessionId: `${m.sender}_${bucket}`
  });

  const r = await fetch(`https://rynekoo-api.hf.space/text.gen/gpt/5-nano?${param}`);
  const j = await r.json();

  if (j.success) {
    return await conn.sendMessage(m.chat, { text: j.result }, { quoted: m });
  }
}
*/

// ===============================
// AGAR BUTTON TERBACA SEBAGAI COMMAND
// ===============================


// ===============================
const isGroup = m.key.remoteJid.endsWith("@g.us");
let groupName = "";

if (isGroup) {
  const meta = await conn.groupMetadata(m.chat).catch(() => null)
  groupName = meta?.subject || "Unknown Group"
}



if (!body || typeof body !== "string") return
if (!body.startsWith(prefix)) return

if (m.message && !m.key.fromMe && bodyText.length > 0) {
  const time = `${getWIBTime()} WIB`
  const line = chalk.magenta("│")
  const who = `${chalk.yellowBright(m.pushName)} ${chalk.gray("(" + m.sender + ")")}`
  const place = isGroup ? chalk.cyan("Group: " + groupName) : chalk.greenBright("Private")
  const topBorder = chalk.magenta("╭" + "─".repeat(40) + "╮")
  const botBorder = chalk.magenta("╰" + "─".repeat(40) + "╯")

  if (isEditMessage) {
    console.log(
      topBorder,
      `\n${line} 🕐 ${chalk.white(time)}`,
      `\n${line} 📝 ${chalk.yellowBright("Type: Edited")}`,
      `\n${line} ⏪ ${chalk.white("Sebelum: " + textBeforeEdit)}`,
      `\n${line} ⏩ ${chalk.white("Sesudah: " + textAfterEdit)}`,
      `\n${line} 👤 ${who}`,
      `\n${line} 📍 ${place}`,
      `\n${botBorder}\n`
    )
  } else {
    console.log(
      topBorder,
      `\n${line} 🕐 ${chalk.white(time)}`,
      `\n${line} 💬 ${chalk.white(budy || m.mtype)}`,
      `\n${line} 👤 ${who}`,
      `\n${line} 📍 ${place}`,
      `\n${botBorder}\n`
    )
  }
}


let command = body
  .slice(prefix.length)
  .trim()
  .split(/\s+/)[0]
  ?.toLowerCase()

if (!command) return

const commands = command





const quoted = m.quoted ? m.quoted : m;  
const message = m;  
const messageType = m.mtype;  
const messageKey = message.key;  
const pushName = m.pushName || "Undefined";  
const usedPrefix = prefix  
const itsMe = m.key.fromMe;
const chat = m.chat;  

const userId = sender.split("@")[0];  
const reply = m.reply;  

const botNumber = conn.user.id.split(":")[0] + "@s.whatsapp.net";  
;  
 let groupMetadata = {}  
const groupMetadata2 = m.isGroup ? await conn.groupMetadata(m.chat) : {}

const participants = m.isGroup ? groupMetadata2.participants : []
const useLid = groupMetadata2.addressingMode === 'lid'

let groupId = "";
let groupMembers = [];
let isGroupAdmins = false;
let isBotGroupAdmins = false;
let me = {};
let user = {}
let bot = {}

if (m.isGroup) {
if (useLid) {
const senderLid = participants.find(p => p.jid === conn.decodeJid(m.sender))?.lid
const botLid = participants.find(p => p.jid === conn.decodeJid(conn.user.id))?.lid
user = participants.find(p => p.lid === senderLid) || {}  
bot = participants.find(p => p.lid === botLid) || {}
} else {
user = participants.find(u => conn.decodeJid(u.id || u.jid) === conn.decodeJid(m.sender)) || {}
bot = participants.find(u => conn.decodeJid(u.id || u.jid) === conn.decodeJid(conn.user.id)) || {}
}
}

const safe = async (fn, fallback = undefined) => {
try {
return await fn();
} catch {
return fallback;
}
};

/*const groupMetadataa = m.isGroup
  ? await conn.groupMetadata(m.chat).catch(_ => (conn.chats?.[m.chat]?.metadata || {}))
  : {};
/* digunakan kalo pake baileys ori
const participantss = groupMetadataa?.participants || [];
const senderJid = conn.decodeJid(m.sender);
const botJid = conn.decodeJid(botNumber);
const map = Object.fromEntries(participantss.map(p => [p.phoneNumber, p]));
const user2 = map[senderJid] || {};
const bott = map[botJid] || {};
const isRAdmin = user2?.admin === "superadmin";
const isAdmin = isRAdmin || user2?.admin === "admin";
const isBotAdmin = bott?.admin === "admin" || bott?.admin === "superadmin";
*/
const groupMetadataa = m.isGroup
  ? await conn.groupMetadata(m.chat).catch(_ => (conn.chats?.[m.chat]?.metadata || {}))
  : {};

const participantss = groupMetadataa?.participants || [];

const senderJid = conn.decodeJid(m.sender);
const botJid = conn.decodeJid(botNumber);
const map = Object.fromEntries(
  participantss.map(p => [conn.decodeJid(p.jid), p])
);

const user2 = map[senderJid] || {};
const bott = map[botJid] || {};

const isRAdmin = user2?.admin === "superadmin";
const isAdmin = isRAdmin || user2?.admin === "admin";
const isBotAdmin = bott?.admin === "admin" || bott?.admin === "superadmin";
if (isGroup) {
groupMetadata = await conn.groupMetadata(chat).catch(() => ({}));
groupName = groupMetadata.subject || "";
groupId = groupMetadata.id || "";
groupMembers = groupMetadata.participantss || [];
isGroupAdmins = !!groupMembers.find((p) => p.admin && p.id === sender);
isBotGroupAdmins = !!groupMembers.find((p) => p.admin && p.id === botNumber);
me = groupMembers.find(p => p.id === m.sender || p.jid === m.sender) || {};
}

const TypeMess = getContentType(m?.message);  
let reactions = TypeMess == "reactionMessage" ? m?.message[TypeMess]?.text : false;  





const isSpecialGroup = m.chat === global.idself

const isAllowed =
  currentMode === "public"
    ? true
    : currentMode === "self"
    ? (itsMe || rawIsOwner || isSpecialGroup)
    : currentMode === "ownerly"
    ? (itsMe || isPrimaryOwner)
    : currentMode === "oneown"
    ? (itsMe || isPrimaryOwner || isSpecialGroup)
    : true

// ==========================
// CEK AKSES GRUP (TARUH DI SINI)
// ==========================
const allowedGroup = isAllowedGroup(m.chat)

// OWNER BYPASS SEMUA
if (rawIsOwner || isPrimaryOwner) {
  // lanjut aja, jangan di return
} else {
  if (m.isGroup && !allowedGroup && m.chat !== global.idself) {
    return
  }
}

if (!isAllowed) return



try {
  const totalUsePath = "./source/database/totaluse.json"
  let totalUse = {}

  if (fs.existsSync(totalUsePath)) {
    totalUse = JSON.parse(fs.readFileSync(totalUsePath))
  }

  

  if (!totalUse[sender]) totalUse[sender] = 0
  totalUse[sender] += 1

  fs.writeFileSync(totalUsePath, JSON.stringify(totalUse, null, 2))
} catch (e) {
  console.log("TOTAL USE ERROR:", e)
}



try {
  const { loadWelcome, saveWelcome } = await import("./database/welcome.js")

  const db = loadWelcome()
  const chat = m.chat
  

  if (!db.joins[chat]) db.joins[chat] = {}


  if (!db.joins[chat][sender]) {
    db.joins[chat][sender] = Date.now()
    saveWelcome(db)
  }
} catch (e) {
  console.log("JOIN TIME TRACK ERROR:", e)
}

const resize = async (imagePathOrUrl, width, height) => {  
  let imageBuffer;  
  if (/^https?:\/\//.test(imagePathOrUrl)) {  
    const response = await axios.get(imagePathOrUrl, { responseType: "arraybuffer" });  
    imageBuffer = response.data;  
  } else {  
    imageBuffer = await fs.readFile(imagePathOrUrl);  
  }  
  const read = await jimp.read(imageBuffer);  
  const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);  
  return data;  
};  

const reaction = async (jid, emoji) => {  
  conn.sendMessage(jid, { react: { text: emoji, key: m.key } });  
};  

const plug = {  
  conn,  
  command,  
  quoted,  
  fetchJson,  
  qtext,  
  budy,  
  commands,  
  args,  
  text,   
  q,  
  message,  
  messageType,  
  messageKey,  
  pushName,  
  itsMe,  
  chat,  
  sender,  
  userId,  
  reply,  
  botNumber,  
  isGroup,  
  groupMetadata,  
  groupName,  
  groupId,  
  groupMembers,  
  isBotGroupAdmins,  
  isGroupAdmins,  
  isAdmin,  
  isBotAdmin,  
  generateProfilePicture,  
  getBuffer,  
  fetchJson,  
  fetchText,  
  getRandom,  
  runtime,  
  sleep,  
  makeid,  
  prefix,  
  usedPrefix,   
  reaction,  
  resize,  
  metaai  
};  

const pluginHandled = await runPlugins(m, plug);  
if (pluginHandled) return;  

const plugins = await pluginsLoader(path.resolve(__dirname, "../cmd"));
const pluginCommands = plugins.flatMap((p) => p.command || []);
const caseCommands = await getCaseCommands(__filename);
const allCommands = [...new Set([...pluginCommands, ...caseCommands])];

const inputCmd = body
.slice(prefix.length)
.trim()
.split(/\s+/)[0];

if (!allCommands.includes(inputCmd)) {
const similarities = allCommands.map((cmd) => ({
name: cmd,
percent: similarityPercent(inputCmd, cmd)
}));

const sorted = similarities.sort((a, b) => b.percent - a.percent).slice(0, 3);
const filtered = sorted.filter((s) => s.percent >= 45);
const suggestions = filtered
.map((s, i) => `${i + 1}. *${prefix + s.name}* — ${s.percent}%`)
.join("\n");

if (filtered.length > 0) {
const buttons = filtered.map((s) => ({
buttonId: `${prefix}${s.name}`,
buttonText: { displayText: `${prefix}${s.name}` },
type: 1
}));

await conn.sendMessage(
m.chat, 
{ text: `🔍 mungkin yang kamu maksud:\n${suggestions}`, footer: global.namebotz, interactiveButtons: [] },
 { quoted: metaai }
);
}
return;
}

switch (commands) {  
  case "mode": {
  await reaction(m.chat, "🧠");

  const currentMode = global.mode || "public"
  const ownerOnlyActive = currentMode === "ownerly" || currentMode === "oneown"

  let modeText = "Public"
  if (currentMode === "self") modeText = "Self"
  if (currentMode === "ownerly") modeText = "OwnerOnly"
  if (currentMode === "oneown") modeText = "OneOwn"

  m.reply(
`🤖 Bot Mode: *${modeText}*
🔐 OwnerOnly: ${ownerOnlyActive ? "Aktif" : "Tidak"}`
  );
  break;
}

  case "only": {  
    if (!isOwner) return m.reply("Perintah ini hanya untuk Owner.");  
    let duh = body.slice(body.indexOf(commands) + commands.length).trim() || "return m";  
    try {  
      let evaled = await eval(`(async () => { ${duh} })()`);  
      if (typeof evaled !== "string") evaled = util.inspect(evaled);  
      await m.reply(evaled);  
    } catch (err) {  
      m.reply(String(err));  
    }  
    break;  
  }  

  case "runtime":  
  case "rtm":  
  case "ping": {  
    function formatRuntime(ms) {  
      let seconds = Math.floor(ms / 1000);  
      let days = Math.floor(seconds / 86400);  
      seconds %= 86400;  
      let hours = Math.floor(seconds / 3600);  
      seconds %= 3600;  
      let minutes = Math.floor(seconds / 60);  
      seconds %= 60;  
      return `${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik`;  
    }  
    let timestamp = speed();  
    let latensi = speed() - timestamp;  
    let totalMem = os.totalmem();  
    let freeMem = os.freemem();  
    let usedMem = totalMem - freeMem;  
    let memUsage = (usedMem / totalMem) * 100;  
    let uptimeServer = formatRuntime(os.uptime() * 1000);  
    let serverTime = new Date().toLocaleString("id-ID", {  
      timeZone: "Asia/Jakarta",  
      hour12: false  
    });  
    let teks = `
— Informasi Bot 🤖
Nama Bot : ${global.botname || "undefined"}
Runtime Bot : ${runtime(process.uptime())}
Response Speed : ${latensi.toFixed(4)} Second
NodeJS Version : ${process.version}

— Informasi Server VPS 🖥️
OS Platform : ${os.type()} (${os.arch()})
Total RAM : ${(totalMem / 1024 / 1024 / 1024).toFixed(2)} GB
Terpakai : ${(usedMem / 1024 / 1024 / 1024).toFixed(2)} GB (${memUsage.toFixed(2)}%)
Tersisa : ${(freeMem / 1024 / 1024 / 1024).toFixed(2)} GB
Total Disk : 199.9 GB
CPU Core : ${os.cpus().length} Core
Load Avg : ${(os.loadavg()[0] * 100 / os.cpus().length).toFixed(2)}%
Uptime VPS : ${uptimeServer}
Server Time : ${serverTime}
`;
m.reply(teks.trim());
break;
}

case "restart":
case "rst": {
if (!isOwner) return m.reply("Perintah ini hanya untuk Owner.");
await reaction(m.chat, "♻️");
await m.reply("♻️ Restarting bot via panel...");
setTimeout(() => {
process.exit(0);
}, 1200);
break;
}

case "cekidch":  
  case "idch": {  
    if (!q) return reply(`*Contoh penggunaan :*\nketik ${commands} linkchannel`);  
    if (!q.includes("https://whatsapp.com/channel/")) return reply("Link channel tidak valid");  
    let result = q.split("https://whatsapp.com/channel/")[1];  
    let res = await conn.newsletterMetadata("invite", result);  
    let teks = `${res.id}`;  
    return m.reply(teks);  
  }  

  case "bot": case "tes": {  
 m.reply('_*Siap, Bot Telah Aktif*_')
await sleep(100);
await conn.sendMessage(m.chat, {
requestPhoneNumber: {}
});
}
break

case "gcbot": case "grupbot": {  
  m.reply('https://chat.whatsapp.com/Fa1Y7H6aTuqLYXMQgl7W02')  
  }  
  break  

  case "jid":  
  case "getjid": {  
    await reply(chat);  
    break;  
  }  

  default:  
}
} catch (err) {
console.log(err);
}
};
