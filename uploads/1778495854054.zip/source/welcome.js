import fetch from "node-fetch";
import {
  isWelcomeEnabled,
  saveJoinTime,
  formatJoinDate
} from "./database/welcome.js";
import { createCanvas, loadImage } from "canvas";
import fs from "fs-extra";
import path from "path";
import { fileURLToPath } from "url";
import { exec } from "child_process";
import sharp from "sharp";
import { prepareWAMessageMedia } from "@whiskeysockets/baileys";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const WELCOME_BG = "https://a.top4top.io/p_3717yaon61.jpg";
const WELCOME_TITLE = "𝗪 𝗘 𝗟 𝗖 𝗢 𝗠 𝗘";
const DEFAULT_AVATAR = "https://k.top4top.io/p_37351pn3f1.jpg";

function resolveJid(conn, jid) {
  if (!jid) return null;

  jid = conn.decodeJid ? conn.decodeJid(jid) : jid;

  if (jid.endsWith("@lid")) {
    const map = conn.signalRepository?.lidMapping;
    const pn = map?.getPNForLID?.(jid);
    if (pn) jid = pn;
  }

  if (jid.includes(":")) {
    jid = jid.split(":")[0] + "@s.whatsapp.net";
  }

  return jid;
}

const uploadUguu = async filePath => {
  return new Promise((resolve, reject) => {
    exec(
      `curl -s -F files[]=@${filePath} https://uguu.se/upload.php`,
      (error, stdout) => {
        if (error) return reject("Gagal upload ke Uguu");

        try {
          const json = JSON.parse(stdout);
          resolve(json.files[0].url);
        } catch {
          reject("Gagal parsing respon Uguu");
        }
      }
    );
  });
};

async function createWelcomeCanvas({
  username,
  guildName,
  memberCount,
  avatar
}) {
  const canvas = createCanvas(800, 400);
  const ctx = canvas.getContext("2d");

  const bg = await loadImage(WELCOME_BG);

  const canvasRatio = 800 / 400;
  const imgRatio = bg.width / bg.height;

  let drawWidth;
  let drawHeight;
  let x;
  let y;

  if (imgRatio > canvasRatio) {
    drawHeight = 400;
    drawWidth = bg.width * (400 / bg.height);
    x = -(drawWidth - 800) / 2;
    y = 0;
  } else {
    drawWidth = 800;
    drawHeight = bg.height * (800 / bg.width);
    x = 0;
    y = -(drawHeight - 400) / 2;
  }

  ctx.drawImage(bg, x, y, drawWidth, drawHeight);

  ctx.fillStyle = "rgba(0,0,0,0.2)";
  ctx.fillRect(0, 0, 800, 400);

  const ava = await loadImage(avatar || DEFAULT_AVATAR);

  ctx.save();
  ctx.beginPath();
  ctx.arc(400, 140, 60, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(ava, 340, 80, 120, 120);
  ctx.restore();

  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";

  ctx.font = "bold 28px Sans";
  ctx.fillText(username, 400, 240);

  ctx.font = "20px Sans";
  ctx.fillText(`Welcome to ${guildName}`, 400, 280);

  ctx.font = "18px Sans";
  ctx.fillText(`Kamu member ke #${memberCount}`, 400, 310);

  return canvas.toBuffer("image/jpeg");
}

export async function handleWelcomeUpdate(conn, anu) {
  try {
    if (!anu?.id || !anu?.participants?.length) return;
    if (anu.action !== "add") return;

    const groupJid = anu.id;

    if (!isWelcomeEnabled(groupJid)) return;

    let subject = "grup";
    let memberCount = 0;
    let meta;

    try {
      meta = await conn.groupMetadata(groupJid);
      subject = meta?.subject || subject;

      memberCount = Array.isArray(meta?.participants)
        ? meta.participants.length
        : 0;
    } catch {}

    const dbPath = path.resolve(__dirname, "./database/database.json");

    let db = [];

    try {
      db = fs.readJsonSync(dbPath);
    } catch {
      db = [];
    }

    for (const user of anu.participants) {
      let jid = typeof user === "string" ? user : user.id;

      jid = resolveJid(conn, jid);

      if (meta?.participants) {
        const p = meta.participants.find(v => v.id === user);

        if (p?.jid) {
          jid = p.jid;
        }
      }

      if (!jid) continue;

      const now = Date.now();

      saveJoinTime(groupJid, jid, now);

      const joinDate = formatJoinDate(now);

      let mentions = [jid];
      let pushname;

      const userExist = db.find(u => u.nomor === jid);

      if (userExist && userExist.name && userExist.name !== "Unknown") {
        pushname = userExist.name;
      } else {
        try {
          pushname = await conn.getName(jid);
        } catch {
          pushname = jid.split("@")[0];
        }
      }

      let avatar = DEFAULT_AVATAR;

      try {
        const pp = await conn.profilePictureUrl(jid, "image").catch(
          () => null
        );

        if (pp && typeof pp === "string") {
          avatar = pp;
        }
      } catch {}

      let text;

      if (!anu.author) {
        text =
          `👋selamat datang di grup *${subject}*\n` +
          `@${jid.split("@")[0]} pada ${joinDate} telah bergabung ke grup ini melalui tautan undangan\n\n` +
          `terimakasih telah bergabung, ketik .𝗵𝗲𝗹𝗽 untuk melihat fitur\n` +
          `dan ketik .𝗺𝗲 / .𝗽𝗿𝗼𝗳𝗶𝗹𝗲 untuk melihat profile kamu`;
      } else {
        let inviter = resolveJid(conn, anu.author);

        if (meta?.participants) {
          const p = meta.participants.find(v => v.id === anu.author);

          if (p?.jid) {
            inviter = p.jid;
          }
        }

        if (inviter) mentions.push(inviter);

        text =
          `👋selamat datang di grup *${subject}*\n` +
          `@${jid.split("@")[0]} kamu ditambahkan oleh @${inviter.split("@")[0]} pada tanggal ${joinDate}\n\n` +
          `terimakasih telah berpartisipasi ke grup ini, ketik .𝗵𝗲𝗹𝗽 untuk melihat fitur\n` +
          `dan ketik .𝗺𝗲 / .𝗽𝗿𝗼𝗳𝗶𝗹𝗲 untuk melihat profile kamu`;
      }

      try {
        const canvasBuffer = await createWelcomeCanvas({
          username: pushname,
          guildName: subject,
          memberCount,
          avatar
        });

        const metaImg = await sharp(canvasBuffer).metadata();

        const tempFile = path.join(
          __dirname,
          `welcome-${Date.now()}.jpg`
        );

        await fs.writeFile(tempFile, canvasBuffer);

        const uploadedUrl = await uploadUguu(tempFile);

        await fs.unlink(tempFile);

        const media = await prepareWAMessageMedia(
          {
            image: {
              url: uploadedUrl
            }
          },
          {
            upload: conn.waUploadToServer,
            mediaTypeOverride: "thumbnail-link"
          }
        );

        const image = media.imageMessage;

        image.height = metaImg.height || 400;
        image.width = metaImg.width || 800;

        await conn.sendMessage(groupJid, {
          text: `${uploadedUrl}\n\n${text}`,
          mentions,
          linkPreview: {
            "matched-text": uploadedUrl,
            title: WELCOME_TITLE,
            previewType: 0,
            jpegThumbnail: canvasBuffer,
            highQualityThumbnail: image,
            linkPreviewMetadata: {
              linkMediaDuration: 0,
              socialMediaPostType: 1
            }
          },
          favicon: {
            url: uploadedUrl
          }
        });

      } catch (err) {
        console.error("WELCOME CANVAS ERROR:", err);

        await conn.sendMessage(groupJid, {
          text,
          mentions
        });
      }
    }
  } catch (e) {
    console.error("WELCOME ERROR:", e);
  }
}