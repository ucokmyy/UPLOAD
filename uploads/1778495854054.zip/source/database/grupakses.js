import fs from "fs"

const path = "./source/database/grupakses.json"

export const loadGroupAccess = () => {
  if (!fs.existsSync(path)) return []
  return JSON.parse(fs.readFileSync(path))
}

export const saveGroupAccess = (data) => {
  fs.writeFileSync(path, JSON.stringify(data, null, 2))
}

export const addGroupAccess = (id) => {
  const data = loadGroupAccess()
  if (!data.includes(id)) {
    data.push(id)
    saveGroupAccess(data)
  }
}

export const delGroupAccess = (id) => {
  let data = loadGroupAccess()
  data = data.filter(v => v !== id)
  saveGroupAccess(data)
}

export const isAllowedGroup = (id) => {
  const data = loadGroupAccess()
  return data.includes(id)
}