import fs from "fs"
import path from "path"

const WELCOME_DB = "./source/database/welcome.json"

function ensureDb() {
  const dir = path.dirname(WELCOME_DB)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

  if (!fs.existsSync(WELCOME_DB)) {
    fs.writeFileSync(
      WELCOME_DB,
      JSON.stringify({ groups: {}, joins: {} }, null, 2)
    )
  }
}

export function loadWelcome() {
  ensureDb()
  try {
    const data = JSON.parse(fs.readFileSync(WELCOME_DB, "utf-8"))

    // ✅ SANITIZER BIAR TIDAK ERROR LAGI
    if (!data || typeof data !== "object") {
      return { groups: {}, joins: {} }
    }

    if (!data.groups || typeof data.groups !== "object") {
      data.groups = {}
    }

    if (!data.joins || typeof data.joins !== "object") {
      data.joins = {}
    }

    return data
  } catch {
    return { groups: {}, joins: {} }
  }
}

export function saveWelcome(data) {
  ensureDb()
  fs.writeFileSync(WELCOME_DB, JSON.stringify(data, null, 2))
}

export function setWelcomeEnabled(groupJid, enabled) {
  const db = loadWelcome()
  db.groups[groupJid] = !!enabled
  saveWelcome(db)
  return db.groups[groupJid]
}

export function isWelcomeEnabled(groupJid) {
  const db = loadWelcome()
  return !!db.groups[groupJid]
}

// ======================
// SIMPAN JOIN TIME REAL-TIME
// ======================
export function saveJoinTime(groupJid, userJid, time = Date.now()) {
  const db = loadWelcome()

  if (!db.joins[groupJid]) {
    db.joins[groupJid] = {}
  }

  db.joins[groupJid][userJid] = time

  saveWelcome(db)
  return time
}

export function formatJoinDate(timeMs) {
  const d = new Date(timeMs)
  const day = String(d.getDate()).padStart(2, "0")
  const year = d.getFullYear()
  const months = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember",
  ]
  const monthName = months[d.getMonth()] || "Januari"
  return `${day} - ${monthName} - ${year}`
}