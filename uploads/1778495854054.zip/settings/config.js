import fs from "fs-extra"
import chalk from "chalk"

const modeFile = "./source/database/mode.json"
const allowedModes = ["public", "self", "ownerly", "oneown"]

if (!fs.existsSync(modeFile)) {
  fs.outputJsonSync(modeFile, { mode: "public" }, { spaces: 2 })
}

let rawModeData = await fs.readJson(modeFile).catch(() => ({ mode: "public" }))
let savedMode = rawModeData?.mode

// support file lama: true = public, false = self
if (savedMode === true) savedMode = "public"
if (savedMode === false) savedMode = "self"
if (!allowedModes.includes(savedMode)) savedMode = "public"

global.mode = savedMode

global.saveMode = async function (value) {
  let next = value

  if (next === true) next = "public"
  if (next === false) next = "self"
  if (!allowedModes.includes(next)) next = "public"

  global.mode = next
  await fs.writeJson(modeFile, { mode: next }, { spaces: 2 })
}

global.primaryOwner = "6282296626024@s.whatsapp.net"
global.pairingPhoneNumber = "6282159019459"
global.customPairingCode = "ZYYYREYN"
global.owner = [
  "62895392968503@s.whatsapp.net",
  "6282296626024@s.whatsapp.net",
  "237622378249@s.whatsapp.net",
  "39415451746429@lid",
  "231387823136812@lid",
  "113498839318628@lid"
]
global.linkgc = "https://chat.whatsapp.com/Fa1Y7H6aTuqLYXMQgl7W02"
global.saluran = "https://whatsapp.com/channel/0029VaodKQNGOj9rjXGW8F03"
global.idsal = "120363320632446478@newsletter"
global.menuStyle = "relay"
global.idself = "120363316437080633@g.us"
global.botname = "rena - cimmy BOT"
global.namebotz = "rena - cimmy BOT"
global.packname = "reyyzy bot"
global.author = "stiker buatan bot"
global.nameown = "Reyn"
global.footer = "CIMMY"
global.autoread = true
global.autoswview = true
global.autotyping = true
global.YouTube = "-"
global.GitHub = "-"
global.Telegram = "https://t.me/"
global.ChannelWA = "https://whatsapp.com/channel/0029VaodKQNGOj9rjXGW8F03"